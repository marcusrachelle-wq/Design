# Contenu Sandbox — Armes retenues

> Registre éditorial. Trois champs par arme : **nom complet**, **jeu de référence** (apparence / feeling), **choix d'éditeur**.
> Ce document ne traite pas l'équilibrage chiffré — voir les fiches dédiées.

---

## 1. CSNU

| # | Nom complet | Référence | Choix d'éditeur |
|---|---|---|---|
| 1 | Fusil d'Assaut MA37 | Halo Reach | « Petit » fusil d'assaut, peu de mécaniques qui se démarquent, plus précis mais pas brutal pour un sou. 32 coups seulement dans le chargeur. Arme utilisée par les marines en général, rarement une arme que le joueur va choisir. Il s'agit d'avoir chez les humains un équivalent / une dualité entre le fusil plasma et le répéteur. |
| 2 | Fusil d'Assaut MA5B | Halo CE / Campaign Evolved | Meilleure itération en terme de sensations et de limites, mais visuels de Campaign Evolved. 60 balles, moins précis que Campaign Evolved, conçu pour éliminer les vagues via des rafales longues, et rentabiliser les rafales courtes à distance (arme jack-of-all-trades, un peu technique à utiliser). |
| 3 | Magnum M6D | Halo CE | Remplace TOUTE FORME DE DMR mono-coup. Garder la brutalité de la version Campaign Evolved. Design chromé du 1er Halo, effet perforant (headshots). |
| 4 | Pistolet M6C/SOCOM | Halo 2 / Halo 3 ODST | Cadence de tir un peu plus élevée, moins puissant que le Magnum, avec ou sans silencieux, arme ultime et peu chère contre les petits ennemis. |
| 5 | Mitraillette M7/M7S SMG | Halo 5 (apparence) + comportement de Halo 3 ODST | La mitraillette de H3 / H3-ODST est celle qui ne fait pas doublon avec le fusil d'assaut ; mais avec le chargeur façon Halo 5. Moins puissante, mais plus précise que le MA5B. |
| 6 | Revolver W0-LF M4 | Originale | Puissant révolver dédié à l'arrêt (physique) de masses / d'ennemis en course. Malus contre les boucliers / armures, mais surtout un stun qui empêche un ennemi dangereux, solide et agressif (véhicule léger compris, Hunters compris) de gagner trop de terrain. Conçu aussi pour avoir un effet Perforateur. |
| 7 | Fusil de Combat BR75 | Halo Reach Evolved (model) | Meilleur en terme de design / sensation de tir, outil plus intéressant que le DMR. |
| 8 | Fusil à Pompe M90 CAWS | Halo Reach | Itération la plus expressive, même si le comportement sera « réhaussé » à la CE (voir conditions dans la fiche du fusil) ; la version de Reach est le seul équilibrage qui ne soit pas aussi mauvais que ceux de H2/H3 et pas aussi suprême que la version de CE. |
| 9 | Fusil de Sniper SRS99C S2 | Halo Campaign Evolved | Itération moderne proche du Sniper d'origine. |
| 10 | Lance-Roquettes M41 SSR MAV/AW | Halo CE (moderniser) | Garder la simplicité du design, sans fioritures et effets de plastique, sans suivi de cibles. |
| 11 | Laser Spartan M6 G/GNR | Halo 3 | Itération historique, voir pour que batterie = 5 tirs. |
| 12 | Lance-Grenades M319 IGL | Halo Reach | Arme lourde la plus amusante niveau gameplay jamais créée dans un Halo. |
| 13 | Lance-Flammes | Halo CE | Arme INJUSTEMENT méprisée par les développeurs, fonctionnement très simple et très fun, excellent pour avoir un burst de dégâts sur l'infanterie via une arme très lourde. |
| 14 | Lance Spartane | ORIGINALE | Arme de corps à corps dédiée aux Spartans. Nouvelle arme iconique dédiée à Yumiko pour ce jeu. |
| 15 | Grenade à Fragmentation | Halo CE | Grenade obligatoire. |
| 16 | Mitrailleuse Fixe M739 LMG — version « portable » : M739 SAW | Halo 4 / 5 (hybride) | Mitrailleuse décrochable, devient une arme lourde « classique » / non-fixe en abandonnant le gros magasin carré (voir explication de l'arme dans l'équilibrage). Permet à ce système de garder la SAW sans faire doublon avec la mitrailleuse gatling. |

---

## 2. Covenant – Élites

| # | Nom complet | Référence | Choix d'éditeur |
|---|---|---|---|
| 1 | Fusil à Plasma | Halo CE (2001) | Itération la plus utile et fun de l'arme (projectiles plus rapides que dans Reach). Comparable au fusil d'assaut MA5B. |
| 2 | Pistolet à Plasma | Halo CE (2001) | Seule vraie version utile de cette arme. Très puissante en soi, arme top tier. |
| 3 | Needler | Halo CE (2001) | Améliorer le guidage, garder le côté crystal et globuleux de l'arme d'origine. |
| 4 | Répéteur à Plasma | Halo Reach (Custom) | Vrai fusil d'assaut covenant, projectiles plus rapides pour les Covenants ; plus précis que le fusil à plasma quand il est chaud, chauffe intégralement gérable (appui sur carré). Pas d'effet sur les boucliers, devient très puissant et précis avec de la chauffe. |
| 5 | Grenadier à Plasma | Halo 5 | Remplace le fusil de concussion. **Tir normal :** un projectile avec forte énergie cinétique à l'impact (peu puissant sauf si on touche directement, gros stun), outil un peu de « pro » pour marier avec les capacités de Yumiko. **Charge :** consomme 3 tirs sur les 6 du chargeur, tire une grenade collante (comme une grenade plasma), mais qui rebondit au sol comme le lance-grenades humain (physique conçue comme fun, interactive avec le décor). |
| 6 | Fusil à Aiguilles | Halo Reach | Bien plus charismatique et unique que la carabine ; permet d'avoir 1 seul DMR covenant qui soit à lui seul suffisant. |
| 7 | Fusil Focus | Halo Reach | Bien plus fun que le simple sniper covenant (trop semblable à celui des humains), et parfaitement distinct en terme de gameplay (pourquoi pas : jeu avec la chauffe pour obtenir plus de puissance). Projectile à charge (charge en restant appuyé sur carré, nécessite de tirer manuellement sous peine de perdre de la batterie et surchauffer sans tirer) comparable au railgun, permet de faire deux coups en un. |
| 8 | Canon à Combustible | Halo 3 (Custom Physics) | L'itération de 2001 est la plus fun et brutale ; ajouter l'effet de CE (Evolved) de laisser du combustible brûler sur le point d'impact. |
| 9 | Épée à Énergie | Halo : qu'importe | Rien à rajouter. |
| 10 | Grenade à Plasma | Halo CE / Reach | Grenade mythique 100 % obligatoire. |
| 11 | Canon à Plasma fixe | Halo 3 / Reach | Tourelle mobile décrochable des Covenants, un classique. |
| 12 | Grêleur | ORIGINALE | Technologie de type AIGUILLES, avec des aiguilles non pas roses mais oranges / rouges. Fusil à deux mains, avec un long bec, et une carcasse bombée avec les pics qui dépassent ; le bec contient 3 canons disposés en triangle. Tir 3 par 3, 9 coups pour une super combine. Projectiles linéaires ne disposant d'aucun suivi de cible. Super combine pouvant détonner des véhicules. Les tirs ralentissent passé une certaine distance (mais gagnent un léger suivi). Existe en déclinaison « Fixe » avec un chargeur étendu. |

---

## 3. Brutes / Jiralhanae

| # | Nom complet | Référence | Choix d'éditeur |
|---|---|---|---|
| 1 | Fusil Plasma Brute | Halo CE / Custom | Version du fusil à plasma d'Halo CE avec une cadence de tir plus élevée, puissance accrue, mais batterie et précision moindres ; version « chaotique ». Plus d'effet aussi sur les boucliers, mais aussi outil avec lames pour le CAC (apparence retravaillée). |
| 2 | Sabre Grenade | Halo 3 | C'est l'arme brute par excellence. Elle remplace le fusil de concussion pour avoir des projectiles explosifs à l'impact avec fort effet de projection / souffle important. Outil de CAC (c'est aussi une arme de CAC avec un pattern). Un bon joueur utilisera deux coups consécutifs pour imprégner une forte concussion à un élément de décor (et tuer indirectement des ennemis). |
| 3 | Mauler | Halo 3 | Permet d'avoir un vrai fusil à pompe covenant, mais le tir se compose de deux entités ; mix avec le Mangler : un tir précis qui perd en puissance avec la distance mais doté d'un effet PERFORANT, ainsi que du shrapnel du Mauler (dispersion) augmentant la puissance au corps à corps. Buff des coups de crosse également. |
| 4 | Fusil Électrique | Halo Infinite | **L'arme d'assaut des Brutes**, au même rang que le MA5B et le Répéteur à Plasma. Anti-protection : excellente contre les boucliers, très faible sur la chair nue. Coups lents et lourds là où les deux autres arrosent. Projectile qui ralentit puis s'arrête — inutile au-delà de 25 m. Acharner sur une cible sans protection la charge jusqu'à l'explosion. |
| 5 | Ravageur | Halo Infinite | Halo Infinite = meilleur ajout d'armes brutes, et le Ravageur est pile dans l'esprit (un vrai lance-roquettes brute). **Tir unique :** 3 coups en rafale. **Charge :** projectile plus lent, guidé, qui explose avec une puissance supérieure au canon à combustible (projectile lent au corps à corps mais qui accélère progressivement ; meilleure arme lourde covenant). |
| 6 | Fusil à Faisceau | Halo 3 | Reprise de l'iconique fusil de sniper covenant, mais avec un équilibrage modifié pour éviter les doublons avec le sniper humain : tirs plus rapides (3 à la suite pour surchauffer, 33 % moins puissant que le sniper des humains), mais dispose d'un tir chargé donnant un tir dévastateur (c'est aussi le moyen d'inclure une tradition des snipers covenants à plusieurs tirs / maniements, voir changements sur le Focus Rifle). |
| 7 | Marteau Antigravité | Halo Reach / Halo 5 (Tartarus) | Utiliser la version avec onde de choc au sol (charger le tir pour balancer une onde de choc, et ainsi augmenter la portée). |
| 8 | Mutilator | Halo Infinite | MEILLEUR shotgun de la saga, je veux rien savoir, avec son concept de shotgun à deux canons qui se casse, plus brutal que celui des humains, avec un petit marteau antigravité (pas d'onde de choc… sauf charge, mais marteau moins puissant sur le fusil et onde de choc plus courte). |
| 9 | Tourelle Spiker | CUSTOM | Version lourde du Spiker, dont la valeur ajoutée est l'effet de combustion de la cible après suffisamment de pics surchauffés enflammés ; ainsi que des munitions capables d'entretenir un feu « lumière » ou « plasma brute ». |
| 10 | Grenade Incendiaire | Halo 3 ODST | Grenade injustement sous-estimée, peu de rayon d'action, mais absolument mortelle si elle touche, excellent burst de dégâts, efficace contre absolument tout. |
| 11 | Grenade Dynamo | Halo Infinite | Grenade permettant de se passer de pistolet à plasma. Efficace contre les boucliers et désactive les véhicules. |

---

## 4. Forerunner / Sentinelles

> Faction d'appoint. Ces armes se trouvent sur les Sentinelles (niveaux et structures Forerunner
> inoccupées) et chez **certains Covenants de haut rang** appartenant à un ordre particulier.
> Plusieurs sont **sacrées de par leur provenance** : seules certaines unités peuvent les porter,
> sur le modèle de l'épée chez les Élites.

| # | Nom complet | Référence | Choix d'éditeur |
|---|---|---|---|
| 1 | Canon Sentinelle | Halo 3 / CE (2026) | Arme Forerunner minimum, un peu à tout faire. Trouvable sur les Sentinelles (niveaux / structures Forerunner inoccupées) ou certains Covenants d'un ordre particulier. |
| 2 | Heatwave | Halo Infinite | Seule arme Forerunner utile et sympa niveau gameplay (remplacerait un Incinerator) avec son tir vertical et horizontal (précision, ou horizontal pour finir plus facilement). **Arme sacrée** de par sa provenance : seules certaines unités peuvent l'utiliser (un peu comme l'épée chez les Élites). |
| 3 | Cindershot | Halo Infinite | Remplace le fusil à concussion. Arme lourde Forerunner, comme un concussion mais plus puissant, et se rechargeant cellule / cartouche par cartouche. Arme assez rare, utile contre les boss de par sa simple supériorité statistique. **Arme sacrée** de par sa provenance : seules certaines unités peuvent l'utiliser (un peu comme l'épée chez les Élites). |
| 4 | Flash | Halo 3 (custom) | Grenade flare Forerunner, inspirée du module flash (équipement consommable) de Halo 3. Perturbe la visée ennemie (explose rapidement comme une grenade, flash blanc cassé / doré) qui éblouit quelques secondes. Cela donne un créneau de liberté pour le Système Hornet du joueur. |
