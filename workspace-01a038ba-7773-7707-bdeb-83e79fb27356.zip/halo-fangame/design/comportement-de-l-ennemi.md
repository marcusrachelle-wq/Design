# Comportement de l'ennemi

> Fichier ouvert en attente des **fiches d'ennemis** (stats + comportements, armée Covenant en
> grande partie déjà rédigée côté auteur). Aucun contenu n'est pré-rempli ici : ce document ne
> contient pour l'instant que les **questions en suspens** que les fiches trancheront.

---

## Acquis

| Point | État |
|---|---|
| Les ennemis peuvent subir la **panique** et la **frénésie** — états qui les rendent désordonnés | ✅ Acté |
| Le comportement ennemi peut être **perturbé activement** par le joueur | ✅ Acté |
| Les ennemis **esquivent les grenades** ; les gradés doivent être **perturbés ou saturés** pour cesser d'y penser | ✅ Acté |
| La mobilité de Yumiko peut la rendre **difficile à viser** — la survie ne passe pas nécessairement par se cacher | ✅ Acté |
| **Légendaire ≠ Héroïque par les chiffres** : mêmes valeurs, comportements **plus raffinés** en Légendaire | ✅ Acté |

---

## Questions en attente des fiches

### Q1 — Fenêtres de recharge bouclier / boosters

Les boosters ne repassent à **10 %/s** qu'après régénération du bouclier ; sinon ils restent à
**2,5 %/s** (40 s pour un plein). Or D15 pose que les formations laissent peu de répit dès l'héroïque.

**À trancher par les fiches :** les ennemis ne laisseront pas le joueur se régénérer *passivement*,
mais le joueur **crée ses ouvertures** — via panique, frénésie, saturation, ou simplement en étant
trop mobile pour être touché. La question devient donc : **combien de temps dure une ouverture
provoquée**, et suffit-elle à amorcer le cycle bouclier → boosters ?

> Reformulé : ce n'est pas un problème de recharge, c'est une **question de durée d'ouverture**.

---

### Q2 — Charge ART transportable en grenades

Huit grenades à fragmentation cumulées = **10,00 ART** de dégâts portables, contre **9,75 ART** pour
le Général Élite, unité la plus solide de la matrice.

**Contrepoids déjà identifié :** les ennemis **esquivent**. Les gradés en particulier ne se laissent
pas grenader sans avoir été perturbés ou saturés au préalable.

**À trancher par les fiches :** le taux d'esquive et les conditions de sa suppression déterminent le
**rendement réel** des 10,00 ART portables. Si l'esquive des gradés est fiable, le cumul de 8 frags
est un investissement en volume, pas une clé — et la question tombe d'elle-même.

---

## Ennemis inédits — Chasseur « Berzerker » et Prélat

> **Ouvert par l'arbitrage ③ de la matrice des effets** *(`equilibrage-sandbox-armes.md`, §5.2)*.
> Ces deux unités sont **inédites dans la série**. Aucun chiffre n'existe encore : cette section n'est
> qu'un **cadre de contraintes** déduit de ce qui est déjà décidé ailleurs. **Rien ici n'est un chiffre
> d'auteur.**

**Pourquoi ils arrivent maintenant.** Ce sont les deux ennemis les plus solides envisagés pour la fin de
partie, et leur solidité conditionne le dosage de tout l'armement tardif. Les fixer, c'est fixer le
plafond contre lequel les armes les plus fortes de la sandbox sont censées être lues.

| Contrainte héritée | Origine | Conséquence pour ces deux fiches |
|---|---|---|
| **Le feu plafonne à 0,18 ART/s** | Non-cumul, §5.0 | Une brûlure ne peut **jamais** être une stratégie principale contre eux. S'ils doivent tomber au feu, il faudra une **vulnérabilité écrite sur leur fiche** *(règle de lecture : ce qui n'est pas écrit n'existe pas)* |
| **Le ravivage Lumière vaut 1,2375 ART** | §5.2 | Sur une unité à **8,50 ART** *(Général)*, cela pèse 14,6 %. Leur PV doit être posé en sachant **combien de ravivages** vous voulez exiger |
| **Une seule arme Railgun par rencontre** | §2.7 / doctrine | Si l'un d'eux est un boss de salle, **le Railgun est déjà la réponse par défaut** — attention à ne pas superposer deux clés |
| **Sept morts exactes à 2,50 ART** *(4 à distance, 3 en dorsal au corps à corps)* | Synthèse V · §5.6 | S'ils frappent au-dessus de 2,50, ils rejoignent la liste des **one-shots** sur Yumiko. À décider explicitement |

**La question de placement, qui est un problème de niveau et pas d'équilibrage.** L'épée se ramasse
**juste avant la salle du boss**. Trois points restent ouverts, et ils déterminent si le ×1,50 est sain :

1. **La conservation.** Le joueur garde-t-il l'épée **après** la rencontre ? Si oui, le multiplicateur
   s'applique à la piétaille, où il est disproportionné. Options : batterie qui ne survit pas au combat,
   ramassage non transportable hors zone, ou acceptation assumée d'une **fenêtre de surpuissance** —
   ce qui est un choix de rythme parfaitement défendable en fin de campagne.
2. **La redondance.** Si le Railgun **et** l'épée ouvrent la même serrure, l'un des deux est décoratif.
3. **Le cas du joueur qui rate le ramassage.** Le boss doit rester **franchissable sans l'épée**, sinon
   le placement devient un mur. C'est la contrainte la plus contraignante des trois.

**Ce que je recommande de fixer en premier**, dans cet ordre : ① le **total de PV** de chaque unité en
ART *(c'est le seul chiffre dont dépendent tous les autres)* · ② leur **répartition bouclier / chair /
blindage**, qui décide seule de quelles armes les touchent · ③ **s'ils sont ANTI-PERFO**, comme le Dévot
· ④ leur **dégât de contact** contre le seuil de 2,50.

---

*Suite du document en attente : fiches d'ennemis (stats, comportements, paliers Normal → Légendaire),
les 5 archétypes d'escouade, et la règle « une seule arme Railgun par rencontre ».*
