# Arcade Yumiko

**Projet :** Fangame Halo · système de mobilité HORNET
**Objet :** le système arcade du personnage jouable

> Le jeu ne se joue **pas** avec le Major, mais avec une Spartane du nom de **Yumiko**.
> Le système porte son nom parce qu'il **lui appartient** : aucune autre unité du jeu ne s'y conforme.

---

## Le socle : ce qui est repris d'Halo CE

| Élément conservé | Précision |
|---|---|
| **Feeling lourd des armes** | Base sensorielle du jeu |
| **PAS DE SPRINT** | Non négociable |
| **Escouades nettes** | Les ennemis sont constitués en groupes lisibles |
| **Niveaux fermeture ↔ ouverture** | Alternance, avec phases en véhicules |
| **PV limités, kits de soin** | Pas de régénération passive de la santé |
| **Coups de crosse sans auto-dash** | Pas de saisie automatique à la Halo 2. **Force d'arrêt : 0,35** (35 % en unité anti-armure / blindage / bouclier) |
| **Mêlée dans le dos** | Ne tue pas forcément comme dans CE : c'est un **critique** — voir barème ci-dessous |
| **Le sang** | Géré comme dans Halo CE |
| **Sauts hauts et flottants** | Gabarit Spartan : saut de **1,00 m**, pieds portés à **2,15 m** de haut |

### Le critique de mêlée

| Cas | Valeur |
|---|---|
| Mêlée de base | **0,35** |
| Mêlée dans le dos, depuis la base 0,35 | **1,00** |
| Mêlée dans le dos, depuis **toute autre base** | **× 3,00** (multiplicateur fixe) |

> Le critique **traverse les protections** : les dégâts passent à travers bouclier, armure et blindage.

---

## Le triangle d'or, réorganisé

Bungie articule son gameplay autour de **Tir – Grenades – Mêlée**. Ce jeu est différent.

Ici, **les grenades font partie du tir** — avec un aspect gestion plus poussé que dans n'importe
quel Halo, tous opus confondus : **la grenade est une arme à équiper**.

Le triangle devient donc :

| Sommet | Contenu |
|---|---|
| **TIR** | La sandbox d'armes, **gestion des grenades incluse** |
| **MOBILITÉ HORNET** | Tout ce qu'il est possible de faire avec les boosters |
| **MÊLÉE** | Coups spéciaux incorporés |

---

## Ce que le triangle impose

Le gameplay de Yumiko est guidé par trois choses : la **sandbox d'armes** à disposition, les
**options de mobilité** dues aux boosters, et les **coups de mêlée spéciaux** qui donnent accès à
plus d'ouvertures et de dégâts.

**Les ennemis sont tanky comparés au joueur.** Leurs salves font mal, et **dès le niveau héroïque**
ils adoptent des formations laissant peu de répit. Il est **nécessaire d'exploiter le Triangle dans
son intégralité** — aucun sommet n'est optionnel.

### Le combat ne suit plus le cycle classique

Le schéma habituel *tir → couverture → mêlée pour achever* ne s'applique quasiment jamais.

| Élément classique | Ce qu'il devient ici |
|---|---|
| **Couverture** | Souvent compromise — elle n'est pas une solution par défaut |
| **Encaissement** | Passe par la **mobilité** : esquive réelle + scaling des dégâts reçus |
| **Mêlée** | Bien plus polyvalente : enchaînements, reprise de tir, déplacements |

---

## 1. Les ressources

### R1 — Bouclier

| Point | Valeur |
|---|---|
| Capacité | **100 %**, soit **1,00 ART** de puissance d'arrêt |
| Régénération | Oui |

---

### R2 — Crans de vie

**10 crans affichés, 15 crans réels.** Deux crans sont dissimulés et servent de charnière visuelle :

| Cran caché | Ce que sa perte déclenche |
|---|---|
| **N° 5** | Les 5 crans restants passent de **bleu à jaune** |
| **N° 8** | Les 3 crans jaunes restants passent au **rouge** |

**Les crans rouges valent double.** Tout cran *entamé* se régénère.

#### Les trois voies de récupération des PV

| Voie | Effet | Visibilité |
|---|---|---|
| **Chip régen** | Régénère le cran *entamé*, celui-là seulement | **Invisible** à l'interface |
| **Kit de soin partiel** | Régénère **le palier en cours** (rouge, jaune **ou** bleu, selon la position du joueur) | Explicite |
| **Pack de soin** | Régénère **tous les crans perdus**, instantanément | Explicite |

Les **kits partiels** se récupèrent sur certains ennemis morts, comme les grenades.

> **Articulation avec D4 et D13.** La doctrine pose « aucune régénération des PV » et « soins par kits
> uniquement ». La **chip régen** en est l'**exception explicite** : elle ne rend jamais un cran perdu,
> seulement le cran entamé, et elle est invisible. Elle absorbe le dommage résiduel sans jamais
> reconstituer une ressource — D4 et D13 restent vrais au niveau du cran.

#### Piste de vie réelle (Légendaire / Héroïque, 0,10 ART par cran effectif)

| État affiché | Crans effectifs | ART restants | Coût du segment |
|---|---|---|---|
| 10 crans bleus | **15** | 1,50 | — |
| 6 crans bleus | 11 | 1,10 | 0,40 |
| 6 crans jaunes | 10 | 1,00 | 0,10 |
| 3 crans jaunes | 7 | 0,70 | 0,30 |
| 3 crans rouges | 6 | 0,60 | 0,10 |
| Mort | 0 | 0,00 | **0,60** |

> **Total : 1,50 ART.** Le dernier segment vaut à lui seul **40 % de la barre entière** — trois crans
> rouges qui valent double, soit six crans effectifs. Le joueur en zone rouge dispose de plus de marge
> qu'il n'en voit.

#### Valeur du cran selon la difficulté

| Difficulté | Cran | PV totaux | Bouclier | Particularité |
|---|---|---|---|---|
| **Légendaire** | 0,10 ART | 1,50 | 100 % | — |
| **Héroïque** | 0,10 ART | 1,50 | 100 % | La difficulté vient de l'**IA** et de la **composition des vagues**, pas des chiffres |
| **Normal** | 0,135 ART *(×1,35)* | **2,025** | **135 %** (1,35) | Même multiplicateur appliqué au bouclier |
| **Facile** | 0,150 ART *(×1,50)* | **2,250** | **150 %** (1,50) | **+ régénération passive par palier** (rouge, jaune, bleu se rechargent seuls) |

**Budget de survie total par difficulté :**

| Difficulté | PV | Bouclier | **Total** | Écart vs Légendaire |
|---|---|---|---|---|
| Légendaire / Héroïque | 1,500 | 1,00 | **2,500 ART** | — |
| Normal | 2,025 | 1,35 | **3,375 ART** | **+35 %** |
| Facile | 2,250 | 1,50 | **3,750 ART** | **+50 %** *(+ régén passive)* |

> **Légendaire et Héroïque partagent exactement les mêmes chiffres.** L'écart entre les deux repose
> intégralement sur des **comportements ennemis plus raffinés** en Légendaire — voir
> `comportement-de-l-ennemi.md`.

> Les taux de cette section sont **provisoires** et peuvent évoluer — de même que la valeur de bouclier
> de Yumiko (maintenue à **100 %** pour l'instant, mais susceptible d'être alignée sur sa valeur de vie)
> et le taux de conversion bouclier → boost.

#### Intention de l'affichage

> **Minimiser aux yeux du joueur l'effectif de ses ressources.** Un joueur a tendance à être plus
> prudent que de raison ; en lui montrant 10 crans là où il en possède 15, on réduit la frustration
> sans réduire la marge réelle. La zone rouge, en particulier, dure deux fois plus longtemps
> qu'elle n'en a l'air.

---

### R3 — Boosters d'armure (stamina)

*Booster = stamina : les deux termes désignent la même chose.*

C'est **la nouveauté par rapport à un Halo classique**.

| Point | Valeur |
|---|---|
| Échelle | Chauffe de **0 à 100 %** (surchauffe) |
| Recharge nominale | **2,5 %/s** → plein en **40 s** |
| Recharge après régénération du bouclier | **10 %/s** → plein en **10 s** *(×4)* |

**Pourquoi un cooldown aussi long :** les impulsions de booster consomment **peu d'unités**. La jauge
unique est conçue pour se gérer **sur toute la durée de l'affrontement**, contrairement au bouclier
qui, lui, sera rechargé plusieurs fois.

#### Conversion bouclier → boost

Si Yumiko est à court de boost, elle peut **consommer une partie de son bouclier** pour prolonger ses combos.

| Conversion | Détail |
|---|---|
| Taux | **1 % de boost = 10 % de bouclier** |
| Un bouclier plein achète | **10 % de boost** |

**Effet recherché :** la recharge du bouclier entraîne celle des boosters **à sa suite**. Le bouclier
se recharge normalement, puis les boosters passent à 10 %/s dans la foulée.

---

### R4 — Armement

| Point | Valeur |
|---|---|
| Capacité | **2 armes** : une équipée, une rangée |
| Changement | **Y** |
| Dual Handling | Selon les armes éligibles |

---

### R5 — Grenades

| Point | Valeur |
|---|---|
| Capacité totale | **8 grenades** |
| Types existants | **5** |
| Types équipables simultanément | **2** — un emplacement gauche, un emplacement droit |
| Par emplacement | 2 de chaque type… |
| **Cumul** | …mais équiper **le même type à gauche et à droite** permet de porter **8 grenades identiques** |
| Échanger | Maintenir **flèche gauche** ou **flèche droite** — l'ordre détermine le placement gauche/droite |

**Ordre du menu de navigation :**

| Ordre | Grenade |
|---|---|
| 1 | Fragmentation |
| 2 | Plasma |
| 3 | Incendiaire |
| 4 | Dynamo |
| 5 | Flash |

**Objets de soin :** jusqu'à **2**, tous types confondus (leurs effets sont identiques). Ce sont des
consommables **à part** — ils s'utilisent en **maintenant flèche gauche / droite ≈ 750 ms**, jamais
par flèche + X.

---

### R6 — Équipements et consommables

Ramassables et utilisables **à la manière des Covenants**.

| Emplacement | Commande | Nature |
|---|---|---|
| Gauche | **Gauche + X** | **Consommable** |
| Droite | **Droite + X** | **Équipement d'armure** |

Ce sont deux types distincts, d'où la séparation des emplacements.

> **Sandbox émergente** *(non essentielle au gameplay — le joueur doit la découvrir)* : Yumiko peut
> échanger son consommable et/ou son équipement contre une **troisième, voire une quatrième
> sélection de grenades**.

---

### Caractéristiques physiques

| Caractéristique | Valeur |
|---|---|
| **Vitesse de marche** | **1,00 unité** — vitesse d'Halo CE |
| **Hauteur de saut** | **1,00 unité** = 1 hauteur de Spartan ≈ **2,25 m**, physique flottante typique des Halo |
| **Vitesse de chute (indice)** | **1,00** = vitesse de chute d'un saut sur sol plat |
| **Force de mêlée** | **0,35 ART** · critique dos **×3, plafonné à 1,00 ART** · équivalent **35 %** sur blindages, armures et boucliers |

> **Précision sur le critique :** le multiplicateur est **×3 avec un plafond dur à 1,00 ART**.
> Depuis la base 0,35 le calcul donne 1,05 → ramené à **1,00**. Toute base ≥ 0,334 plafonne donc
> également à 1,00 : **le critique de dos ne dépasse jamais 1,00 ART**, quelle que soit la force
> du coup spécial employé.

#### Dégâts de chute

| Cas | Règle |
|---|---|
| Seuil de déclenchement | À partir de **3,00** de hauteur de chute |
| Avec bouclier | **1 % de bouclier** par tranche de **0,015** de hauteur supplémentaire *(scaling possible, variable selon la pente)* |
| Sans bouclier | **1 cran de vie** tous les **0,15** de hauteur — seuil à **3,00** sans bouclier, **4,50** si le bouclier a d'abord été consommé |

**Repères calculés :**

| Situation | Hauteur |
|---|---|
| Premier dégât | **3,00** |
| Bouclier entièrement vidé | **4,50** *(3,00 + 100 × 0,015)* |
| Mort sans bouclier | **5,25** *(3,00 + 15 × 0,15)* |
| Mort avec bouclier plein | **6,75** *(4,50 + 15 × 0,15)* |

> À l'échelle du saut (1,00 unité ≈ 2,25 m), le premier dégât tombe vers **6,75 m** de chute et le
> seuil létal vers **15 m**. Le seuil de 3,00 vaut **trois hauteurs de saut** — une valeur que le
> wall jump et les impulsions Hornet dépasseront couramment.

---

## 2. Schéma de commandes

### Manette

| Bouton | Fonction |
|---|---|
| **Stick gauche** | Se déplacer |
| **Stick droit** | Déplacer la vision / le viseur |
| **Tap stick droit** | **Mêlée principale (Mêlée 1)** |
| **LT** | Viser / mise en joue — valable pour les objets de lancer et les consommables |
| **LT** *(Dual Handling)* | Tirer avec la seconde arme |
| **LT** *(Dual Handling + objet de lancer / consommable équipé)* | Tirer avec l'arme secondaire, main gauche |
| **LB** | **Booster Hornet** |
| **RT** | Tirer *(Dual Handling : tirer avec l'arme principale)* |
| **RT** *(objet de lancer équipé)* | Jeter l'objet / la grenade / le consommable |
| **RT** *(Dual Handling + objet de lancer)* | Jeter l'objet équipé dans la **main droite**, via flèche gauche ou droite |
| **RB** | **Mêlée 2** |
| **A** | Sauter |
| **B** | Se baisser |
| **X** | Recharger |
| **Maintenir X** | **Système secondaire d'arme** — toujours une **arme à batterie** (décharge contrôlée, préparation du tir railgun du Fusil Focus…). Détail arme par arme dans `equilibrage-sandbox-armes.md` |
| **Y** | Interaction · hors interaction : changer d'arme |
| **Maintenir Y** | Échanger une arme |
| **Flèche bas** | Utiliser l'équipement d'armure *(commande alternative : tap stick gauche)* |
| **Flèche droite** | Équiper / changer de grenade |
| **Flèche gauche** | Équiper / déséquiper un consommable |
| **Flèche haut** | Allumer la lampe |
| **Maintenir flèche haut** | Afficher l'objectif |

---

### Maniement — précisions

#### Déplacement au sol

Vitesse de base **1,00**, avec **inertie**.

| Règle | Détail |
|---|---|
| Accélération | Toujours **2 pas** (0 → 1,00) |
| Décélération | Toujours **2 pas** |
| Changement de direction | Les deux pas d'inertie servent à **reconduire** la vitesse (ex. : cesser d'avancer pour straffer) |
| **Défaut majeur assumé** | Yumiko est **plus facile à viser** pendant ces deux pas |

**Le sous-virage.** La règle s'applique aussi au **changement d'angle de visée** : un joueur
clavier/souris à haute sensibilité qui pivote instantanément à 90° tout en avançant subit deux pas
de **sous-virage**. L'effet est **moins sensible à la manette**.

> **La caméra n'est jamais bloquée.** Elle tourne **dès la frame 1** — le sous-virage réduit sa
> vitesse angulaire par seconde, il ne suspend pas le contrôle. Le cas de la **charge Spartane**,
> conçue comme une course linéaire, applique la contrainte la plus forte : la caméra y tourne
> plus lentement, mais elle tourne.

#### Grenades

Équiper la grenade ou le consommable, puis **RT** pour s'en servir. **Viser (LT)** allonge la portée :
le jet est **moins en cloche et plus tendu vers l'avant**.

**Y** ramène à l'arme — ou aux armes, si le Dual Handling était actif — précédemment équipée.

#### Booster

**LB** pour employer les propulseurs. C'est la mécanique **à la base de toute la mobilité** de Yumiko.

**La direction des deux sticks influe sur la direction dans laquelle les boosters appliquent leur force.**

---

## 3. La Charge Spartane

**Ce qui remplace le sprint.** Utiliser les boosters pendant la marche pour atteindre une vitesse de
course supérieure. Une fois engagée, Yumiko **maintient la Charge sans maintenir LB ni le stick gauche**.

Les vitesses fonctionnent en **paliers d'inertie**.

### Les deux paliers

| | **Palier 1** | **Palier 2** |
|---|---|---|
| Vitesse | **1,10** | **1,25** |
| Coût | **Aucun** | Boosters allumés en permanence |
| Durée | **5 s maximum** | **Illimitée** |
| **Bouclier (cinétique)** | **135 %** | **175 %** |
| Sur-boucliers | Le bonus s'applique | Le bonus s'applique |

**La cinétique améliore le bouclier** : elle réduit les dégâts reçus. Le bonus s'applique également
aux sur-boucliers.

> ⚠️ **Valeur en conflit :** la consommation du Palier 2 est donnée à **2 %/s** dans la description
> des paliers, et à **1,50 %/s** dans la section « maintien ». À trancher.
> *(2 %/s → 50 s de course sur barre pleine ; 1,50 %/s → 66,7 s.)*

#### Budget de survie par palier

| Palier | Vitesse | Bouclier | PV | **Total** | Gain |
|---|---|---|---|---|---|
| **0** — marche | 1,00 | 1,00 | 1,50 | **2,50 ART** | — |
| **1** — charge | 1,10 | 1,35 | 1,50 | **2,85 ART** | **+14 %** |
| **2** — charge max | 1,25 | 1,75 | 1,50 | **3,25 ART** | **+30 %** |

---

### Entrer en Charge

| Entrée | Effet |
|---|---|
| **LB + stick avant**, vitesse ≥ 0,75 | Propulse la course à **1,10** — Palier 1 |
| **LB + stick avant**, vitesse < 0,75 | Accélération instantanée (**1 seul pas**) vers la vitesse normale |
| **Maintenir LB** plus longtemps | **2 pas d'accélération supplémentaires** → vitesse **1,25**, Palier 2 |
| **Tap LB + stick latéral** | Change de direction en **1 seul pas** : passe de la marche avant au **straff à 1,00** |

### Freiner et sortir

| Entrée | Effet |
|---|---|
| **Tap LB + stick arrière** | Passe de **1,00 à 0,00** |
| *(le même tap)* | Réduit de **2 paliers** l'inertie de la charge — freinage 1,25 → 1,00 |
| Diriger le stick **pendant les frames de freinage rapide** | **Redirige l'inertie** et passe en straff |
| **Maintenir** encore | Freine jusqu'à 0,00, puis **marche arrière** |
| **Palier 1 ou 2 + stick arrière** | Freine jusqu'au retour à **1,00** |

---

### Maintenir la Charge

| État | Comportement |
|---|---|
| **Palier 1 + rien** | Maintient 1,10 · pas de booster · **5 s**, puis ralentissement progressif et retour en marche |
| **Palier 2 + rien** | Maintient 1,25 · booster permanent · **1,50 %/s** *(voir conflit ci-dessus)* |

#### Course oblique — Palier + stick latéral

Maintient la vitesse de course et straffe légèrement : **course en ligne droite légèrement oblique**.

| Palier | Angle par rapport à la ligne de course neutre |
|---|---|
| **Palier 1** | **35°** |
| **Palier 2** | **15°** |

> Plus la vitesse est haute, moins l'oblique est ouverte : la charge se raidit à mesure qu'elle
> accélère.

---

### Le virage — Palier + stick droit latéral

Tourne la visée (**pivot du personnage**) : changement progressif de direction, **vitesse angulaire
indépendante du réglage de sensibilité**.

| Palier | Vitesse de pivot | Sous-virage |
|---|---|---|
| **Palier 1** | **60°/s** | Compensé en **3 pas** |
| **Palier 2** | **47,5°/s** | Compensé en **3 pas** |

#### Manœuvres avancées — compenser avec le stick gauche

Pendant un virage, pencher le **stick gauche** latéralement pour compenser les angles limités :

| Stick gauche | Effet sur le sous-virage | Vitesse de pivot P1 | Vitesse de pivot P2 |
|---|---|---|---|
| **Intérieur du virage** | Compense **2 pas sur 3** | 60° → **47,5°/s** | 47,5° → **35°/s** |
| **Extérieur du virage** | **Augmente** le sous-virage, Yumiko se laisse déporter | 60° → **85°/s** | 47,5° → **65°/s** |

**Temps de pivot calculés :**

| Configuration | 90° | 120° | 180° |
|---|---|---|---|
| Palier 1 — intérieur | 1,89 s | 2,53 s | 3,79 s |
| Palier 1 — neutre | 1,50 s | 2,00 s | 3,00 s |
| **Palier 1 — extérieur** | **1,06 s** | **1,41 s** | **2,12 s** |
| Palier 2 — intérieur | 2,57 s | 3,43 s | 5,14 s |
| Palier 2 — neutre | 1,89 s | 2,53 s | 3,79 s |
| Palier 2 — extérieur | 1,38 s | 1,85 s | 2,77 s |

#### Les deux combinaisons

**« Interne → externe » — le DRIFT.** Maximise le sur-virage. Yumiko **dérape au sol** en posture
plus basse — ce qui permet d'**esquiver par le bas les projectiles hauts et les tirs de précision**.
En changeant de direction, elle **perd 1 niveau d'inertie après 120° d'angle**. Utile pour un
**demi-tour rapide** ou un **virage en épingle**. Basculer le stick droit dans l'autre sens pour se
projeter en virage dans la direction opposée.

**« Externe → interne » — l'IMPULSION.** Se projette **à l'intérieur du virage** en course basse, en
utilisant le haut du corps pour donner l'impulsion, et prend immédiatement de l'angle. Se combine
avec une compensation externe pour **prendre très rapidement de l'angle**.

---

### Agir pendant la Charge

| Entrée | Disponible |
|---|---|
| **A** | Sauter |
| **X** | Recharger |
| **Y** | Changer d'arme |
| **Mêlée 1 / Mêlée 2** | Coup de mêlée |
| **LT** | **Viser pendant la charge** — stick droit pour tourner la vue jusqu'à **105° d'angle périphérique de chaque côté** |
| **RT** *(pendant visée)* | Tirer |

> **La Charge ne verrouille rien.** Toutes les actions restent disponibles ; la visée dispose d'un
> **cône périphérique de 105°** de chaque côté, indépendant du pivot du corps.

---

## 4. Mêlée 1 et Mêlée 2

**Cas général :** **RB** et **tap stick droit** ont le **même effet** — déclencher une attaque de
mêlée. La redondance existe pour **soulager l'exécution** quand les combos sont rapides.

**Armes de corps à corps :** avec l'**Épée à Énergie**, le **Marteau Antigravité** et la **Lance
Spartane**, les deux boutons **ne donnent pas le même coup** — d'où beaucoup plus de variation dans
les combos. *Chacune aura son schéma de commandes dédié.*

Vaut également pour les armes à **outil intégré** (lames) — exemple : le **Sabre Grenade**.

---

## 5. Consommation et recharge des boosters

### Consommation en continu

Les boosters peuvent rester allumés. La consommation est **progressive** :

| Seconde d'activation | Coût | Cumul |
|---|---|---|
| 1ʳᵉ | **8,00 %/s** | 8,0 % |
| 2ᵉ | **10,50 %/s** | 18,5 % |
| 3ᵉ | **15,00 %/s** | 33,5 % |

> **3 secondes de booster continu consomment un tiers de la barre.** À l'inverse, une impulsion de
> 0,25 s ne coûte que **2 %** : la barre pleine vaut environ **50 impulsions courtes**. La courbe
> punit le maintien, pas la fréquence.

### Recharge

| Condition | Taux | Barre pleine |
|---|---|---|
| Cooldown avant recharge | **2 s** sans utiliser les boosters | — |
| **Passif** | **0,50 %/s** | 200 s |
| **En marchant** *(conversion cinétique à plein potentiel)* | **3,00 %/s** | 33 s |
| **Après régénération du bouclier** | **10,00 %/s** | 10 s |

> ⚠️ **Valeur en conflit :** la section R3 donne une recharge nominale de **2,50 %/s**. Elle est ici
> remplacée par **0,50 %/s passif** et **3,00 %/s en marchant**. À trancher — la valeur R3 est
> probablement caduque.

> **La marche est la posture de récupération.** ×6 par rapport à l'immobilité : rester planté ne
> recharge quasiment rien. C'est cohérent avec D10 — la vitesse ne s'active pas, elle se pilote,
> et l'arrêt n'est jamais une position de repos.

---

## 6. Matrice des combinaisons

> **Statut de la couche.** C'est la partie la plus **émergente** du design. Un joueur peut s'en passer ;
> elle transforme une run légendaire en **danse**, et les phases de dive / désengagement en **jeu dans
> le jeu**. La charge cognitive est **assumée** : tous les joueurs ne seront pas égaux devant elle.
> Ce Halo reste compréhensible, mais comporte **le plus de mécaniques émergentes qu'on ait vues**.

### 6.1 — Parade

| Point | Détail |
|---|---|
| Entrée | **Mêlée 1**, **Mêlée 2**, ou **1+2** |
| Condition | **Uniquement avec une arme de corps à corps équipée** |
| Effet | Dévie l'attaque de l'ennemi **s'il dispose lui aussi d'une arme de CAC** ; retour au neutre après entrechoquement |
| **Mêlée 1+2** *(tip avancé)* | Recovery **avec des frames d'avance** : le retour au neutre devient un **avantage de frames à l'attaque** |

---

### 6.2 — L'échelle de mêlée

Toutes les valeurs de mêlée du personnage se rangent sur **cinq crans** :

| ART | Coups concernés | Condition |
|---|---|---|
| **0,20** | Leg Breaker | Depuis un slide |
| **0,35** | Mêlée de base · Demi-tour frappe | Référence D14 — **seule base plafonnée** |
| **0,50** | Emplafonnement · Bastonneur · Uppercut | Vitesse 1,01–1,10 / Palier 1 |
| **0,65** | Versions **critiques** de ces trois coups | Vitesse ≥ 1,10 *(1,11 pour l'Emplafonnement)* |
| **0,80** | Mêlée aérienne au-delà du Palier 2 | Vitesse > 1,25 en l'air |

> **Critique dorsal — D14 révisée.** Il traverse bouclier, armure et blindage, et **remplace** cette
> échelle au lieu de s'y cumuler.
>
> | Base frappée | Résultat |
> |---|---|
> | **0,35** *(mêlée de base ou assimilée)* | ×3 → **1,00 ART, plafonné** |
> | **Toute autre base** | **×3,00 fixe appliqué à cette base — aucun plafond** |
>
> Le plafond de 1,00 **n'a jamais été une limite universelle** : il ne concerne que la mêlée de base.
> Un coup dorsal parti d'une base de 0,65 vaut donc **1,95 ART**, et non 1,00.

---

### 6.3 — Coups liés à la vitesse

#### Emplafonnement — *Palier 1 ou 2 + Mêlée*

| Point | Détail |
|---|---|
| Condition | Être en vitesse de charge : **1,01 à 1,10**, ou Palier 1 *(post-dash avec booster)* |
| Puissance | **0,50 ART** |
| **Palier supérieur** | À partir de **1,11** de vitesse *(pendant le Palier 2)* → **0,65 ART** |
| Effet | **WALL SPLAT même sur un ennemi encore protégé** (blindage / armure / bouclier) |
| Animation | Coup de crosse ou coup d'épaule |

#### Bastonneur — *Direction 22,5° à 67,5° + Mêlée*

| Point | Détail |
|---|---|
| Effet | Coup de mêlée **en se décalant sur le côté** — animation différente selon le côté |
| Stun | Sur les ennemis **non protégés** |
| **Position finale** | **Yumiko atterrit DOS à l'ennemi frappé** |
| Puissance | **0,50 ART** jusqu'à 1,09 de vitesse · **0,65 ART** critique à partir de **1,10** |

#### Demi-tour frappe — *Tap stick gauche arrière + Mêlée*

| Point | Détail |
|---|---|
| Effet | Se retourne et envoie un coup de mêlée classique à **0,35 ART** |
| Compensation | Pas de puissance supplémentaire, mais **wall splat / stun vers l'arrière** sur n'importe quel ennemi |
| Exceptions | **Hors Hunters, hors Dévots** |

> ### Le combo signature
>
> **Bastonneur critique (0,65) → Demi-tour frappe (0,35) = 1,00 ART.**
> Le Bastonneur laisse Yumiko **dos à l'ennemi** ; le demi-tour frappe est donc l'enchaînement naturel.
> **1,00 ART = exactement la chair d'un Elite Minor.** Le seuil est conçu, pas fortuit.

#### Uppercut — *(accroupi) Se relever OU Sauter + Mêlée*

| Version | Puissance | Effet |
|---|---|---|
| **Uppercut** | **0,50 ART** | Ne stun **pas**, sauf cible sans protection · peut **Wall Splat** |
| **Uppercut critique** *(se relever → sauter + mêlée)* | **0,65 ART** | **Stun** · wall splat sur cible non protégée · assorti d'un **saut de hauteur normale** |

**Animation :** coup de crosse vertical ascendant, ou uppercut du poing gauche — arme tenue à une main
(droite). **Dual handling : non disponible** *(en version simple)*. En **dual handling ou arme lourde** :
uppercut en sautant **+ coup de genou**. **Arme de CAC** : animation et équilibrage dédiés.

> **PASSIF — Drain de bouclier.** Contre les cibles équipées, l'uppercut **draine l'équivalent en %
> d'une attaque de mêlée**, soit **35 %**.

---

### 6.4 — Aérien

#### AIR + Impulsion — *AIR + LB + Direction*

Boosters utilisables **pendant les sauts**. Équilibrage :

| Cas | Résultat |
|---|---|
| Sauter sur place puis accélérer dans une direction | Équivaut à **sauter en marchant à 1,00** |
| Sauter à **1,25** et impulser **vers l'arrière dès la frame 1** | Réduit la vitesse à **0** à la retombée |
| **Vitesse aérienne max** | **1,35** — ralentissement progressif **en 4 s** jusqu'à 1,35, **sans consommer de boost** (Yumiko est au-delà de ses limites, elle ralentit d'elle-même) |
| Mêlée pendant le dépassement du Palier 2 | Passe à **0,80 ART** de référence |

#### Impulsion haute — *Direction + LB + A*

| Point | Détail |
|---|---|
| Effet | **+0,25 de hauteur de saut**, en **conservant le momentum** dans la direction donnée |
| Suite | Le joueur peut enchaîner **AIR + LB** pour accélérer en saut *(modifie les valeurs d'équilibrage)* |
| Statut | **Outil de mobilité avancé** |

#### Wall Jump — *En l'air, toucher le mur + A*

| Point | Détail |
|---|---|
| Effet | Saute **dans la direction visée** |
| Bonus de vitesse | **+0,25 fixe** — permet de **dépasser le plafond du Palier 2** jusqu'à +0,25 |
| Vitesse minimale requise | **0,85** |
| Angle de réajustement max sans perte de vitesse | **35°** |
| Hauteur gagnée | **+0,25** |
| Propriété | Mouvement à effet **« transmission »** |

> ⚠️ **Conflit de plafond :** la vitesse aérienne max est donnée à **1,35**, mais Palier 2 (1,25) +
> wall jump (+0,25) = **1,50**. À trancher : le wall jump perce-t-il le plafond, ou est-il écrêté ?

#### Wall Breaker Stance — *En l'air, toucher le mur + B*

Utilise la stance Breakers **accrochée au mur**. **Un seul effet principal :** pouvoir diriger le saut
de la BRS (**BRS + A**) **à l'horizontale depuis le mur**, et donc gagner beaucoup de hauteur.

> La vitesse horizontale du saut **BRS + A** est de **1,35**. Idéal pour obtenir, à la moindre
> impulsion, vitesse horizontale **et** verticale — pour un **slide critique**.

---

### 6.5 — Le forçage de boosters

#### Impulsion + X — *LB + X*

**Forçage-Boosters** (fonctionne aussi en déplacement). Consomme **l'intégralité du bouclier,
over-bouclier compris**, pour enclencher la recharge des boosters.

| Effet | Détail |
|---|---|
| Conversion | **1 % de recharge pour 10 % de bouclier** |
| Recharge | Enclenche la recharge accélérée **10 %/s**, **sans cooldown** |
| **Invulnérabilité** | **0,50 s** au déclenchement — outil de **temporisation** |
| Repoussée | Repousse les ennemis proches, comme la **grenade à impulsion sans l'EMP critique** — même effet que l'impulsion du Break Stance |

#### Impulsion en course — *Pendant course (latérale ou charge) + LB + X*

Animation de **slide raccourcie**, puis forçage booster. **Vers l'avant**, le slide est plus long
(le temps du freinage, selon le palier de vitesse atteint). **Comme le slide, cancellable en se déplaçant.**

#### Direct Break Stance — *Impulsion + X puis B*

| Point | Détail |
|---|---|
| Timing | Appuyer **B pendant les 0,50 s d'invulnérabilité** du forçage |
| Coût | **100 % du bouclier**, mais **pas l'over-bouclier** de la BRS (si le passif est disponible) |
| Statut | Outil de **calibration du risque**, **high skill ceiling** |

---

### 6.6 — Pas-chassé — *Direction 35° à 125° (straff boosté) + B*

| Point | Détail |
|---|---|
| Animation | Buste effectuant une **vague vers le bas** |
| Effet défensif | **Esquive les coups hauts**, dont les **tirs de précision** |
| Effet offensif | **Accélère momentanément la vitesse latérale** — brouille l'anticipation ennemie, **perte de ciblage des têtes chercheuses** |
| Recovery | Relevée du buste **annulable** par un saut, un autre mouvement de booster… **ou un uppercut**, Yumiko étant considérée comme **accroupie** |
| Synergie | Permet de rendre le **Bastonneur critique** via impulsion latérale |

---

### 6.7 — Le slide

#### Arrêt brutal — *Pendant Charge (Inertie 1 min.) + B*

Pied à plat au sol, arrêt en glissant. **Cancellable par le stick gauche** pour reprendre la marche
dans n'importe quelle direction sans inertie. **Valable pour TOUTES les occurrences de slide**, même
incluses dans d'autres animations.

#### Options de sortie du slide

| Sortie | Entrée | Effet |
|---|---|---|
| **Saut** | **A** | Saute, **conserve le momentum** actuel (compte tenu du ralentissement encaissé) |
| **Uppercut** | **A + Mêlée** | Voir Uppercut — sortable depuis le slide |
| **Redirection** | Stick droit *(réajustement)* puis **LB** | **80° de débattement de chaque côté** · redirige une charge depuis un slide · **1 s = revient toujours à 1,10** |
| **Mêlée basse** | **Mêlée 1 ou 2** | Pied glissant comptant comme attaque de mêlée. **Ne peut pas reprendre la charge**, mais reprend la **marche** (direction libre sans inertie, **sauf vers l'arrière** — les 180° derrière Yumiko). Recovery par **A** ou **booster manuel** (réengage une course) |

#### Leg Breaker — *Slide + Mêlée 1 ou 2*

| Point | Détail |
|---|---|
| Effet | Coup de pied bas, **stun dédié**, gagne des **frames d'avantage** |
| Particularité | **N'interrompt pas l'animation de slide** |
| Coût | **4,5 % de boost** |
| Puissance | **0,20 ART** |
| **CRITIQUE** | **0,65 ART** — et **ne consomme aucun boost** |

#### Leg Breaker — armes de CAC — *Slide + Mêlée 2*

Nécessite une arme disposant d'un **pattern de corps à corps** (épée à énergie, marteau, Lance Spartane).
**Ne consomme aucun boost.** Dégâts variables selon l'arme : **multiplicateur des dégâts type Mêlée 1
de l'arme × 1,35**.

#### Cancels du slide / Leg Breaker

| Entrée | Effet |
|---|---|
| **Stick gauche** | Marche |
| **LB** | Reprend la charge dans une direction de **−105° à +105°** |
| **B** | **BRS Stance** |
| **Ne rien faire** | Fin de recovery **accroupie** — idéal pour enchaîner un **uppercut** |

> Le joueur peut **enchaîner les cancels** après la frappe de Leg Breaker, et continuer d'enchaîner.

#### Combo Slide → Impulsion — *Slide + LB (+ stick droit optionnel)*

Ré-accélère depuis la vitesse V au moment de l'appui pour **reprendre rapidement une vitesse de charge**
tout en réajustant sa direction : **−75° à +75°**.

---

### 6.8 — BREAK STANCE (BRS)

**Se pose solidement sur ses appuis, boosters enflammés**, prête à utiliser une des options de sortie.

| Point | Valeur |
|---|---|
| **Durée de la stance** | **0,75 s** |
| **PASSIF 1 — Over-bouclier** | **+35 %** provisoire · permet de **régénérer le bouclier abîmé** · nécessite un **retour au neutre** · utilisable **1 seule fois** · **cumulable** avec l'overboost de l'impulsion |
| **PASSIF 2 — Over-boost** | **+25 %** · retour au neutre pour le récupérer · s'applique aux cancels **BRS + B**, **BRS + A**, **BRS + Mêlée 1** |

#### Sorties de la BRS

| Entrée | Nom | Effet |
|---|---|---|
| **BRS + B** | **Cancel** | Retour en posture debout neutre · **+4,5 % de boost** · **PASSIF :** conserve l'over-bouclier même s'il déborde des 100 % *(ne régénère pas au-delà de 100 %)* · **non cumulable**, nécessite retour au neutre |
| **BRS + stick gauche arrière** | **Demi-tour 180°** | Vise directement derrière Yumiko, **reste accroupie** · Mêlée pour utiliser le coup en demi-tour |
| **BRS + stick gauche (toute direction) + LB** | **Dash-Cancel** | Sort par une impulsion · **reprise très rapide à 1,00** dès les premières frames |
| **BRS + stick droit** | **Bouger le viseur** | Yumiko peut viser avec **LT** depuis la BRS ; le stick droit bouge la vision. Très utile pour viser après un **slide Leg Breaker → BRS demi-tour** |
| **BRS + LT / RT / Mêlée** | **Viser / Tirer / Mêlée** | Mouvements de base disponibles depuis la stance |
| **BRS + A** | **Jump Cancel** | **−4,5 % de boost** · saut à **1,25** de hauteur · **donne l'effet CRITIQUE si l'uppercut est performé** |
| **BRS + Mêlée 1** | **Impulsion** | Impulsion courte portée · consomme **35 % de bouclier** *(équivalent EMP)* · **pas de dégâts IEM critiques** · inflige le coup de mêlée de base dans un **rayon de 2,50 m**, par onde de choc identique à la grenade à impulsion |
| **BRS + Mêlée 2** | **Break Uppercut** | Uppercut non critique · consomme **l'over-bouclier uniquement au-delà de 100 %** · enclenche la **régén du boost sans attendre le cooldown de 1,5 s** *(régén instantanée, disparaît à l'usage d'une autre capacité)* |
| **BRS + A + Mêlée 1** | **Impulsion critique** | Saute **en infligeant l'impulsion** · donne l'**over-boost** |
| **BRS + A + Mêlée 2** | **Break Upper critique** | Donne l'**over-boost** · puissance de l'upper portée à **0,65 ART** |
| **BRS + flèches du pad** | — | Voir schéma de commandes §2 |

---

### 6.9 — Lectures chiffrées

#### Économie du boost

| Action | Boost |
|---|---|
| **BRS + B** (cancel) | **+4,5 %** — *génère* |
| **Over-boost BRS** | **+25 %** *(1 fois par retour au neutre)* |
| **Forçage LB+X** | **+10 %** *(bouclier plein)* + régén 10 %/s sans cooldown |
| BRS + A (jump cancel) | −4,5 % |
| Leg Breaker | −4,5 % |
| **Leg Breaker critique** | **0 %** — gratuit |

> **La boucle BRS + B / BRS + A est neutre en boost.** Le cancel rend exactement ce que le jump cancel
> consomme. Le joueur qui maîtrise la stance ne paie pas sa mobilité — il la fait tourner.
> Cumul théorique maximal en une séquence : **39,5 %**.

#### Budget de survie avec over-bouclier BRS

| Palier | Bouclier | + over 35 % | + PV | **Total** |
|---|---|---|---|---|
| 0 — marche | 1,00 | 1,35 | 1,50 | **2,85 ART** |
| 1 — charge | 1,35 | 1,70 | 1,50 | **3,20 ART** |
| **2 — charge max** | 1,75 | **2,10** | 1,50 | **3,60 ART** |

> En Palier 2 avec over-bouclier, Yumiko atteint **3,60 ART** — soit **0,96× un Spec-Ops**. Le plafond
> défensif du personnage se situe donc juste sous l'élite intermédiaire du Covenant, et **uniquement en
> mouvement**.

---

*Suite du document en attente : modificateurs de dégâts reçus, schémas de commandes des armes de
corps à corps (Épée à Énergie, Marteau Antigravité, Lance Spartane).*
