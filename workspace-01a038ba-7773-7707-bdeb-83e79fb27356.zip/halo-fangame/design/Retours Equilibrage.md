# Retours Équilibrage

*Observations analytiques de l'assistant, consignées au fil des livraisons de fiches.*
*Ce document ne contient **aucune transcription** de fiche d'arme : les chiffres bruts vivent dans `equilibrage-sandbox-armes.md`, la doctrine dans `base-de-travail.md`. Ici, uniquement des lectures, des jugements et des recommandations.*

**Sommaire**

- [0 — Arbitrages de règles communes](#0--arbitrages-de-règles-communes)
- [I — CSNU (16 fiches)](#i--csnu--16-fiches)
- [II — Covenant / Élites (12 fiches)](#ii--covenant--élites--12-fiches)
- [III — Brutes / Jiralhanae (12 fiches)](#iii--brutes--jiralhanae--12-fiches)
- [IV — Forerunner / Sentinelles (4 fiches)](#iv--forerunner--sentinelles--4-fiches)
- [V — Synthèse des quatre factions](#v--synthèse-des-quatre-factions)
- [VI — Ce qui reste dû](#vi--ce-qui-reste-dû)

---

## 0 — Arbitrages de règles communes

*Sept points qui ne relevaient d'aucune fiche en particulier mais qui décidaient du sens de plusieurs d'entre elles. **Les sept sont tranchés.** Ce qui suit est la décision de l'auteur, pas ma recommandation : elle fait foi et a été répercutée dans les fiches.*

| # | Objet | **Décision de l'auteur** | État |
|---|---|---|---|
| **R1** | **CAC des armes fixes** *(§0.6)* | **0,55 ART = base de la catégorie et valeur de Mêlée 1** ; **0,75 = Mêlée 2 uniquement** *(l'arme est jetée en avant)*. **Des exceptions existent, arme par arme** — l'**Estoc Plasma de la Tourelle Plasma est à 1,333 ART** | ☑ |
| **R2** | **Report de DPS** *(§0.4)* | **Aucune exception.** Une arme à malus chair ne reporte pas « à 25 % » : elle subit son **malus normal** parce que le report tombe sur de la chair non protégée | ☑ |
| **R3** | **Dégressivité du feu** *(§0.3)* | **Supprimée.** Un feu ravivé brûle comme un feu initial — plus de courbe 100 → 80 → 60 %, plus de plancher ×0,10 | ☑ |
| **R4** | **Cumul des zones au sol** | **Pas de cumul, pas de fusion : remplacement.** Allumer un feu sur une zone déjà allumée **remplace** le foyer précédent | ☑ |
| **R5** | **Plafond D14** | Le plafond **1,00 ne concerne que la mêlée de base (0,35)** ou une base assimilée. **Si la base change, le multiplicateur devient ×3,00 fixe sur cette nouvelle base, sans plafond.** Ce ne fut jamais une limite universelle | ☑ |
| **R6** | **Hybridations de classe** | **Voulues et justifiées au cas par cas.** Il n'existe **pas une règle unique** mais **deux verrous distincts** — *interdiction de port* et *pénalité de mobilité* — et **chaque fiche déclare lequel elle porte**. Promu en doctrine sous **D16** *(`base-de-travail.md`)*, qui porte la table complète des **7 armes concernées et des 2 exceptions** | ☑ |
| **R7** | **Déclenchement du Flash** | **Pas de liste fermée par faction.** La fiche Flash porte désormais : *« d'autres armes peuvent allumer l'explosion Flash, voir fiches individuelles le précisant »* — une arme non-Forerunner l'allume **si sa propre fiche le mentionne** | ☑ |

**Deux règles nouvelles sont nées de ces arbitrages** et vivent désormais dans `equilibrage-sandbox-armes.md` :

| § | Règle |
|---|---|
| **§0.8** | **Un critique qui s'applique aux CASQUES s'applique aussi, au même multiplicateur, aux ARMURES.** Concerne aujourd'hui le M739 SAW |
| **§0.9** | **Le souffle d'une explosion éteint un feu d'un seul coup**, au sol comme sur un ennemi. **8 armes** : frag, M319, M41, Marteau Antigravité, Déchiqueteur, Sabre Grenade, Grenade Dynamo, toute explosion Dynamo |

### 0.1 — Ce que ces décisions changent dans mes lectures

**R2 corrige une erreur de lecture de ma part**, et je la signale parce qu'elle contaminait deux sections. J'avais lu une mise en situation VS Élite Minor comme la preuve d'un report à taux réduit propre à une arme. Elle illustrait l'inverse : les 0,20 ART restants après chute du bouclier (sur un critique valant 0,60) subissent le **malus ×0,25 ordinaire**, parce qu'ils touchent de la chair. **§0.4 n'a donc aucune exception**, et le point ㉕ tombe.

**R3 + R4 réduisent le système de feu à deux lignes** au lieu d'un sous-système. Plus de dégressivité, plus de cumul : un feu est **actif ou éteint**, à pleine puissance, et le dernier allumeur écrase le précédent. Ajouté au §0.9, ça donne un système qui se décrit intégralement en trois phrases — c'est un gain de lisibilité considérable pour une mécanique portée par **onze armes**.

**§0.9 change la doctrine Brute plus que R3.** J'écrivais que « deux armes de la faction éteignent le feu » comme une anti-synergie élégante. Ce n'est plus une anti-synergie interne : **cinq armes sur deux factions** éteignent, dont trois CSNU. Le feu passe de *ressource d'escouade Brute* à *ressource contestée par tout le monde*. La lecture reste bonne, mais elle change de nature : ce n'est plus une bizarrerie Brute, c'est le **contre-jeu générique du feu**, et il faudra que le joueur le découvre tôt.

**R5 rend D14 plus généreuse, pas moins.** Je recommandais le plafond après bonus, par crainte que la promesse faite au joueur se dilue. L'auteur tranche autrement, et sa formulation est plus solide que la mienne : le plafond n'était pas une promesse sur la mêlée, c'était **le résultat arithmétique de ×3 sur 0,35**. Une base différente donne un résultat différent. Conséquence concrète : un coup dorsal parti d'une base de 0,65 vaut **1,95 ART**, soit 78 % de Yumiko. À surveiller au playtest — c'est le seul des sept qui ouvre un plafond au lieu d'en fermer un.

**R6 ferme le point ㉞ autrement que prévu.** Je voulais nommer une catégorie unique « armes sans spéciale ». La réponse est qu'il n'y a **pas de catégorie** : chaque hybridation est un choix éditorial distinct, et **deux verrous différents coexistent** — *interdiction de port* et *pénalité de mobilité en duo ambidextre*. C'est plus fin, et ça évite d'afficher au joueur une règle qui aurait été fausse dans la moitié des cas. **La répartition arme par arme est désormais tenue par D16**, pas ici : cinq armes interdisent le port, deux taxent la mobilité, deux font exception.

---

## ★ MATRICE DES EFFETS ET CONTRÔLES — reçue et transcrite

> **Transcrite en `## 5` de `equilibrage-sandbox-armes.md`**, entre les armes Forerunner et la matrice
> consolidée — l'emplacement demandé. L'ancienne `## 5` est devenue `## 6`, tous les renvois `§5.x`
> internes ont été renumérotés en `§6.x`. **Neuf sous-sections, §5.0 à §5.9.**
>
> Placé avant les arbitrages traités, comme demandé : **cette matrice rouvre des points déjà clos.**

### A — Ce qu'elle change, structurellement

La matrice fait **trois choses** que la dispersion précédente rendait impossibles.

**① Elle sépare le type d'effet de l'arme qui le porte.** C'était le vrai problème. Avant, « le feu » était
douze paragraphes dans douze fiches. Maintenant il y a **cinq types**, et chaque arme se contente de dire
*combien de tirs* elle demande pour allumer ou entretenir. **Le type porte les dégâts, l'arme porte le
coût d'accès.** C'est la bonne séparation, et elle scale — une 48ᵉ arme ne demandera qu'une ligne.

**② Elle transforme l'entretien en verbe unique.** §5.0 : entretenir = **reset du cooldown**. Ni cumul, ni
extension. Une définition, valable pour cinq types et une trentaine de sources. Avant, chaque fiche avait
sa formulation *(« +6,5 s », « double la durée », « relance »)* — trois façons de dire trois choses
différentes, dont personne n'aurait pu tirer une règle générale.

**③ Elle nomme des émergences au lieu de les laisser se produire.** Les deux lignes de §5.5 — la
propagation par les pics et la propagation de Zone Plasma par Super-Combine — **n'auraient jamais pu être
écrites dans une fiche d'arme**, puisqu'elles impliquent trois armes et deux états à la fois. C'est
l'argument le plus fort en faveur du document.

### B — La table de référence, et ce qu'elle dit

| Type | ART/s | Flaque | Brûlure | Total flaque | Total brûlure | % de Yumiko *(les deux)* |
|---|---|---|---|---|---|---|
| **Incendier** | 0,18 | 5,00 s | 3,00 s | 0,900 | 0,540 | **57,6 %** |
| **Zone Plasma** | 0,13 | 7,00 s | 3,50 s | 0,910 | 0,455 | 54,6 % |
| **Plasma Instable** | 0,16 | 4,50 s | 2,50 s | 0,720 | 0,400 | 44,8 % |

☑ **Post-combustion du Plasma Instable** *(note auteur, écrite en §5.2)*. Sur une tentative d'allumage
**non aboutie** : **cooldown de 2,00 s** — salve suivante en deçà, **le décompte reprend où il en était**,
et **aucune brûlure** pendant le cooldown. À 2,00 s écoulées, **reset**, signalé par une **micro-brûlure
résiduelle** : **0,05 ART/s × 1,50 s = 0,075 ART**, sur touche directe / armure / blindage, **jamais à
travers un bouclier**. La brûlure est donc le **témoin visuel du reset**. **Une fois l'allumage fait, on
passe aux statistiques de base du Plasma Instable** *(0,16 ART/s, 2,50 s)*.
| **Combustible** | 0,175 | **10,00 s** | 2,00 s | **1,750** | 0,350 | **84,0 %** |
| **Lumière** | 0,11 | **Aucune** | **5,00 s** | — | 0,550 | 22,0 % |

**L'échange intensité / durée est bien tenu.** Incendier est le plus violent et l'un des plus courts ;
Lumière le plus faible et le plus long. Les **totaux de brûlure tiennent dans une bande de 0,35 à 0,55** —
le pire type vaut les deux tiers du meilleur. **Aucun type n'est un piège**, aucun n'est un choix évident.
C'est exactement la compression qu'il faut pour que cinq éléments restent distincts sans être hiérarchisés.

**Et les durées racontent les factions sans une ligne de texte** : Combustible 10 s au sol / 2 s sur cible
*(le CSNU pose du terrain)* · Lumière 0 s au sol / 5 s sur cible *(les Forerunner marquent des individus)*
· Zone Plasma 7 s / 3,50 s *(les Covenant tiennent l'espace)*. **Quatre doctrines lisibles dans deux
colonnes de chiffres.**

### C — Les quatre réussites de conception

**① Le délai de 1,25 s sur la Zone Plasma est la meilleure décision de la matrice.** Un feu qui siffle et
crache des étincelles bleues avant de prendre, **toujours**, quelle que soit la source. C'est un tell
universel, gratuit à apprendre, impossible à contourner — et il **vaut dans les deux sens** : l'IA le subit
aussi, donc le piège devient jouable par le joueur. Sur un socle sans sprint, 1,25 s de lecture est le bon
dosage.

**② La permutation du Crémator est un plafond de puissance déguisé en effet de style.** Entretenir un feu
Incendier **le transforme en Lumière** : impossible d'entretenir indéfiniment le type le plus violent
*(0,18)* — l'entretien **dégrade** vers 0,11. Qui veut du Incendier durable doit changer d'outil. Très
élégant : la contrainte n'est jamais énoncée comme une règle, elle est dans la mécanique.

**③ Le tri du souffle Dynamo est la meilleure idée systémique.** Il **nourrit** Combustible et Plasma
Instable, il **éteint** Zone Plasma, Incendier et Lumière. Le même geste fait deux choses opposées selon
ce qui brûle : une grenade utilitaire devient une **décision de lecture du terrain**, et le joueur qui sait
identifier une couleur de flamme à la volée est récompensé. Deux nourris, trois éteints — le ratio est bon,
la Dynamo reste majoritairement un outil de contre-feu.

**④ Les coûts d'allumage définissent les rôles sans toucher aux dégâts.** 1 tir au Ravageur pour une zone,
16 au Fusil à Plasma Brute pour une cible, 12 au Lance-Flammes, 3 au Crémator, 2,5 au Heatwave. **Deux
armes de la même faction, deux fonctions**, sans un seul chiffre de puissance modifié. C'est de
l'équilibrage par le coût d'accès, et c'est plus fin que de l'équilibrage par le DPS.

### D — Les six points d'arbitrage : ☑ TRANCHÉS

> **Purge appliquée** *(§0.6)* : les six questions sont closes. Seul subsiste ci-dessous ce qui **engage
> la suite du travail**. Le détail est écrit dans la matrice elle-même, `## 5`.

| # | Arbitrage rendu | Écrit en |
|---|---|---|
| **①** | **Pas de plafond** sur la flaque de Combustible — **à Yumiko de sortir de la zone** | **§5.1**, encadré + table du coût par seconde passée |
| **②** | **Pas de cumul** : une flamme remplace la précédente, tous types confondus | **§5.0**, règle de non-cumul |
| **④** | **Entretien additif** : +3,00 s *(Incendier → 6,00 s)*, +4,50 s *(Lumière → 9,50 s)* | **§5.2**, lignes Laser Spartan |
| **⑥** | Heatwave **permutant** : Incendier ravivé → **Lumière** | **§5.2**, ligne Heatwave |

**Trois conséquences qui dépassent les six points.**

**① Le non-cumul plafonne le feu pour toujours, et c'est la meilleure nouvelle de cette passe.** Interdire
deux brûlures simultanées fixe le **DPS d'effet maximal du jeu à 0,18 ART/s** — soit **7,2 % du bouclier
de Yumiko par seconde**, quelles que soient les armes engagées, à 43 armes comme à 60. Le feu ne pourra
donc jamais concurrencer le tir : il reste **pression, contrôle d'espace et révélateur de position**.
**Le sommet « Tir » du triangle est protégé par construction, plus par vigilance.**

**② La sandbox est 100 % déterministe.** **Aucune des 43 armes ne tire au dé.** C'est une propriété rare et précieuse : tout échec est imputable au joueur,
donc lisible, donc corrigeable. À **inscrire comme invariant** — le jour où une arme réclamera un jet,
ce sera une rupture, pas un détail.

**③ Vos six réponses retirent des règles au lieu d'en ajouter.** Pas de cap sur le Combustible, pas de
table de cumul, pas de RNG à documenter : le contre-jeu passe du chiffre au **déplacement du joueur**.
Sur un socle **sans sprint**, quitter une flaque de 6,50 m coûte du temps réel — la zone d'interdiction
est **plus chère à traverser ici que dans n'importe quel Halo**. Le contre-jeu est lent, et c'est le bon
tempo.

**Deux corrections reçues depuis, déjà intégrées.**

| Correction | Effet |
|---|---|
| **Liste cinétique arrêtée à 5 armes** | Le **Sabre Grenade est maintenu** *(je l'avais sorti à tort)* · **Marteau Antigravité : toutes formes** · le **Déchiqueteur sort** · la **Grenade Dynamo** garde son tri propre *(§5.3)*. Écrit en **§5.4**, et l'ancien **§0.9** est marqué absorbé pour qu'il ne reste **qu'une seule liste** dans le document |
| **Lance-Flammes à double régime** | Le **jet direct garde son barème de fiche** *(1,25 → 1,50 ART/s)* ; **seuls la flaque et le résiduel** passent en Incendier. Encadré en **§5.2** et en tête de **§1.13** |

**Le Lance-Flammes tombe juste au millième, et ça vaut d'être signalé.** Ancien résiduel maximal
**0,15 × 3,60 s = 0,540 ART** ; nouveau résiduel Incendier **0,18 × 3,00 s = 0,540 ART**. **La même valeur
exactement.** Le type Incendier reproduit le sommet de l'ancien système, mais **sans exiger le cumul de
douze flammes** : même total, fenêtre plus courte et plus dense. Le joueur moyen — celui qui place quatre
à sept flammes — y **gagne**, tandis que le cas parfait ne gagne rien. C'est le bon sens de correction.

La distinction burst / résiduel était nécessaire : le burst est un **dégât d'arme**, le résiduel est un
**état**. Seul le second obéit au non-cumul, se fait souffler par les 6 cinétiques et permuter par le
Crémator ou le Heatwave. **Le jet direct ne s'éteint pas — il s'interrompt.** Sans cette ligne, une frag
bien placée aurait annulé un burst en cours, ce qui n'aurait eu aucun sens.

### D bis — Saignement : sixième type d'effet *(reçu, transcrit en §5.6)*

**Ce qu'il apporte : un axe que la sandbox n'avait pas.** Les cinq flammes sont des effets **à distance**,
posés par des armes de tir. Le Saignement est le premier effet **de corps à corps**, et il rend au sommet
« Mêlée » du triangle une profondeur que le reste du système lui refusait. Jusqu'ici, la mêlée était un
chiffre — 0,35, 0,65, 1,00 au dorsal. Elle devient une **séquence**.

**Le vrai sujet n'est pas les dégâts, c'est le marquage.** 0,125 ART de saignement générique, c'est 5 % de
Yumiko : négligeable, et c'est voulu. La valeur est ailleurs — **0,35 → 0,55 pendant 12,50 s**, soit
**+57 % sur toutes les mêlées cinétiques** contre une cible ouverte. La fenêtre dure **cinq fois plus
longtemps que la plaie** *(2,50 s)*. Ce n'est donc pas un DoT : **c'est un debuff de mêlée déguisé en
DoT**, et la lecture correcte est « une lame ouvre, un poing conclut ».

**La cautérisation est la plus belle idée de toute la matrice.** Elle relie les deux familles d'effet par
une logique physique qu'aucun joueur n'a besoin qu'on lui explique — *le feu ferme la plaie* — et elle
produit une vraie tension : **brûler une cible détruit sa propre mise en place au tranchant**. Feu et lame
ne se combinent pas, ils s'annulent. Vous obtenez gratuitement une contrainte de composition d'escouade et
un dilemme d'armement, sans une seule ligne de règle supplémentaire. Les deux exceptions incautérisables
*(Ravageur, Marteau M1)* sont cohérentes : ce sont des **broiements**, pas des coupures.

**La condition d'application est la plus stricte du jeu, et c'est le bon garde-fou.** Report de DPS oui,
mais **la plaie exige un contact intégral sur une cible sans protection**. Autrement dit : **il faut avoir
déjà gagné l'échange pour ouvrir la cible.** Le saignement ne peut donc jamais servir à *entamer* un
ennemi frais — il récompense une position déjà acquise. C'est ce qui empêche le +57 % d'être abusif.

**Les deux points sont tranchés, et la section §5.6 est close.**

| # | Arbitrage rendu | Ce qu'il produit |
|---|---|---|
| **⑦** | **Oui, D14 s'applique** : la base 0,55 diffère de la base, donc **×3,00 sans plafond** | Dorsal sur cible saignée = **1,65 ART** *(66 % de Yumiko)*, contre 1,00 plafonné |
| **⑧** | **Oui, la cautérisation annule tout** — plaie **et** fenêtre de 12,50 s | **Feu et lame deviennent mutuellement exclusifs** |

**Sur ⑦ — la chaîne d'exécution au corps à corps est maintenant la meilleure du jeu, et elle ne tue pas.**

| Étape | ART |
|---|---|
| Mêlée tranchante *(ouvre)* | 0,350 |
| Saignement *(0,05 × 2,50 s)* | 0,125 |
| Dorsal sur base 0,55 *(×3,00)* | **1,650** |
| **Total** | **2,125 — 85 % de Yumiko** |

Il reste **0,375 ART**. C'est le bon dosage : la meilleure séquence de mêlée du jeu amène une Spartane au
bord de la mort **sans l'y mettre**, et deux mêlées de face après ouverture ne totalisent que **1,575**
*(63 %)*. **C'est le dos qui paie, pas la répétition** — exactement ce qu'on veut d'un système de mêlée.

**Mais ⑦ a une conséquence que la question ne contenait pas.** D14 vaut pour **toute** base modifiée, or
cinq armes de §5.6 en portent une. En appliquant la règle jusqu'au bout :

| Arme | Base | Dorsal ×3,00 | Part de Yumiko |
|---|---|---|---|
| Ravageur · Marteau M1 | 0,50 | 1,50 | 60 % |
| Sabre Grenade | 0,65 | 1,95 | 78 % |
| Tourelle Spiker | 0,80 | 2,40 | **96 %** |
| **Tourelle Spiker** *(lancer)* | **1,05** | **3,15** | **126 % — MORT** |

**Le lancer de Tourelle Spiker en dorsal ouvre une famille neuve : les morts exactes de corps à corps.**
Les quatre recensées jusqu'ici frôlent 2,50 et s'obtiennent à distance ; celle-ci le **dépasse de 26 %**.
Elle exige un dos exposé face à un porteur de tourelle arrachée — rare et lisible — mais elle existe, et
j'ai mis à jour tous les endroits du dossier qui annonçaient « quatre morts exactes ». *(La révision du
critique en bonus additif en a depuis ajouté deux autres — voir ci-dessous.)*

**Sur ⑧ — c'est le choix le plus tranchant de la matrice, au sens propre.** Une seule flammèche, d'où
qu'elle vienne, **efface 12,50 s de préparation**. Trois effets que je souligne :

- **Le tir incendiaire d'un allié ruine l'exécution du joueur au tranchant.** En coopératif, c'est une
  contrainte de coordination réelle, et une friction que je trouve saine.
- **L'IA obtient un contre gratuit** : n'importe quel porteur d'arme incendiaire annule la mise en place
  sans même viser Yumiko.
- **Les deux plaies incautérisables changent de statut.** Ravageur et Marteau M1 ne sont plus une
  curiosité de fiche : ce sont les **seules ouvertures que le feu ne peut pas refermer**, donc les seules
  fiables dans un environnement embrasé. **Leur valeur monte nettement**, et ça mérite d'être pris en
  compte dans le placement des porteurs.

**Les deux écarts arithmétiques sont corrigés** : Sabre Grenade Mêlée 2 = **0,8775 ART** *(0,65 × 1,35)*,
Tourelle Spiker = **0,075 ART/s**. La section ne contient plus aucun chiffre en attente.

---

### D ter — Le critique devient **additif** et couvre l'estoc plasma *(révision reçue)*

**Deux changements, dont un beaucoup plus lourd qu'il n'en a l'air.** Le bonus n'est plus « la base passe
à 0,55 » mais **« +0,20 ART sur la base »**, et il s'applique désormais à la mêlée cinétique **et à
l'estoc plasma**.

**Sur la mêlée standard, rien ne bouge** : 0,35 + 0,20 = 0,55, le résultat est identique. **Tout l'effet
réel est dans l'extension aux estocs**, qui n'étaient pas couverts.

| Attaque | Base | Saignée | Dorsal ×3,00 | Part de Yumiko |
|---|---|---|---|---|
| Mêlée cinétique | 0,35 | 0,55 | 1,65 | 66 % |
| **Estoc Fusil à Plasma** | 0,65 | **0,85** | **2,55** | **102 % — MORT** |
| **Estoc Tourelle Plasma** | 1,333 | **1,533** | **4,60** | **184 % — MORT** |

**Le choix de l'additif plutôt que du multiplicatif est juste, et pour une raison structurelle : il
s'auto-régule.** +57 % sur la mêlée nue, +31 % sur l'estoc de Fusil, **+15 % seulement** sur celui de
Tourelle. Un ×1,57 aurait fait exactement l'inverse — il aurait porté l'estoc de Tourelle à 2,09 ART et
récompensé l'arme déjà la plus forte. **Ici, c'est celui qui n'a que ses poings qui gagne le plus**, ce
qui est le bon sens de lecture pour un système dont l'entrée est une lame.

**L'articulation avec la condition d'application est élégante, et je ne suis pas sûr qu'elle soit
volontaire.** Les deux estocs **traversent le bouclier** ; ce sont les seules mêlées qui n'ont pas besoin
d'une cible à nu. Mais **le saignement, lui, exige une cible sans protection pour s'appliquer**. Les deux
règles s'emboîtent : *la lame doit trouver la chair pour ouvrir, puis l'estoc profite du bonus tout en
gardant sa capacité à ignorer un bouclier qui reviendrait*. Ça donne au Fusil à Plasma un rôle de
**finisseur** qu'il n'avait pas, et ça relie enfin le sommet Mêlée au roster Covenant.

⚠️ **Le point à noter : l'estoc dorsal du Fusil à Plasma franchit le seuil de 2,50.** Il valait **1,95**
*(écart L, clos par R5)* ; sur cible saignée il vaut **2,55**, avec une attaque qui **traverse le
bouclier**. La chaîne complète — tranchant 0,35, saignement 0,125, estoc dorsal 2,55 — atteint **3,025
ART, soit 121 % de Yumiko**. **C'est une mort exacte obtenue avec l'arme la plus banale du jeu.**

Je ne le signale pas comme un problème : la séquence exige une arme tranchante, une ouverture réussie sur
cible dénudée, une charge d'estoc *(25 tirs)*, un dos exposé et l'absence de toute flamme alentour. **Cinq
conditions, c'est un prix honnête.** Mais le dossier annonçait « quatre morts exactes » ; il en compte
maintenant **sept**, dont **trois au corps à corps**, et j'ai propagé le décompte partout.

**La cautérisation a aussi été précisée** : elle met fin au saignement **et à l'effet critique**. C'était
déjà l'arbitrage rendu en ⑧, la formulation le dit maintenant explicitement dans la matrice.

**Sur la Tourelle Spiker, votre intention est notée et elle change ma lecture.** L'arme est **pensée pour
s'exploiter autour de sa mêlée et de son saignement** : ce n'est donc pas une tourelle avec un corps à
corps d'appoint, mais **une arme de contact qui tire aussi** — la seule du roster à assumer ce sens de
lecture. Vu ainsi, la charge en effets n'est plus une dispersion : 0,80 de base, 1,05 au lancer et un
saignement traversant sont **le cœur de l'arme**, et la combustion à 12 coups n'en est que la retombée.

Cela règle ma réserve précédente. Je maintiens un seul point de vigilance, de lisibilité et non
d'équilibrage : elle reste de classe **FIXE**, et son CAC à **0,988** est arrêté.

L'ancienne fiche §3.11 *(0,133/s × 3 s, CAC 0,55)* est **marquée périmée** dans le document, et les six
fiches Brutes concernées sont entrées au relevé de dette **§5.9**.

---

**Le ×3,00 Dynamo est désormais le seul barème** : la fiche qui portait un ×5,00 dérogatoire est sortie
du roster, et le relevé de dette **§5.9** n'a plus cette exception à porter.

---

### E — Les rééquilibrages que la matrice déclenche

C'est ce que vous anticipiez. Le relevé complet est en **§5.9** du fichier d'équilibrage ; voici les
conséquences qui dépassent la simple réécriture.

**① Le §0.9 est absorbé — et sa liste rétrécit.** L'ancienne règle listait **9 armes** au souffle
extincteur. La matrice en retient **4** *(Fragmentation, M319, M41, Marteau)*. **Le Déchiqueteur et
le Sabre Grenade en sortent**, et la Grenade Dynamo a désormais son **propre tri** en §5.3 au lieu d'être
un extincteur générique. Ce n'est pas un détail de rédaction : **deux armes Brutes perdent une capacité**
qu'elles avaient dans l'équilibrage actuel.

**② Le Focus Rifle est recentré, et le sens du changement est bon.** Critique sur brûlés **×1,75 → ×1,50**
*(1,54 → **1,32 ART/s**)*, mais il gagne la **traversée de blindage à ×1,00** sur cible brûlée — **0,88
ART/s au lieu de 0,44**. Le critique baisse, la pénétration double : **perte contre la chair, gain net
contre les cibles dures.** Cohérent avec son rôle de Soutien, et ça rend la synergie avec le feu plus
intéressante qu'avant *(elle sert à percer, pas juste à cogner plus fort)*.

**③ Le Lance-Flammes perd tout son système propre.** Le cumul ×12, l'escalade 0,1375 / 0,15, le seuil de
10 flammes, le résiduel de 3,60 s : **tout est remplacé** par « 12 tirs pour allumer, 12 flammèches pour
entretenir », type Incendier. **C'était le système le plus élaboré du CSNU** ; il devient une entrée
ordinaire. Je le note sans le regretter — l'uniformité vaut mieux ici — mais **vérifiez que la puissance
assumée de l'arme survit** : 0,18 ART/s de brûlure est très loin des 1,50 ART/s de burst que vous aviez
défendus. Les deux ne parlent pas de la même chose *(burst direct vs résiduel)*, et **la V2 devra dire
lequel des deux reste**.

**④ Le Canon à Combustible change de nature.** Il perd son critique **×2,50 contre les protections
destructibles** — qui était sa meilleure valeur défensive et **le seul moyen Covenant d'attaquer la chair
sans percer**. Il gagne 10 s de flaque et le cumul 3 tirs → 6,50 m. **D'arme anti-bouclier passive, il
devient arme de contrôle de terrain.** C'est un vrai changement de rôle, et il faudra le répercuter sur
D9 : la note « le plasma n'est plus anti-bouclier, mais le feu récupère cette capacité » **tombe**.

**⑤ La Tourelle Spiker perd le Saignement.** 0,133 ART/s sur 3 s disparaît au profit d'une combustion à
12 coups. **Le Saignement n'avait qu'une seule source dans toute la sandbox** — il sort donc du jeu, sauf
si vous le réintroduisez ailleurs. C'est une simplification que j'approuve : un effet à source unique est
une exception, pas un système.

**⑥ Le Flash est reformulé et devient plus dangereux.** De 0,45 + 0,08/s sur 5 s, il passe à **7,50 m ·
0,50 ART · brûlure infligée même derrière les boucliers**. La traversée de bouclier est neuve et
significative.

### F — Ce qui reste à faire, dans l'ordre

| # | Étape | Statut |
|---|---|---|
| 1 | **Arbitrages Brutes** *(III.2)* et **Forerunner** *(IV.2)* | **En cours** — file active |
| 2 | ~~Matrice des effets et contrôles~~ | **✅ Reçue et transcrite en §5** |
| 3 | **Fiches V2 des 43 armes** — chiffres retouchés, données d'effet retirées | ⏳ Annoncée |
| 4 | Vérification de la V2 contre le **relevé de dette §5.9** | À faire à réception |

**Je n'ai touché à aucune fiche d'arme.** Vous annoncez une refonte intégrale des 44 : corriger maintenant
serait du travail jeté. **§5.9 est le relevé de dette** — dix emplacements périmés, listés pour servir de
liste de contrôle quand la V2 arrivera.

**Deux questions ouvertes par la matrice, en plus des six de la partie D :**

1. **Les effets partagent-ils un barème joueur / ennemi ?** Une brûlure Incendier coûte **21,6 %** de
   Yumiko *(2,50 ART)* et **6,4 %** d'un Général *(8,50 ART)*. Même effet, trois fois moins de poids. Vous
   pouvez l'assumer *(le joueur est fragile, c'est le socle Halo CE)* — mais alors **le feu est une arme
   anti-joueur avant d'être une arme de joueur**, et ça mérite d'être écrit.
2. **Une brûlure interrompt-elle la régénération du bouclier ?** Rien ne le dit. Sur Yumiko, dont la seule
   régénération est le **chip regen** du cran entamé, la réponse change complètement la valeur du feu
   contre elle.

---

## I — CSNU — 16 fiches

*Reçues, contrôlées, transcrites en `## 1`, consolidées en §6.1–§6.4.* **✅ Lot entièrement arbitré et reporté.**

### I.1 — État de contrôle

Les 16 fiches ont été contrôlées arithmétiquement (écarts A–I) avant transcription, puis **entièrement arbitrées**. Neuf écarts, onze questions ouvertes, trois bloquants de design : **tout est tranché et reporté** dans `equilibrage-sandbox-armes.md` §1.1–§1.16 et §6.1–§6.4.

Le taux d'erreur initial était normal pour un roster de cette taille, et deux des « écarts » relevés se sont révélés être **des erreurs de lecture de ma part, pas des fautes de fiche** — le BR75 (écart B) et le SRS99 SSR (écart E). Je les note parce qu'ils disent quelque chose de méthodologique : votre notation est plus dense que ce que je supposais, et une salve n'est pas une unité indivisible de dégâts pas plus qu'un « 0,75 » n'est forcément une soustraction.

**Le lot CSNU est clos.** Ne subsistent que les trois éléments de vigilance listés en I.4 — aucun n'est une question, ce sont des paramètres à surveiller au playtest.

### I.2 — Les quatre reworks de design

Quatre armes ont changé de nature, pas seulement de chiffres. C'est ce qui mérite d'être relu.

**MA37 — trois critiques au lieu d'un.** 0,071 ART *(chargeur de 32 = un Minor pile)*, critique ×1,25 étendu aux **points faibles**, et un ×1,40 **amélioré contre les casques** portant le DPS à 0,966. Le burst initial ne bouge que de 3 % : la réhabilitation passe entièrement par la précision du joueur. **Les deux barèmes d'armure coexistent** *(§0.8)* — **×1,40 si le tir touche la tête, ×1,25 sinon** : le ×1,25 est le plancher contre tout ce qui est blindé, le ×1,40 la prime de précision, et l'écart de **+12 %** se gagne au contrôle du recul. **L'arme est explicitement réorientée vers les environnements Brute**, où l'armure domine et où son ×0,80 anti-bouclier ne la pénalise pas.

**M7-S — le pic disparaît, la portée reste.** Balle critique de fin de rafale **supprimée**, critique points faibles **×1,65 → ×1,35** *(0,061 · 0,732 ART/s)*. Le problème n'était pas le DPS moyen mais les 0,223 ART sur une balle unique à 30 m, qui mettaient l'arme en concurrence frontale avec le BR75. En retirant le pic plutôt que la portée, la correction préserve l'identité — une SMG précise à moyenne distance — et sépare les rôles par **nature de tir** : flux continu contre salve, suppression contre exécution.

**M6C dual — nerf sur trois axes, aucun sur les dégâts.** Cadence bornée à **6 c/s par arme** *(1,80 ART/s au lieu de 2,40)*, portée ramenée à **6–20 m**, spread **uniquement** en rafale à vitesse maximale et **aucun sous 8 c/s combinés**. C'est une conversion de portée en puissance, pas un nerf sec. Le seuil sans spread est la bonne idée : le joueur qui alterne proprement ses gâchettes n'est jamais puni, le spammeur l'est. **Trois armes légères, trois fois la même leçon** — avec la cadence de précision du M6D et le M7-S : *tapoter vite est un piège.*

**Lance-Flammes — rework complet, et l'arme change de catégorie.** Chaque flamme vaut désormais **0,125 instantanés + 0,125 de brûlure résiduelle** ; la brûlure n'est plus un dixième de la flamme, elle en est le double emploi. Cumul jusqu'à 12 flammes, avec une escalade qui **revalorise rétroactivement** les dix premières (0,125 → 0,1375 → 0,15) pour un burst à **1,50 ART/s** et 3,60 s de résiduel. La flamme au sol a maintenant un **coût d'entrée** — 10 flammes minimum, 18 pour les 5,40 s maximum — et 1 s passée dedans inflige 3 s de brûlure.

Deux choses à retenir sur cette dernière. D'abord la clause anti-blindage est plus subtile qu'avant : le malus ×0,35 ne frappe que ce qui **persiste après décrochage**, la brûlure passant sans scaling **tant que la cible reste sous le feu**. L'arme récompense donc le maintien du contact contre les blindés et le décrochage contre la piétaille — deux usages opposés sur la même gâchette. Ensuite, le cumul interne **ne contredit pas §0.3** : cette règle arbitre le cumul entre *sources de feu distinctes*, pas le cumul interne d'une source continue. En revanche **§0.9 s'applique pleinement** — une frag bien placée annule 1,8 s de travail au lance-flammes.

**La puissance/seconde élevée est assumée, et la contrepartie n'est pas chiffrée : elle est cinématique.** Le **projectile est lent, façon Halo CE**, l'arme est peu mobile, et maintenir douze flammes sur un ennemi qui se déplace est un cas parfait — pas un régime nominal. Contre une IA qui esquive et se replie, le joueur réaliste place quatre à sept flammes et compte sur le résiduel. **Aucun nerf du cumul n'est recommandé** ; la vraie variable n'est pas l'ART/s mais le nombre de flammes que l'ennemi laisse poser, ce qui relève de `comportement-de-l-ennemi.md`. C'est le profil de risque inverse du laser : le laser demande d'avoir raison 2,5 s **à l'avance**, le lance-flammes demande d'avoir raison **pendant** 1,2 s.

### I.3 — Lectures transversales *(révisées après arbitrage)*

**Le CSNU n'a toujours aucune clé anti-bouclier généraliste, et les arbitrages durcissent le constat.** Sept armes sur dix-sept subissent un malus, aucune ne porte de bonus. Les seules réponses restent l'IEM et l'adhésif du M319 — une arme, deux modes, un chargeur de 1. Le M41 a confirmé que **seul son souffle** est pénalisé, et le Laser M6 reste la seule exception franche du roster. Le contrepoids viendra des factions Covenant.

**En revanche le CSNU s'est doté d'une clé anti-protection dure, et c'est le vrai apport du lot.** Trois armes portent un critique casque, propagé aux armures par §0.8 :

| Arme | Mult. | Classe | Portée | Malus bouclier | Rôle |
|---|---|---|---|---|---|
| **SAW** | ×1,50 | Lourd | 12–25 m | ×0,75 | Marteler, poste tenu |
| **MA37** | ×1,40 | Principale | 15–25 m | ×0,80 | Décaper, ramassable partout |
| **BR75** | ×1,35 | Principale | 10–75 m | aucun | Cueillir à distance |

**La courbe est inverse de l'accessibilité** : plus l'arme est contraignante, plus le multiplicateur est haut. C'est proprement calibré, et ça donne au CSNU une identité que ma lecture précédente ne voyait pas — **il n'ouvre pas les boucliers, il détruit ce qui est solide derrière**. Face aux Élites il subit ; face aux Brutes, faction de l'armure, il est chez lui.

**Une seconde monnaie est apparue à côté des munitions : la mêlée.** Le rework du Laser M6 fait de sa batterie une ressource qui ne se ramasse pas — elle se gagne au contact, **0,35 % par 0,01 ART infligé, 0,525 % avec une Lance Spartane**. Additionné à la recharge cinétique de la lance, ça installe une économie parallèle :

| Économie | Armes | Se reconstitue par |
|---|---|---|
| **Munitions** | 15 armes sur 17 | Ramassage au sol |
| **Énergie cinétique** | **Laser M6, Lance Spartane** | **Mêlée, mobilité, parade** |

Les deux armes concernées sont aux extrémités absolues du roster — la plus lourde et la plus courte portée — et partagent le même carburant. Le ×1,50 accordé quand les deux sont portées ensemble est une **incitation explicite à les chaîner**. C'est la traduction la plus littérale de D15 qu'on ait : ici, **ne pas jouer le sommet Mêlée coûte littéralement des munitions**.

Le taux de **0,35 %** donne à cette économie le bon ordre de grandeur. Un tir coûte 20 % ; il se rachète pour **0,571 ART de mêlée**, soit **1,6 coup de base** :

| Mêlée | ART | Batterie *(0,35 %)* | Taux amélioré *(0,525 %)* |
|---|---|---|---|
| Base | 0,35 | **12,25 %** | 18,375 % |
| Critique *(≥ 1,10)* | 0,65 | 22,75 % | 34,125 % |
| **Critique dorsal** | 1,00 | **35 %** | **52,5 %** |
| Lance, 3 unités | 1,05 | — | **55,125 %** |

**Aucune mêlée unique ne rend une batterie pleine**, et un critique dorsal ne finance même pas deux tirs. Remplir une batterie vide demande **2,857 ART de mêlée cumulés** — huit coups de base. La mêlée **prolonge** donc la batterie sans jamais la remplacer : cinq tirs restent cinq tirs, un joueur très agressif en gagne un ou deux de plus. C'est un appoint, pas une source — l'arme conserve sa rareté, qui était son identité.

**La Lance Spartane facture l'inertie, et c'est le meilleur couplage mobilité/arme du roster.** Le palier de coût suit le **momentum réel**, pas la vitesse nominale : 10 % en marche établie à 1,10, 5 % en course, mais **retour à 20 %** dès que le momentum retombe — accélération inachevée, freinage au *slide*, sortie de BRS, dérive qui dissipe la vitesse. Le coût de la lance est donc un **indicateur d'inertie**. Le propulseur Hornet existe pour ne pas subir l'inertie ; la lance facture précisément ceux qui la subissent. Et comme la recharge cinétique (+5 % par accélération) tire dans le même sens, **le joueur qui joue mal la mobilité est puni deux fois** : il recharge moins et il dépense plus.

**Le sommet Mêlée n'est plus tenu par une seule arme.** La Lance Spartane évidemment, mais aussi le **Laser M6** qui ne se recharge qu'au contact, et le **W0-LF** qui fige les cibles pour le combo dorsal. Trois armes, trois voies — dégâts, ressource, contrôle.

**Le budget de munitions reste le levier principal**, courbe inchangée : W0-LF 24, M90 24, M319 24, SRS99 20, M41 6 en bas ; MA37 384, M7 384, SAW 360, Flammes 300, MA5B 300 en haut. La puissance se paie en rareté, pas en malus.

**Le verrou « pas d'armes spéciales » gagne une exception volontaire.** La plupart des armes lourdes interdisent le port ou taxent la mobilité *(R6, détail en **D16**)* — mais le Laser M6, arme Lourde, **gagne à être porté avec la Lance Spartane** : sa recharge cinétique se nourrit des mêlées. Le roster ne dit plus « choisis un camp » mais *« choisis un camp, sauf ici, où le mariage est récompensé »*. Une exception nommée vaut mieux qu'une règle sans relief, à condition qu'elle soit **lisible dans l'interface de chargement**.

### I.4 — CSNU : les points de vigilance sont tombés

**Les trois paramètres que je signalais comme à surveiller sont tombés**, tous les trois pour la même raison : une contrepartie structurelle existait, que la fiche ne portait pas.

| Ancien point de vigilance | Ce qui l'annule |
|---|---|
| ~~Recharge cinétique du Laser~~ | Le taux réel est **0,35 %** par 0,01 ART *(0,525 % amélioré)*, pas 1,5 %. Une mêlée de base rend **12,25 %** — moins d'un tir. Le laser s'épuise, la rareté tient |
| ~~Puissance/seconde du Lance-Flammes~~ | **Projectile lent façon CE**, arme peu mobile : maintenir 12 flammes sur une cible qui bouge est un cas parfait, pas un régime nominal |
| ~~SAW en Lourd~~ | Le Lourd est un **plafond (1,10 + saut réduit)**, pas une interdiction ; la **mêlée spéciale** reste disponible. Même en Fixe, une **charge linéaire à 1,05** subsiste |

**Il reste une seule dépendance ouverte sur le CSNU, et elle est externe :**

> ⚠️ **La grille ANB conditionne deux armes.** Le **M319** *(mentions anti-véhicule retirées de la fiche en attendant)* et la **recharge cinétique du Laser** *(indexée sur « 0,01 ART **ou ANB** »)*. Tant que l'échelle ANB n'est pas posée, le rendement de la recharge laser contre un véhicule est indéterminé — 0,35 % par 0,01 point n'a pas le même sens selon que la grille compte en dixièmes ou en dizaines. **À revérifier au moment de poser la grille**, pas avant.

✅ **Le fil MA37 ↔ §0.8 est clos.** Le ×1,25 armures n'était pas une ligne morte : il s'applique **hors tir à la tête**, le ×1,40 casque prenant le relais quand le joueur vise juste. §0.8 gagne au passage une **réserve générale** — la propagation casque→armure ne remplace pas un multiplicateur d'armure propre à l'arme, elle s'y superpose sous condition de visée. **Le lot CSNU ne laisse plus aucune ambiguïté interne.**

> **Une règle de lecture est sortie du point 8**, et elle vaut désormais partout : *ce que la fiche ne mentionne pas n'existe pas.* Elle s'applique en particulier aux notes qui **modifieraient une valeur de base** déjà inscrite — un malus, un scaling ou un multiplicateur non écrit ne doit jamais être supposé par analogie avec une autre arme. Cette règle complète §0.7 et a été portée en §6.3.

---

## II — Covenant / Élites — 12 fiches

*Reçues, contrôlées, transcrites en `## 2`, consolidées en §6.5–§6.8.* **✅ Lot entièrement arbitré et reporté.**

Seize points — cinq écarts *(J–N)* et onze questions *(12–22)* — **tous tranchés**. Deux fiches ont été
**entièrement réécrites** par l'auteur plutôt que corrigées ligne à ligne : le **Focus Rifle** *(chaleur à
trois zones, tir de Railgun en sous-système, 2,50 ART maximum)* et l'**Épée à Énergie** *(jauge de chauffe,
perforation retirée, scaling de combo, poing américain en mode dégradé)*. Deux règles générales sont nées
de ce lot et vivent désormais en tête de fichier : **§0.10 dual handling** *(double identique uniquement)*
et **§0.11 sous-systèmes et IA** *(aucun accès sauf mention explicite)*.

**Trois conséquences dépassent le lot :**

- **Le Railgun reste une mort exacte à 2,50**, et c'est la seule à **portée infinie** — la mobilité HORNET
  ne peut pas la contester. Côté arme, deux verrous l'encadrent et sont écrits : **2 s de charge** et
  **sifflement audible**.
- **La chauffe de l'Épée dépend de la cible** : 15 % sur la chair, **9,90 % sur un bouclier**, **0 % sur
  une armure**. L'arme ne s'use que sur ce qu'elle tue — elle ouvre gratuitement et facture l'achèvement.
- **La Super-Combine du Needler monte** : ses 1,25 ART frappent **directement les PV** *et* mordent le
  bouclier. Elle est plus létale que le tableau ne le disait ; son garde-fou est la lenteur du projectile.
- **La chaîne du Feu reste émergente.** L'archétype d'escouade dédié est **rejeté** — le feu est un outil
  de chaos, pas une leçon à scripter.

**Un seul détail d'arme reste à trancher chez les Élites** : le **conflit de Mêlée 2 du Grêleur** *(§2.12)*,
entre le régime Lourd FIXE *(le bouton jette l'arme)* et le décrochage. C'est un conflit de commande, il
est signalé dans la fiche, et il ne bloque rien.

---

## III — Brutes / Jiralhanae — 12 fiches

*Reçues, contrôlées arithmétiquement, transcrites en `## 3`, consolidées en §6.9–§6.12.*

### III.1 — État de contrôle

**Le lot Brute est soldé.** Les douze fiches sont arbitrées, les écarts arithmétiques sont clos et reportés dans `equilibrage-sandbox-armes.md` §3.1–§3.11.

Une leçon de méthode reste à garder : la cadence était écrite trois fois par fiche — en secondes, en tirs/s, puis implicitement dans le DPS — et les trois se désynchronisaient. **Une seule valeur doit faire foi et les deux autres en être dérivées** : la valeur en secondes, qui est celle que le moteur consommera.

### III.2 — Lot Brutes : soldé

**Le lot est clos, chiffres et arbitrages.** Aucun point ne reste ouvert.

**Deux règles générales sont sorties de ce lot et ont été promues en doctrine** — elles ne dépendent plus des Brutes :

| Règle | Ce qui a été tranché | Où elle vit désormais |
|---|---|---|
| **Report de DPS — régime de la cible** | Le report est **intégral en quantité**, puis le **multiplicateur applicable à la nouvelle cible** s'applique au montant reporté. **Sans malus, report strict** — la réduction vient de l'arme, pas de la mécanique | **D17** *(`base-de-travail.md`)* + §0.4 |
| **Ré-application, jamais cumul** | Une cible = **un seul effet actif** par famille. Feu, saignement, zones : la nouvelle source **remet la durée à plein** au lieu d'empiler | **D18** *(`base-de-travail.md`)* + §5.6 |

### III.3 — L'identité de la faction : le feu et la fenêtre

**Sept armes sur douze produisent ou manipulent du feu**, et deux l'éteignent. Là où les Élites rendaient le terrain inhabitable par la zone plasma, les Brutes le rendent inhabitable par **la combustion entretenue**. Même intention, système différent.

La différence est de nature et elle compte pour le level design. **Les zones plasma Élites sont statiques et brèves ; les feux Brutes se transmettent, s'entretiennent et se cumulent entre armes.** Un feu allumé par une Tourelle Spiker peut être entretenu par un Fusil à Plasma Brute, nourri par un Ravageur, exploité au ×1,75 par un Fusil à Faisceau, rallumé par une Dynamo. **Le feu Brute est une ressource collective qui circule dans l'escouade**, pas un effet d'arme. C'est la version Brute de la conscience collective, et elle est mécaniquement plus intégrée que la chaîne du Feu Élite — elle ne demande pas une composition précise, seulement que plusieurs Brutes tirent.

**~~Deux armes de la faction éteignent le feu~~ — il y en a cinq, et elles ne sont pas toutes Brutes.** *(Paragraphe révisé après §0.9.)* J'avais lu l'extinction des flammes par le Marteau Antigravité et le marteau du Déchiqueteur comme une anti-synergie interne à la faction. L'auteur en fait une **règle générale** : tout souffle d'explosion éteint un feu d'un coup, au sol comme sur une cible, sur **5 armes réparties sur deux factions**.

Ce que ça change pour les Brutes : la faction reste **la seule à allumer, entretenir et exploiter** le feu en chaîne (Spiker allume → Fusil entretient → Ravageur nourrit → Faisceau exploite ×1,75 → Dynamo rallume), mais elle n'est plus la seule à l'éteindre. **Le joueur emporte désormais son propre extincteur** : une frag, un M319, une roquette. La doctrine incendiaire Brute passe donc de *menace sans réponse* à *menace avec un coût de réponse* — le joueur paie une grenade pour annuler un feu, ce qui est exactement le bon prix. L'anti-synergie interne subsiste au passage : un Chieftain qui frappe au marteau éteint toujours les flammes de ses propres alliés.

**Le second axe d'identité est le rythme, et il complète les deux autres factions :**

| Faction | Ce qui limite le joueur |
|---|---|
| **CSNU** | Le budget de **munitions** — la puissance se paie en rareté |
| **Élites** | La **zone** — la puissance se paie en placement |
| **Brutes** | La **fenêtre** — la puissance se paie en **temps** |

Presque toutes les armes Brutes ont une fenêtre courte suivie d'une pénalité longue : Fusil à Plasma Brute (4 s puis 5 s), Fusil à Faisceau (3 tirs puis 6,5 s **sans voie rapide**), Marteau (une frappe puis 10 s), Déchiqueteur (2 cartouches puis rechargement). **La faction joue en pics.** C'est le profil ennemi le plus compatible avec HORNET des trois, parce qu'il récompense explicitement le déplacement à contretemps plutôt que le déplacement continu : encaisser le pic, exploiter le creux.

### III.4 — Les deux choses qui doivent vous arrêter

**Le Ravageur est la seule arme des quarante transcrites qui annule frontalement votre système de mobilité** — et c'est **tranché : elle le fait exprès.** Sa mare de plasma se forme aux pieds de la cible *même si elle a bougé*, dès lors que **4 projectiles sur 2 salves** ont porté *(66 %)*, **protection ou non**. La mobilité HORNET ne protège pas ; **rien ne bride la séquence**, c'est la punition assumée. Le contre-jeu n'est pas d'esquiver la mare, c'est d'empêcher la séquence d'aboutir — casser la ligne de vue, forcer le changement de cible, ou tuer le tireur. ⚠️ Le passage de 6 tirs consécutifs à 4 sur 6 **retire la dernière prise de la mobilité**, qui était de casser la série.

**Le Déchiqueteur en tir dual fait exactement 2,50 ART.** C'est la **quatrième mort exacte** relevée sur la solidité totale de Yumiko, après le Railgun du Focus Rifle, la double Super-Combine du Needler et — à 0,10 près — le Grenadier chargé collé. Quatre coïncidences au centième sur quarante fiches ne sont plus fortuites : **la sandbox converge d'elle-même vers « 2,50 = un engagement réussi ».** Cela renforce ce que je disais après les Élites — le bouclier à 100 % reste le curseur n° 1, et le passer à 1,50 ferait basculer huit lignes sur les deux tableaux de menaces.

**Les menaces mortelles, roster Brute** *(Yumiko = 2,50 ART)* — **table mise à jour après les arbitrages** :

| Menace | ART | Sur 2,50 |
|---|---|---|
| **Sabre Grenade — chargeur de 6 sur la même cible** | **3,53** | **Mort large** *(était 2,62)* |
| Fusil à Faisceau — 2 headshots *(0,30 s)* | **3,00** | Mort |
| Fusil à Faisceau — 3 tirs au corps | **3,00** | Mort |
| Marteau Antigravité — Mêlée 2, frappe au sol | **3,00** | Mort |
| **Mauler — dual, deux tirs sur cible blindée** | **2,70** | **Mort** *(nouveau)* |
| Déchiqueteur — tir dual | **2,50** | **Mort exacte** |
| Marteau Antigravité — frappe simple | 2,25 | 0,25 restant |
| Mauler — dual, deux tirs non blindés | 2,00 | 0,50 restant |

**Le rework fait passer les Brutes de cinq à six menaces mortelles, et il déplace le podium.** Le Sabre Grenade prend la première place — il était la cinquième menace, il devient la plus forte. Le Mauler entre dans la table par le bonus ×1,35 contre les armures : deux tirs dual sur une cible blindée valent désormais 2,70. **Ces deux entrées changent le profil de la faction sans changer sa nature** — les deux exigent toujours le contact ou la quasi-portée, et le Mauler paie sa montée en puissance par la perte totale de sa portée utile au-delà de cinq mètres.

**La nature des menaces reste ce qui rend le design bon.** Les morts Élites venaient de la distance ou du projectile guidé (Needler, Railgun). **Cinq des six morts Brutes exigent le contact ou la quasi-portée** — Mauler à 5 m, Marteau à 5 m, Déchiqueteur à 12 m, Sabre à 20 m avec six coups au but. Seul le Fusil à Faisceau tue de loin.

Conséquence : **la mobilité HORNET est une réponse valable au roster Brute, alors qu'elle l'était mal contre les Élites.** Sortir de 12 m est possible, sortir d'un pic à tête chercheuse ne l'est pas. C'est une bonne courbe — la faction la plus létale est celle contre laquelle le système du joueur fonctionne le mieux, ce qui récompense la maîtrise acquise sur les deux premières factions. **Le Ravageur reste l'exception délibérée à cette courbe**, et c'est ce qui l'empêche d'être une faction où il suffit de bouger.

### III.5 — Ce que la faction apporte au joueur

Trois armes Brutes règlent des problèmes signalés dans les lectures précédentes :

**La Grenade Incendiaire comble le déficit de contrôle de zone du CSNU** — le problème de composition le plus sérieux relevé jusqu'ici *(voir II.6)*. Le joueur exclusivement humain n'avait aucun moyen de contester le terrain face à sept sources de zone Covenant ; il en a maintenant une, sur un emplacement de grenade, donc **sans coût d'arme**. Les chiffres sont sérieux : 3,15 ART cumulés sur 4,5 s, 4,725 contre un bouclier. Personne ne reste 4,5 s dans une flaque de 3 m, mais l'ordre de grandeur dit ce qu'il faut comprendre — **la surface n'est pas un dégât, c'est une interdiction.**

**Le Ravageur et son mode focus** donnent au joueur la première arme qui contourne les angles. Sur un socle sans sprint où la couverture est la ressource principale, une arme qui frappe derrière un mur est une arme qui invalide la ressource — correctement payée par la lenteur des projectiles guidés. Et la technique qui en émerge (cibler au dernier moment après un tir en mortier, pour cumuler vitesse balistique et bonus de guidage ×1,25) **naît des règles au lieu d'être scriptée**. C'est rare, et ça mérite d'être protégé tel quel.

**Le Marteau** offre à Yumiko une auto-extinction, donc une réponse aux sept sources de feu de la faction qui le porte.

**La faction du feu fournit elle-même l'extincteur ; la faction de la zone fournit l'arme anti-couverture.** Sur un jeu où le joueur ramasse en permanence l'armement ennemi, c'est le bon dosage : chaque faction apporte sa propre contre-mesure, à condition d'accepter d'utiliser ses outils.

### III.6 — Points de vigilance

✅ **Le Fusil Électrique a été refondu en arme d'assaut** *(§3.4)* — le pendant Brute du **MA5B** *(§1.2)* et du **Répéteur à Plasma** *(§2.4)*. L'ancienne fiche empilait quatre systèmes dont deux invisibles sans interface dédiée ; la V2 garde l'intention — **récompenser l'obstination plutôt que le changement de cible** — mais la rend lisible : **un seul compteur de 1 à 4** et des verrous **spatiaux et rythmiques** *(bande 12,50–25 m, 0,55 s par tir, 12 coups)*. **Les trois armes d'assaut ont le même DPS brut et des angles morts opposés.** **Fiche complète, aucun chiffre dû.**

Mais le joueur doit suivre en temps réel sa chaîne de consécutifs, la fenêtre de 3,5 s, quels ennemis sont marqués, quelle cible a explosé, et si un critique est en cours de réactivation. La charge cognitive de la couche émergente est assumée côté IA ; **ici elle pèse sur le joueur.** C'est le seul endroit du projet où je recommanderais de **retirer de la mécanique si l'interface ne suit pas**, plutôt que d'ajuster des valeurs.

Sur les chiffres de propagation : la chaîne critique sur bouclier monte à 0,225 / 0,45 / 0,90 par tir transmis, **sur chaque marqué**. Face à quatre Grognards marqués, le troisième tir inflige 3,60 ART en une pression de gâchette. ✅ **Ma recommandation de plafond est retirée** : **aucun plafond sur les mécaniques d'émergence.** Si la sandbox permet cette situation, elle est assumée — c'est le prix d'un système qui récompense l'obstination.

**Plus aucune arme anti-bouclier n'échappe au malus sur la chair.** Toutes en payent un — Tourelle ×0,50, Pistolet ×0,75, Fusil Brute ×0,80. **Le Pistolet reste la meilleure arme plasma sur les PV** — toute comparaison doit traiter les deux colonnes, chair et bouclier, jamais une seule.

**D9 tient sur les quarante-trois fiches**, et deux des trois porteurs anti-bouclier nommés sont Brutes (Fusil Électrique ×1,50 + IEM, Grenade Dynamo ×3). C'est cohérent avec une faction qui arrive en troisième position et doit rester menaçante face à un joueur déjà équipé.

**La parade du Sabre Grenade complète le club fermé des armes qui parent** — marteau, épée, Lance Spartane — et il y ajoute une **Mêlée 2 à 0,8775 avec saignement**. C'est un chiffre d'arme, et il est arrêté.

**Deux interactions inter-fiches méritent d'être documentées ailleurs qu'en note de bas de page :**

- **Les Flash.** ✅ **Tranché** : le déclenchement est ouvert aux **armes Forerunner en général** et à **certaines armes incendiaires**, la **matrice des effets** faisant foi *(§5.2)*.

---

## IV — Forerunner / Sentinelles — 4 fiches

*Reçues, contrôlées arithmétiquement, transcrites en `## 4`, consolidées en §6.13–§6.16.*

### IV.1 — État de contrôle

**Une fiche sur quatre est irréprochable** *(Heatwave)*. Quatre écarts (W–Z) et un arrondi. C'est le lot le plus court et le plus propre en proportion, mais **deux de ses quatre écarts sont structurants** — pas des fautes de frappe : une consommation donnée du simple au double, et un multiplicateur de dual handling qui décide si une arme tue Yumiko en une passe ou non.

### IV.2 — Les arbitrages Forerunner

#### IV.2.a — Les quatre qui engagent un choix de design

**Sentinel Beam — la consommation est donnée deux fois, du simple au double.** « 1 % tous les 4 tirs » à 30 tirs/s donne **7,50 %/s** ; la fiche annonce ensuite **15 %/s**. Ce n'est pas un détail, c'est l'autonomie de l'arme :

| Hypothèse | Autonomie | Tirs | ART total délivrable |
|---|---|---|---|
| **7,50 %/s** | **13,33 s** | 400 | **8,80 ART** |
| **15 %/s** | **6,67 s** | 200 | **4,40 ART** |

**Je recommande 7,50 %/s.** À 15 %/s, une arme classée Principale qui exige de rester exposé délivre moins que quatre cartouches de Déchiqueteur sur toute sa batterie. Treize secondes de rayon continu est déjà une contrainte sévère.

**Sentinel Beam — « 0,10 ART / 4 secondes » est ambigu.** Est-ce 0,10 ART **au total** sur 4 s (0,025/s), ou 0,10 ART/s **pendant** 4 s (0,40) ? La première lecture donne le feu le plus faible du jeu par un facteur sept ; la seconde le place au niveau de la flaque du Fusil à Plasma Brute.

**Flash — le critique ne tombe pas juste.** ×3 sur 0,45 donne **1,35**, pas 1,25. **Je recommande de retenir 1,35** et de garder le ×3 propre : c'est la valeur qui aligne le Flash sur la Grenade Dynamo (0,35 × 3 = 1,05), à ×3 exact.

#### IV.2.b — Les écarts arithmétiques restants *(W–Z)*

| # | Arme | Ce qui cloche | Ma recommandation | Décision |
|---|---|---|---|---|
| ~~**W**~~ | **Sentinel Beam** | Consommation | **0,25 %/tir → 7,50 %/s** · batterie **13,33 s** / 400 tirs / **8,80 ART** | ☑ |
| ~~**X**~~ | **Sentinel Beam** | Seuil et nature du feu | **12,50 % de batterie *(50 tirs)*** → brûlure **type LUMIÈRE** *(0,11/s × 5 s = **0,550**)* | ☑ |
| ~~**Z**~~ | **Flash** | Critique bouclier | **1,35 ART** — **×3 exact** conservé · munition solide : **0,45** puis brûlure Lumière **sur les PV même protégés, sauf bouclier** | ☑ |

**✅ Les vingt-trois écarts sont clos.** *(T, U et V sont sans objet depuis le retrait de deux fiches.)*

**Arrondi — consigne de l'auteur :** *l'arrondi n'a pas besoin d'être fait au millième, l'actuel est
suffisamment lisible.* Les écarts de troisième décimale *(type Cindershot 0,6665 vs 0,66)* **ne sont plus
relevés** dans les contrôles.

#### IV.2.c — Les questions ouvertes du lot Forerunner *(35–42)*

| # | Arme | Arbitrage de l'auteur | Décision |
|---|---|---|---|
| ~~35~~ | **Heatwave** | **Variable selon le mode.** **Vertical 5–25 m** *(viser devient difficile au-delà)* · **Horizontal 3–10 m** *(la ligne de 8 unités s'étale, dégâts risibles)* | ☑ |
| ~~38~~ | **Sentinel Beam** | **Hors périmètre.** Certains **ennemis de fin de jeu** portent un **bouclier énergétique non conventionnel**, et **c'est voulu** — beaucoup de travail en amont avant d'y arriver. **Ne plus s'occuper du type lumière pour le moment** | ☑ |
| ~~39~~ | **Général** | **Le tableau existe déjà** — c'est **§5.7**, livré avec la matrice des effets, **antérieur à la question** | ☑ |
| ~~40~~ | **Flash** | **Armes Forerunner en général**, **plus certaines armes de type incendiaire**. **Pas de liste fermée** — la **matrice des effets** fait autorité | ☑ |
| ~~42~~ | **Flash** | **Déjà précisé** — matrice des effets *(§5.2, ligne Flash)* et fiche **§4.4** | ☑ |

**✅ Le lot Forerunner est soldé. Aucun point ouvert ne subsiste sur les armes.**

### IV.3 — L'identité de la faction : la lumière solide et l'armure

**Après quarante fiches presque toutes construites autour du bouclier, les Forerunner déplacent la question sur l'armure.** Sur quatre armes, **une seule est anti-bouclier** (le Flash). Le Sentinel Beam est **anti-armure** — le premier de la sandbox, avec un ×1,35 qui ne s'applique ni au bouclier ni à la chair. Le Heatwave critique à la tête, le Cindershot ne critique nulle part. **Contre cette faction, ce n'est pas le décapage qui compte** — et ça la rend lisible immédiatement.

**Le Sentinel Beam pose le seul cas d'arme du projet dont l'effet s'inverse selon la cible.** Il **recharge** les **boucliers énergétiques non conventionnels** de certains ennemis de fin de jeu, au lieu de les détruire. Aucune des quarante armes précédentes n'a d'effet inverse — il y avait des malus, des immunités partielles, jamais un renversement complet. Trois conséquences :

1. **C'est la seule arme que le joueur peut retourner contre lui-même**, au sens tactique : ramasser un Beam et tirer sur une Sentinelle à bouclier de lumière **la répare**. Excellent piège pédagogique — on l'apprend en une fois et on ne l'oublie jamais.
2. **L'arme change de valeur selon l'ennemi, pas selon la situation.** C'est un axe d'équilibrage neuf dans ce projet.
3. Cela implique une catégorie de protection « lumière » **distincte des boucliers énergétiques Covenant**. C'est une information de matrice de solidité, pas d'arme — elle doit descendre dans `base-de-travail.md`.

**Le rayon continu à 30 tirs/s est un choix de feeling avant d'être un choix de chiffres.** Trente impacts par seconde à 0,022 ART l'unité, ce n'est pas une cadence, c'est un flux : **l'arme ne récompense pas le timing, elle récompense la tenue de ligne.** Sur un socle sans sprint, exiger de rester exposé plusieurs secondes est une contrainte réelle, et elle est bien payée. Elle contraste proprement avec la doctrine Brute : **les Forerunner demandent la durée là où les Brutes demandent la fenêtre.**

### IV.4 — Le Flash résout huit références semées depuis les Brutes

**C'est la fiche la plus importante de la faction, et elle est rétroactive.** Depuis le lot Brute, quatre armes étaient créditées de « peut mettre le feu aux Flash » sans qu'on sache de quoi il s'agissait : Grenade Incendiaire, Tourelle Spiker, Sentinel Beam, Heatwave. **Un Flash est une grenade aveuglante qui devient une bombe incendiaire si on lui tire dessus.**

**C'est la meilleure coopération d'escouade du projet, et elle dépasse ce que font les trois autres factions**, pour une raison précise : l'objet intermédiaire est **visible, statique et neutre**. La chaîne du Feu Élite exigeait trois porteurs coordonnés dans le temps ; le duo Dynamo + Fusil Électrique exige une fenêtre de 2,50 s d'entretien. **Le Flash attend au sol que quelqu'un le déclenche** — n'importe qui, y compris le joueur, y compris avec une arme d'une autre faction. Un Flash lancé par une Sentinelle devient une bombe pour son propre camp si Yumiko tire dessus avec une Tourelle Spiker Brute.

**C'est le premier objet du jeu qui appartient à celui qui réagit le plus vite.** Je le tiens pour le meilleur candidat à un moment de gameplay signature de tout ce que j'ai lu sur les quarante-trois fiches.

**L'aveuglement qui frappe le lanceur et ses alliés est la clause qui rend l'objet honnête.** Aucune arme précédente ne se retournait contre son porteur. Cela donne un vecteur direct à la couche de conscience collective : **un Grognard paniqué jette son Flash n'importe où et aveugle son escouade ; un gradé le place.** Le même objet mesure la compétence de l'unité qui l'utilise, sans qu'il faille écrire deux comportements distincts.

### IV.5 — Deux choses à surveiller


### IV.6 — Le meilleur calibrage des quatre fiches

**Le seuil d'incendie du Heatwave mérite d'être isolé.** Il faut 16 unités sur 3 tirs, alors que 3 tirs en délivrent 24 : **le seuil est à 66,7 % de précision.** Ce n'est pas un compteur de tirs, c'est un **compteur de justesse**. Un joueur qui arrose n'allume pas ; un joueur qui place ses gerbes allume.

Sur une arme à dispersion, c'est la façon la plus élégante de récompenser la précision sans imposer de headshot — et je n'ai vu ce mécanisme nulle part dans les quarante fiches précédentes. **À garder tel quel, et à réutiliser ailleurs si l'occasion se présente.**

Le reste de la fiche est du même niveau : deux modes accessibles par un bouton déjà présent (Mêlée 2), sans menu ni temps de bascule, et **qui ne partagent pas le même barème** — l'horizontal critique à ×2,5 au headshot, le vertical détone en zone à 0,88 ART. Le joueur ne choisit pas entre « fort » et « faible », il choisit entre **viser la tête d'un** et **arroser un groupe**. C'est la bonne forme de choix : celle qui dépend de la situation, pas de la maîtrise.

Un chiffre à connaître tout de même : **huit unités toutes en critique font 2,20 ART**, soit 88 % de Yumiko en une pression de gâchette. Ce n'est pas atteignable en pratique, mais avec la mise en joue qui resserre la gerbe, **le Heatwave à courte distance est probablement l'arme la plus forte du roster Forerunner**. À tester en priorité.

### IV.7 — Le feu est devenu inter-factions

Le Heatwave entretient « n'importe quel feu plasma ou classique » **et** peut être entretenu par des tirs de plasma. Traduction : **une escouade mixte Brute + Forerunner maintient un feu indéfiniment**, chacune rechargeant le cooldown de l'autre. Ce que j'avais identifié chez les Brutes comme une ressource collective circulant dans l'escouade **dépasse maintenant le cadre d'une faction** — c'est un argument mécanique, et pas seulement narratif, pour faire combattre les deux ensemble.

Le revers était un besoin de documentation : **cinq sources de feu réparties sur trois factions, avec des tables de pénétration différentes.** Le feu du Sentinel Beam **entretient et allume en Lumière** ; celui du Flash traverse **armures et blindages mais pas les boucliers** ; ceux des Brutes ne traversent rien. **Deux feux Forerunner, deux comportements opposés.** ✅ **Le tableau demandé existait déjà : c'est §5.7**, livré avec la matrice des effets.

---

## V — Synthèse des quatre factions

**43 armes transcrites, contrôlées, consolidées et arbitrées.** Vingt-trois écarts arithmétiques **tous tranchés**, quarante-cinq points ouverts **tous clos**, **aucun chiffre inventé**. **Le chantier des armes est terminé.**

| Lot | Fiches | Écarts | Fiches sans écart | Points ouverts | État |
|---|---|---|---|---|---|
| ~~CSNU~~ | 16 | ~~**A–I**~~ *(9)* | — | ~~1–11~~ | ✅ **Clos** |
| ~~Covenant / Élites~~ | 12 | ~~**J–N**~~ *(5)* | **0** | ~~12–22~~ | ✅ **Clos** |
| ~~Brutes~~ | 11 | ~~**O–S**~~ *(5)* | 5 | ~~23–34 · 43 · 44 · 45~~ | ✅ **Clos** |
| ~~Forerunner~~ | 4 | ~~**W–Z**~~ *(4)* | 1 | ~~35–42~~ | ✅ **Clos** |
| **Total** | **43** | **23** | **6** | **45** | ✅ **Les quatre lots sont clos** |

### V.1 — Quatre doctrines qui ne se recouvrent pas

C'est le résultat le plus solide de l'ensemble du travail. **Chaque faction limite le joueur par une ressource différente**, et aucune ne double une autre :

| Faction | Ce qui limite le joueur | Mécanisme |
|---|---|---|
| **CSNU** | Les **munitions** | Les cinq armes les plus fortes ont les cinq plus petites réserves |
| **Élites** | Le **placement** | Sept sources de zone rendent le terrain inhabitable |
| **Brutes** | Le **temps** | Fenêtres courtes, pénalités longues, jeu en pics |
| **Forerunner** | L'**exposition** | Rayons continus, seuils cumulatifs, objets à déclencher |

**La courbe de létalité entre factions est bonne** : **3 menaces mortelles chez les Élites**, **6 chez les Brutes** (le pic), **2 chez les Forerunner**. La quatrième faction redescend — mais elle redescend **en apportant des mécaniques plutôt que des chiffres** : inversion d'effet selon la cible, objet neutre détonable, contournement automatique des couverts. **Une quatrième faction qui aurait surenchéri en dégâts n'aurait rien eu à dire ; celle-ci change les règles à la place.** C'est le bon rôle pour un appoint.

### V.2 — Les trois constats qui tiennent sur les 43 fiches

**① D9 tient partout, et elle n'a plus une seule exception.** Chaque arme anti-bouclier paie sur la chair — Tourelle ×0,50, Pistolet ×0,75, Fusil Brute ×0,80, Fusil Électrique ×0,25. La seule fiche qui y échappait est **sortie du roster**. La doctrine est désormais sans trou : **qui frappe fort le bouclier frappe faible la chair.**

**② La sandbox converge d'elle-même vers 2,50 ART.** Quatre morts exactes à la solidité totale de Yumiko : Railgun du Focus Rifle, double Super-Combine du Needler, Déchiqueteur en dual, et à 0,10 près le Grenadier chargé collé. **Quatre coïncidences au centième ne sont plus des coïncidences.** ⚠️ **Trois s'ajoutent depuis §5.6, toutes au corps à corps et toutes en dorsal** : **lancer de Tourelle Spiker** *(3,15 ART)*, **estoc de Tourelle Plasma sur cible saignée** *(4,60)* et **estoc de Fusil à Plasma sur cible saignée** *(2,55)*. Contrairement aux quatre autres, elles **dépassent** 2,50 au lieu de le frôler — mais elles exigent toutes un dos exposé. Le bouclier à 100 % reste le curseur n° 1 : le passer à 1,50 ferait basculer une dizaine de lignes sur les trois tableaux de menaces.

**③ Le feu est devenu un système à part entière, et personne ne l'a décidé.** Il a émergé fiche par fiche : brûlures Brutes, flaques, mares, incinération, feux Forerunner, Flash détonables. **Huit armes l'allument, neuf l'éteignent** *(§0.9)*, **quatre l'entretiennent, et les tables de pénétration diffèrent d'une source à l'autre.** C'est aujourd'hui la mécanique la plus transversale du projet et **la seule qui n'ait pas de document dédié.** Je recommande de lui en donner un — c'est ma principale recommandation d'organisation à ce stade.

---

## VI — Ce qui reste dû

> **Note de méthode.** L'auteur a confirmé qu'il repasserait sur **l'intégralité des points soulevés** — écarts arithmétiques comme points ouverts — et y répondrait. Aucun point de ce document n'est à relancer : ils sont consignés pour être traités, pas pour être rappelés.

**`equilibrage-sandbox-armes.md` compte ~4 260 lignes** : 43 fiches, quatre factions, la **matrice des effets et contrôles** *(`## 5`)* et la matrice consolidée *(`## 6`)*. ⚠️ **Les fiches ne sont plus la référence sur les effets** : la matrice prime, et les **fiches V2** annoncées corrigeront les dix emplacements périmés listés en **§5.9**.

**Outil** — le moteur `kill()` de `matrice-de-depart.py` **ignore `malus` et `anb`** (ANB affiché à 0,00). Les TTK produits ne sont pas exploitables tant que ce n'est pas corrigé. **C'est le premier chantier**, puisque les trois lectures ci-dessous en dépendent. *(Les valeurs CSNU du fichier sont à jour des arbitrages : MA37 0,071 · M7-S ×1,35 · SSR malus ×0,75 · M41 et M319 sans ANB.)*

**Les trois lectures promises à la réception de la matrice** — toutes trois désormais possibles, les quatre factions étant en place :

1. **Rapport bouclier / chair entre Spartan et Élites** — duel entre égaux ou asymétrie assumée.
2. **Rapport coûts HORNET / budget ART** — le taux de change entre mobilité et survie.
3. **Cohérence des seuils** — où tombent les tirs-pour-tuer, et quels chiffres sont posés sur une falaise.

**Arbitrages ouverts, récapitulatif complet.** Tous sont désormais **portés dans ce document**, avec une recommandation et une case de décision. Les renvois en §5 mènent au détail chiffré.

| Lot | Section ici | Écarts | Points ouverts | Total | Clos |
|---|---|---|---|---|---|
| ~~**Règles communes**~~ | **§0** | — | **R1–R7** | **7** | **7 ☑** |
| ~~**CSNU**~~ | **I** | ~~A–I~~ | ~~1–11~~ | **20** | **20 ☑** |
| ~~**Élites**~~ | **II** | ~~J–N~~ | ~~12–22~~ | **16** | **16 ☑** |
| ~~**Brutes**~~ | **III.2** | ~~O–S~~ *(§6.10)* | ~~23–34 · 43 · 44 · 45~~ *(§6.11)* | **20** | **20 ☑** |
| ~~**Forerunner**~~ | **IV.2** | ~~W–Z~~ *(§6.14)* | ~~35–42~~ *(§6.15)* | **12** | **12 ☑** |
| | | **23 écarts** | **52 questions** | **75** | **75 ☑** |

**Les cinq lots sont clos.** Les sept règles communes *(§0)*, le **CSNU**, les **Élites**, les **Brutes** et les **Forerunner**. **Les soixante-quinze arbitrages sont rendus. Plus rien n'est ouvert sur les armes.** Plus rien d'autre n'est ouvert sur les armes.**

> **Les vingt-trois écarts arithmétiques sont tous tranchés, et aucun chiffre n'a été inventé.** Là où
> une fiche se contredisait, l'auteur a fixé.

> **Hors périmètre de ce document — définitivement.** Unités porteuses, comportements, escouades,
> coordination, directeur d'IA : **ces questions ne sont pas des questions d'armes** et ne sont plus
> posées ici. Elles vivent dans `comportement-de-l-ennemi.md` et seront traitées **en temps voulu**.

**Par où continuer — séquence fixée par l'auteur.** Il ne reste aucun bloquant de design :

| # | Étape | Statut |
|---|---|---|
| 1 | ~~Arbitrages **Brutes** *(III.2)*~~ | **✅ Soldés** |
| 1 bis | ~~**Arbitrages Forerunner** *(IV.2)* — écarts W–Z, points 35 / 38 / 39 / 40 / 42~~ | **✅ Soldés** |
| 2 | ~~Matrice des effets et contrôles~~ | **✅ Reçue — transcrite en `## 5`** |
| 3 | **Fiches d'armes V2** — remplacent les anciennes, chiffres retouchés, données d'effet retirées | ⏳ Annoncée |
| 4 | Vérification de la V2 contre le **relevé de dette §5.9** | À faire à réception |

*(La matrice des zones plasma évoquée plus bas est **absorbée** par l'étape 2 : la Zone Plasma y est l'un des cinq types de flamme.)*

**Un fil ouvert par le lot CSNU, à ne pas perdre** *(le second, MA37 ↔ §0.8, est clos : ×1,40 à la tête, ×1,25 au corps)* **:**

- **La grille ANB conditionne maintenant deux armes, pas une.** Les valeurs anti-véhicule du M319 ont été retirées de sa fiche en attendant le barème, et la **recharge cinétique du Laser M6** est indexée sur les ANB autant que sur l'ART — 0,35 % par 0,01 point n'aura pas le même rendement selon l'échelle retenue. Le barème devra être posé avant que ces deux armes soient réellement équilibrées.

**Trois fils transversaux ouverts par les quatre lots**, à traiter hors fiches d'armes :

- **Le feu mérite son propre document — et il est maintenant plus simple à écrire qu'il ne l'était.** R3, R4 et §0.9 le réduisent à trois règles : pas de dégressivité, pas de cumul *(le dernier foyer remplace)*, et tout souffle d'explosion éteint. Reste à recenser au même endroit **huit armes qui allument, neuf qui éteignent, quatre qui entretiennent**, et à uniformiser les tables de pénétration, encore divergentes d'une source à l'autre. ~~**Recommandation d'organisation n° 1**~~ — **✅ RÉALISÉ.** La **matrice des effets et contrôles** *(`## 5`)* absorbe l'intégralité du sujet : cinq types de flamme, table d'allumage / entretien / extinction, tri du souffle Dynamo, deux émergences nommées. Le feu cesse d'être un thème dispersé pour devenir **un système à cinq entrées**. Reste à purger les fiches — c'est l'objet de la V2, relevé de dette en **§5.9**.
- **Le bouclier de Yumiko à 100 %.** **Sept** morts exactes à 2,50 sur quarante-trois fiches — quatre à distance, **trois au corps à corps en dorsal** *(lancer de Tourelle Spiker 3,15 ; estocs plasma sur cible saignée, 4,60 et 2,55)*. Curseur n° 1 au playtest.
 et par des armes d'autres factions · la **composition variable selon le commandement** (Grognard au Spiker = Chieftain à proximité) · le **Flash comme mesure de compétence** (un Grognard paniqué aveugle son escouade, un gradé le place).

**Trois informations à faire descendre dans `base-de-travail.md`** :

- **Les sous-systèmes d'armes sont interdits à l'IA par défaut** *(§0.11)*. Seules les unités
  explicitement désignées en disposent, et la mention se fait sur la fiche d'ennemi. Un ennemi qui
  déclenche un sous-système est donc toujours **une information de grade**.


- ~~Les **boucliers de type lumière** sont une catégorie de protection distincte *(point ㊳)*.~~ **✅ CLOS — rien à descendre.** Il s'agit de **boucliers énergétiques non conventionnels** portés par des **ennemis de fin de jeu**, et c'est voulu. La matrice de solidité ne les portera qu'au moment où ces unités seront traitées.
- ~~Le **verrou « pas d'armes spéciales »** est une catégorie *(point ㊴)*.~~ **Reformulé par R6, puis promu en D16** : il n'y a pas de catégorie unique, mais **deux verrous distincts** — *interdiction de port* et *pénalité de mobilité en duo ambidextre* — décidés au cas par cas et écrits sur chaque fiche. ✅ **Descendu dans la doctrine sous D16**, avec la table des 7 armes et des 2 exceptions.
- **D14 a été reformulée** dans `base-de-travail.md` : le plafond de 1,00 ne vaut que pour la base 0,35 ; toute autre base prend ×3,00 fixe sans plafond *(R5)*. `arcade-yumiko.md` §6.2 et `arcade-yumiko.py` sont alignés.
- ~~**Le tableau « qu'est-ce qui traverse quoi »** *(point ㊴)*.~~ **✅ CLOS — il existait déjà** : c'est **§5.7**, livré avec la matrice des effets, donc **antérieur à la demande**. Les deux feux Forerunner y ont été ajoutés. *(La règle §0.8 — un critique casque vaut aussi contre les armures — reste valable et vit dans §0.8.)*
