# Équilibrage Sandbox — Armes

**Projet :** Fangame Halo · système de mobilité HORNET
**Objet :** fiches d'équilibrage détaillées, arme par arme, et matrice consolidée
**Source :** équilibrage établi par l'auteur. Ce document le transcrit et en tire la matrice.

> Le **registre éditorial** (quelle arme existe et pourquoi) vit dans `contenu-sandbox-armes-retenues.md`.
> La **doctrine, la légende des colonnes et la matrice de solidité des unités** vivent dans `base-de-travail.md`.
> Ici : **les chiffres**.

---

## 0. Règles constantes

### 0.1 — Unité et conversion

| Point | Règle |
|---|---|
| **ART** | Unité de puissance d'arrêt |
| **Boucliers et armures** | Notés en **%** |
| **Conversion** | **1,00 ART = 100 % de résistance de bouclier** |
| **Référence** | **Elite Minor = 100 % de bouclier, 1,00 ART de vie non protégée** |

---

### 0.2 — Mode mise en joue *(armes sans lunette)*

Vue **par-dessus l'arme** — pas de lunette ni de zoom à proprement parler.

| Point | Règle |
|---|---|
| Gain | Mode **plus précis** |
| Coût | **Course ralentie** · **ne peut pas déclencher la mobilité spéciale** |
| Sortie forcée | Une **impulsion / dash fait sortir du mode** — vaut aussi pour les armes à lunette |
| Dual handling | **Compatible**, sauf mention contraire — **valable en double identique uniquement**, voir **§0.10** |

---

### 0.3 — Entretien du feu

**Il n'y a pas de dégressivité.** Un feu ravivé brûle exactement comme un feu initial.

| Point | Règle |
|---|---|
| Entretien | Un tir qui ravive un feu **relance l'effet à pleine puissance** — aucune décroissance |
| **Cumul** | **Impossible.** Allumer un feu sur une cible ou une zone **déjà en feu remplace le foyer précédent** |
| **Portée du remplacement** | **Tous types confondus.** Incendiaire, plasma, **plasma instable** *(Brutes)* et combustible : une zone nouvelle, **quelle qu'elle soit**, brûle **à la place** de l'ancienne. Il n'existe pas de sol qui cumule deux natures de feu |
| Extinction | Le **souffle d'une explosion** éteint un feu **d'un seul coup** — voir §0.9 |

> *Règle antérieure abandonnée : la courbe dégressive 100 → 80 → 60 → 40 → 20 → 10 % n'existe plus.*

---

### 0.4 — Report de DPS

**Le report de DPS existe pour toutes les armes du jeu.** *(Cette règle générale remplace la
restriction antérieure aux SRS99 et M90.)*

Lorsqu'une protection saute et qu'il reste de la puissance pour toucher la chair :

| Situation | Traitement |
|---|---|
| Base du critique | Calculée sur les **dégâts RESTANTS**, pas sur le tir entier |
| Report depuis un coup **malusé** *(ex. malus bouclier)* | Les dégâts restants sur chair / armure sont **indexés sur la base malusée** |
| **La part reportée change de régime** | Le report est **intégral en quantité**, puis **le multiplicateur applicable à la nouvelle cible s'applique au montant reporté** — malus, neutre ou bonus. Sans malus, le report est **strict** *(**D17**)* |
| Report sur un **point faible**, arme **à criticité** | Le **multiplicateur critique** s'applique **au montant ART restant** |

> **Le report ne conserve jamais le taux de la protection qu'il vient de traverser.** Un tir bonifié
> contre le bouclier reporte ce qui reste, et ce reste est **recalculé au régime de la chair**. C'est ce
> qui empêche une arme anti-bouclier de devenir accidentellement bonne contre la chair au moment de la
> transition.
>
> ⚠️ **Le report n'est réduit que si l'arme est déjà faible contre ce qu'elle atteint.** Une arme neutre
> sur la chair reporte **strictement**, sans perte. La réduction vient de l'arme, jamais de la mécanique.
>
> **Exemple — une arme à ×1,50 bouclier et ×0,25 chair** sur un **Élite Major** *(bouclier 2,00)* :
> 4 tirs à 0,60 = **2,40**, le bouclier saute à 2,00, il reste **0,40 à reporter**, et ce reste touche la
> chair : 0,40 × **×0,25** = **0,10 ART**. Un « 25 % » lu dans une fiche n'est jamais un taux de report —
> **c'est le malus chair de l'arme.**

---

### 0.5 — Catégories de maniement

| Catégorie | Mobilité Spartane | Boost | Armes SPÉCIALES | Dual handling |
|---|---|---|---|---|
| **Principale** | **Intouchée** | — | Compatible *(mobilité et précision réduites)* | — |
| **Légère** | Intouchée | — | Compatible, **aucune perte** de maniabilité ni de mobilité | **Éligible** |
| **Soutien** | **Intouchée** | **Consommation accrue** pour les **déplacements**, pas pour les attaques | Compatible *(**pas** de mobilité de Spartan)* | — |
| **Lourd** | **Aucun déplacement Spartane au-delà du palier 1,10** · **hauteur de saut réduite** · seules les **attaques** boosters restent utilisables | **Consommation accrue** | **Non** | — |
| **Fixe** | **Restrictions du Lourd**, plus : **pas de charge Spartane** *(charge **linéaire** plafonnée à **1,05**, vers l'avant uniquement)* · **aucun dérapage ni mobilité** · marche **0,90** · boosters **anti-inertie seulement** | **Consommation accrue** | **Non** | — |
| **SPÉCIALES** | — | — | Outil, souvent utilisable seul **ou en tandem** avec une Principale, Soutien ou Légère | — |

> **PASSIF des armes SPÉCIALES :** vitesse de marche portée à **1,10**.
>
> **Précision sur la classe Lourd.** La restriction est un **plafond de vitesse**, pas une interdiction :
> tout déplacement Spartane **jusqu'à 1,10 reste ouvert** *(palier 1, coût nul — voir `arcade-yumiko.md` §3)*,
> seul ce qui va **au-delà** est fermé, à commencer par le **palier 2 (1,25)**. S'y ajoute une **hauteur de
> saut réduite** — la vraie perte du Lourd est **verticale**, pas horizontale. Les **attaques** boosters
> restent utilisables, la **mêlée spéciale** aussi.
>
> **Les deux classes sont emboîtées.** La classe **Fixe applique toutes les restrictions du Lourd**, puis
> en ajoute : la **charge Spartane disparaît** au profit d'une **charge linéaire plafonnée à 1,05**, vers
> l'avant uniquement, **sans dérapage ni redirection**. Une arme « Lourd FIXE – Lourd » traverse donc
> **deux régimes**, et le décrochage rend surtout de la **liberté directionnelle**.

---

### 0.6 — Armes FIXES *(tourelles)*

**Maniement à la première personne**, mais l'arme **ne peut pas être rangée** dans l'inventaire
secondaire : c'est une **3ᵉ arme**, qu'on **repose au sol** après utilisation.

#### Mobilité — gameplay revenu au plus basique

**La classe Fixe applique d'abord toutes les restrictions du Lourd** *(§0.5)* — plafond 1,10, **saut
réduit**, attaques boosters seules, consommation accrue, pas d'arme SPÉCIALE — puis les durcit :

| | État |
|---|---|
| **Vitesse de marche** | **0,90** |
| **Charge Spartane** | **Non** — remplacée par une **charge linéaire plafonnée à 1,05** |
| **Direction de la charge** | **Vers l'avant uniquement** |
| **Dérapage / redirection** | **Non** |
| **Boosters** | **Contrent l'inertie, et rien d'autre** |
| **Slide** | **Non** |
| **Wall jump** | **Non** |

> **Ce n'est pas l'immobilité, c'est la ligne droite.** Le joueur avance encore — à 1,05, à peine au-dessus
> de sa marche normale — mais **ne choisit plus sa trajectoire en cours de route** : pas de dérive, pas de
> redirection, pas de slide. Le porteur d'une arme fixe est **prévisible**, et c'est là que le danger se joue.

> ⚠️ **Le seuil de 1,05 a une conséquence sur la mêlée.** Il tombe dans la fenêtre **1,01–1,10** qui ouvre
> l'Emplafonnement, le Bastonneur et l'Uppercut à **0,50 ART** *(`arcade-yumiko.md` §4)*, mais **reste sous
> le seuil critique de 1,10** qui les porte à 0,65. En Fixe, Yumiko conserve donc les **versions non
> critiques** de ces trois coups et **perd définitivement leurs versions critiques** — le plafond est
> calibré cinq centièmes trop bas pour elles. Volontaire ou non, c'est un arbitrage de mêlée autant que
> de mobilité, et il mérite d'être confirmé.

#### Corps à corps des armes fixes

| Entrée | Effet | Puissance |
|---|---|---|
| **Base de catégorie** | Mêlée **plus lente** que la normale · **stuns facilités** | **0,55 ART** |
| **Mêlée 1** | Attaque **lente**, **stun plus important** | **0,55 ART** |
| **Mêlée 2** | **Jette l'arme vers l'avant** — inflige **à distance** | **0,75 ART** + **stun important** |

| Modificateur | Valeur |
|---|---|
| Contre les **blindages** | **×0,50** *(les deux mêlées)* |
| Contre les **armures** | **Critique ×1,5** |

> **Les stuns se déclenchent plus facilement — même sur des ennemis solides ou protégés** qui, de base,
> ne subissent pas de stun. C'est la contrepartie de la lenteur, et **la vraie valeur de ce CAC** :
> il ouvre des cibles que rien d'autre n'ouvre.

> ✅ **Tranché (R1).** **0,55 ART est la base de la catégorie.** **Des exceptions existent, arme par
> arme** — l'**Estoc Plasma de la Tourelle Plasma** est à **1,333 ART**.

#### Grand magasin

Certaines armes fixes peuvent être **séparées de leur GRAND MAGASIN** :

| Conséquence | Détail |
|---|---|
| Coût | Retour à des **chargeurs restreints** |
| Gain | L'arme devient **rangeable** comme l'une des **deux armes portées** |
| Manipulation | **Maintenir Y** — échange avec la dernière arme « normale » équipée avant le ramassage de l'arme lourde fixe |

---

### 0.7 — Format des fiches d'arme

Chaque arme reçoit **deux blocs** : un **tableau de statistiques**, puis un espace **Notes** en texte libre.

**Le tableau ne contient que les lignes qui ont quelque chose à dire.** Une arme sans critique n'a pas de ligne Critique, une arme sans perforation n'a pas de ligne Perforation. Un champ dont la fiche source ne dit rien est **simplement absent** — pas de `—` décoratif, pas de relance.

#### Bloc A — Statistiques

**Lignes systématiques** — présentes sur toutes les armes :

| Champ | Contenu |
|---|---|
| **Classe** | Principale · Légère · Soutien · Lourd · Fixe · Spéciale · Lancer · Hybride *(X/Y)* |
| **Puissance** | ART par tir · ART/s |
| **Cadence** | Secondes entre tirs · tirs/s |
| **Chargeur / Recharges** | Chargeur · nombre de recharges · réserve totale |
| **Portée efficace** | Mètres · seuils de *fall-off* |

**Lignes conditionnelles** — uniquement si l'arme en dispose :

| Champ | Quand la ligne apparaît |
|---|---|
| **Variante** | L'arme a une déclinaison nommée |
| **Critique** | Multiplicateur, zone, condition de portée |
| **Perforation** | Ce qu'elle traverse — rappel §0 : le casque, jamais le bouclier |
| **Anti-bouclier** | Malus ou bonus chiffré — rappel D9 : le plasma est neutre |
| **Scaling / fall-off** | Multiplicateur et distance de déclenchement |
| **Mise en joue** | Seulement si le mode change quelque chose |
| **Lunette** | Niveaux de grossissement |
| **Système secondaire** | Maintenir X — armes à batterie |
| **Charge** | Tir chargé et son coût |
| **Dual handling** | Ce que le maniement à deux armes modifie — **toujours deux exemplaires de la même arme** *(§0.10)* |
| **CAC** | Seulement si la mêlée avec cette arme sort de l'ordinaire |
| **Mobilité** | Seulement si la classe impose une restriction particulière |
| **Anti-véhicule** | Valeurs dédiées |

#### Bloc B — Notes

Texte libre, sans limite de longueur. C'est là que va **l'essentiel** : intention de design, rôle dans la sandbox, comportement du critique et de la perforation quand il ne tient pas dans une case, interactions avec le Triangle, cibles de référence, pièges d'équilibrage, points laissés ouverts.

---

### 0.8 — Critiques CASQUE et ARMURE

| Point | Règle |
|---|---|
| Règle | **Un critique qui s'applique aux CASQUES s'applique AUSSI, au même multiplicateur, aux ARMURES** |
| Portée | Générale — toute arme dotée d'un critique casque |
| Conséquence | Une arme « anti-casque » est mécaniquement une arme **anti-protection dure**, pas une arme anti-gradé |
| **Réserve** | La propagation **ne remplace pas** un multiplicateur d'armure **propre à l'arme** : elle s'y **superpose** et ne s'applique **que si le tir touche la tête** |

> Concerne aujourd'hui **trois armes CSNU** :
>
> | Arme | Mult. casque | Armure, tir tête | Armure, tir corps | Fiche |
> |---|---|---|---|---|
> | **M739 SAW** | ×1,50 | ×1,50 | — | §1.16 |
> | **MA37** | ×1,40 | **×1,40** | **×1,25** *(valeur propre)* | §1.1 |
> | **BR75** | ×1,35 | ×1,35 | — | §1.7 |
>
> ✅ **Cas du MA37 — tranché, et la ligne ×1,25 n'est pas morte.** L'arme porte **deux barèmes
> d'armure distincts**, départagés par le **point d'impact** :
>
> | Le joueur vise… | Multiplicateur sur l'armure | ART / tir |
> |---|---|---|
> | **La tête** | **×1,40** *(casque, propagé par §0.8)* | 0,0966 |
> | **Le corps** | **×1,25** *(critique armure propre à la fiche)* | 0,086 |
>
> **La précision paie deux fois** : viser la tête d'un ennemi blindé vaut mieux que l'arroser, mais
> l'arrosage conserve un bonus. C'est un plancher, pas une punition — l'écart entre les deux
> (**+12 %**) récompense la visée sans rendre le tir au corps inutile.
>
> **Portée de la réserve** : elle vaut pour **toute arme** qui déclarerait à la fois un critique casque
> et un critique armure propre. Aujourd'hui seul le MA37 est dans ce cas ; la SAW et le BR75 n'ont pas
> de multiplicateur d'armure propre, leur propagation reste donc pleine et sans condition.

---

### 0.9 — Souffle des explosions et extinction du feu

| Point | Règle |
|---|---|
| Effet | Le **souffle d'une explosion éteint un feu d'un seul coup** |
| Cibles | **Feu au sol** comme **feu porté par un ennemi** — les deux |
| Portée | Générale à toutes les armes explosives listées ci-dessous |

> ### ⚠️ SECTION ABSORBÉE — la liste fait autorité en **§5.4**
>
> ~~**Armes concernées** *(9)* : Grenade à Fragmentation · Lance-Grenades M319 · Lance-Roquettes
> M41 · Marteau Antigravité · Déchiqueteur · Sabre Grenade · Grenade Dynamo · toute forme d'explosion
> Dynamo.~~
>
> **Liste en vigueur — 5 armes** : Grenade à Fragmentation · Lance-Grenades M319 · Lance-Roquettes M41 ·
> **Marteau Antigravité** *(toutes formes)* · **Sabre Grenade**.
>
> **Deux sorties** : le **Déchiqueteur** *(ses lames ne soufflent pas)* et la **Grenade Dynamo**, qui a
> désormais son **tri propre** en §5.3 — elle éteint trois types et en **entretient** deux, ce qui est
> l'inverse d'un extincteur générique.
>
> **Cas particulier** : sur le **Lance-Flammes**, le souffle éteint la flaque et la brûlure résiduelle,
> **jamais le jet direct** — celui-ci s'interrompt, il ne s'éteint pas *(§5.2)*.

C'est le **contre-jeu générique du système de feu**. Trois factions sur quatre en disposent, ce qui
évite qu'une doctrine incendiaire devienne une réponse sans réponse.

---

### 0.10 — Dual handling : la règle vaut pour le **double identique**

| Point | Règle |
|---|---|
| **Champ d'application** | Les valeurs de dual handling écrites sur une fiche *(multiplicateur, spread, réserve, contreparties)* ne valent **que si le joueur porte deux exemplaires de la MÊME arme** |
| **Deux armes différentes** | **Aucun de ces équilibrages ne s'applique.** Le port ambidextre hétérogène n'hérite pas des chiffres de l'une ni de l'autre |
| Conséquence | Un multiplicateur comme le **×0,66 de l'Épée à Énergie** décrit un couple homogène, jamais un panachage |

> **Pourquoi c'est nécessaire.** Sans cette borne, un joueur combinerait le meilleur des deux
> colonnes — la réserve d'un M7 avec la puissance d'un Mauler — en ne payant la contrepartie
> d'aucun des deux. Le dual handling est un **choix de spécialisation**, pas un assemblage.

---

### 0.11 — Sous-systèmes d'armes et IA

| Point | Règle |
|---|---|
| **Principe** | **Par défaut, l'IA n'utilise pas les sous-systèmes d'une arme** — charge, estoc, railgun, reconversion, refroidissement contrôlé |
| **Exception** | Seules les unités **dont la fiche d'ennemi le précise** en disposent, et seulement pour les sous-systèmes nommés |
| Lecture | Un ennemi qui déclenche un sous-système est donc **toujours une information de grade** pour le joueur |

> Cette règle referme d'un coup une famille entière de questions ouvertes — « l'IA peut-elle
> enchaîner deux tirs chargés ? », « un Grognard sait-il faire un estoc ? ». La réponse est
> **non, sauf mention**, et la mention se fait côté `comportement-de-l-ennemi.md`, pas côté arme.

---

## 1. CSNU

> 17 entrées. Les valeurs proviennent de la fiche d'équilibrage de l'auteur.
> Les lignes marquées ⚠️ signalent un **écart arithmétique** relevé à la transcription — voir `## 6. Matrice consolidée`.

---

### 1.1 — Fusil d'Assaut MA37

| Champ | Valeur |
|---|---|
| **Classe** | Principale |
| **Puissance** | **0,071 ART** · **0,568 ART/s** |
| **Cadence** | 0,125 s · 8 tirs/s |
| **Chargeur / Recharges** | 32 / 12 · réserve **384** |
| **Portée efficace** | 15 m · 25 m en mise en joue |
| **Anti-bouclier** | **×0,80** → 0,057 ART/tir · 0,454 ART/s |
| **Critique — armures / blindages** | **×1,25** sur **armures et blindages destructibles** → **0,086 ART · 0,690 ART/s** · s'applique **hors tir à la tête** *(§0.8)* |
| **Critique — points faibles** | **×1,25** → **0,086 ART · 0,690 ART/s** |
| **Critique — casques** | **×1,40** *(amélioré)* → **0,0966 ART · 0,966 ART/s** · **prime sur le ×1,25** quand le tir touche la tête d'une cible blindée *(§0.8)* |
| **Mise en joue** | LT · vue sur l'arête haute de l'arme, arme centrée · précision portée à 25 m, recul réduit · *fall-off* repoussé de 15 m à **35 m** |
| **Scaling** | Au-delà de 25 m le spread rend le gain inexploitable malgré l'absence de *fall-off* |

**Notes**

Arme d'ouverture du jeu et **arme des PNJ**. L'intention est explicite : le MA37 est *moins bon que la moyenne*, et c'est plus souvent un Marine qui le porte que Yumiko. Il tient le rôle d'équivalent humain du Répéteur à Plasma, pas celui d'une arme de choix.

La cible d'équilibrage annoncée est **un chargeur pour un Elite Minor**, et elle est désormais **tenue** : ✅ **0,071 ART** *(écart A tranché)*. Le compte tombe à **32 tirs pile** — 18 sur le bouclier (0,057 × 18 = 1,022, report 0,022) puis 14 sur la chair — pour 32 disponibles, DPS à **0,568**. Le chargeur rond est préservé, ce qui était l'intention lisible.

**Le MA37 a désormais trois critiques, et c'est ce qui le sauve.** ×1,25 sur les **armures et blindages destructibles**, ×1,25 sur les **points faibles**, et un ×1,40 **amélioré contre les casques**.

✅ **Les deux barèmes d'armure coexistent, départagés par la visée** *(§0.8)* : **×1,40 si le tir touche la tête**, **×1,25 sinon**. Le ×1,25 n'est donc pas écrasé par la propagation §0.8 — il est le **plancher** de l'arme contre tout ce qui est blindé, et le ×1,40 la **prime de précision**. Sur une arme automatique à 8 tirs/s et 32 balles, c'est le bon dosage : la rafale au corps reste rentable contre une plaque (0,690 ART/s), la rafale ciblée l'est 40 % plus (0,966 ART/s), et l'écart entre les deux — **+12 %** — se gagne au contrôle du recul, pas au hasard. Le MA37 n'est pas une arme de précision au sens du BR75 : c'est une arme qui **décape**, mais qui récompense maintenant la rafale courte et ciblée. Contre une plaque il monte à 0,690 ART/s (+25 % là où les autres fusils ne gagnent rien) ; contre un casque il atteint **0,966 ART/s**, soit **+70 % sur son DPS de base**.

**Le ×1,40 casque le réoriente vers les Brutes, et c'est délibéré.** Une faction dont l'armure est le trait dominant est exactement la cible que le ×1,25 armures et le ×1,40 casques servent le mieux — là où un Élite oppose d'abord un bouclier énergétique, contre lequel le MA37 subit son ×0,80. **Le MA37 est faible en environnement Élite et correct en environnement Brute.** Cette lecture doit guider sa disponibilité au sol : c'est sur les niveaux Jiralhanae qu'il mérite d'être posé en abondance.

Le burst initial n'a pas bougé — 0,071 contre 0,069, +3 % — donc la réhabilitation passe **entièrement par la compétence de visée**, pas par la puissance brute. C'est le bon levier : l'arme d'ouverture reste médiocre entre des mains passives et devient acceptable entre des mains précises. Combiné à la réserve de 384 balles — la plus grosse du CSNU après la SAW — il reste l'outil d'entretien d'un siège long.

C'est cohérent avec la correction antérieure : arme de **finition**, support de la mêlée Hornet, disponibilité maximale en Légendaire. Le joueur ne le choisit pas, il le **ramasse**, et il le ramasse tout le temps.

---

### 1.2 — Fusil d'Assaut MA5B

| Champ | Valeur |
|---|---|
| **Classe** | **Hybride Principale / Soutien** |
| **Puissance** | 0,059 ART · **0,885 ART/s** |
| **Cadence** | 0,0667 s · 15 tirs/s |
| **Chargeur / Recharges** | 60 / 5 · réserve **300** |
| **Portée efficace** | 10 m au spread · **rafales courtes 20–25 m** |
| **Anti-bouclier** | **×0,80** → **0,708 ART/s** |
| **Scaling** | **×0,65 dès 15 m** → 0,039 ART |
| **Mise en joue** | **Aucune** |
| **Mobilité** | **Pénalité de mobilité** en **duo ambidextre avec une arme spéciale** *(l'arme spéciale reste portable — c'est la différence avec le SRS99)* |

**Rafales longues — multiplicateur progressif**

| Seconde | Tirs | Mult. | ART/tir | ART/s | Contre bouclier | Critique points faibles |
|---|---|---|---|---|---|---|
| 1ʳᵉ | 1–15 | ×1,00 | 0,059 | 0,885 | 0,708 | — |
| 2ᵉ | 16–30 | ×1,25 | 0,074 | 1,106 | 0,885 | — |
| 3ᵉ | 31–45 | ×1,35 | 0,080 | 1,195 | 0,956 | **×1,20** → 1,434 ART/s |
| 4ᵉ | 46–60 | ×1,55 | 0,092 | 1,372 | 1,097 | **×1,35** → 1,852 ART/s |

Le malus bouclier ×0,80 s'applique **par-dessus** le multiplicateur de rafale, à tous les paliers.

**Notes**

C'est la meilleure idée de la sandbox CSNU. Le MA5B est la seule arme du jeu dont **la puissance est fonction de la durée d'engagement** — il récompense le joueur qui tient le doigt sur la gâchette et accepte de ne pas se replier. Sur un socle Halo CE sans sprint, où la couverture se paie en temps d'exposition, c'est une mécanique qui pousse exactement dans la bonne direction.

**Les cibles d'équilibrage sont tenues.** Vérification :

| Cible | Corps seul | Avec critique points faibles | Annonce |
|---|---|---|---|
| Elite Minor | 34 tirs · **2,27 s** | 33 tirs · 2,20 s | « pas trop vite » ✓ |
| Elite Major | 52 tirs · **3,47 s** | 49 tirs · **3,27 s** | « ~3 s si critique sur les derniers tirs » ✓ |
| Spec-Ops | 57 tirs · 3,80 s | 53 tirs · 3,53 s | — |
| Ultra — bouclier seul | **48 tirs · 3,20 s** | — | « ~3,20 s » ✓ **exact** |

Le chiffre de l'Ultra tombe **au centième près**. Et les 12 tirs restants du chargeur (0,80 s au palier ×1,55) infligent 1,10 ART sur une chair de 2,50 — ou **1,48 ART en visant la tête**, ce qui laisse l'Ultra à 40 % de vie. « Presque le tuer » est exact.

Le chargeur complet vaut **3,646 ART sur bouclier**, contre 3,50 pour le bouclier du Dévot : « à peu de choses près » ✓.

Il y a une conséquence que la fiche ne dit pas et qui mérite d'être vue : **le rechargement est le vrai coût de l'arme.** Recharger remet le multiplicateur à ×1,00. Un joueur qui vide 60 balles en 4 s puis recharge repart de 0,885 ART/s ; un joueur qui gère par rafales de 45 garde son palier 3 s de plus. Le MA5B a donc une **fenêtre de compétence sur la gestion du chargeur**, pas seulement sur la visée. C'est très bien — mais ça veut aussi dire que **les 5 recharges (300 balles) sont serrées** : à peine plus de 3 engagements longs. À surveiller en Légendaire.

**Hybride** : arme principale à part entière, la pénalité ne tombe qu'en dual handling avec une arme spéciale. C'est le seul fusil d'assaut du jeu à porter une contrainte de maniement.

---

### 1.3 — Magnum M6D

| Champ | Valeur |
|---|---|
| **Classe** | Légère |
| **Puissance** | **0,225 ART** · 0,563 ART/s |
| **Cadence** | 0,40 s · 2,5 tirs/s · **cadence de précision 0,60 s (1,66 tir/s)** |
| **Chargeur / Recharges** | 12 / 5 · réserve **60** |
| **Portée efficace** | 7–35 m |
| **Critique** | **×5,00** → **1,125 ART** |
| **Perforation** | **Pas de gaspillage** : le tir qui réduit une protection à zéro reporte intégralement · compte comme perforant contre les *protections vulnérables aux perforations* |
| **Scaling** | Dégâts décroissants **à partir de 35 m** → 0,15 ART · 0,375 ART/s |
| **Mise en joue** | Supprime **toute** dispersion (le tir de base en a une légère) · ne change rien d'autre |
| **Dual handling** | **Perd totalement le mode mise en joue** · spread légèrement augmenté |

**Notes**

La cible d'équilibrage est atteinte exactement. Contre un Elite Minor : **5 tirs sur le bouclier** (1,125 ART, report 0,125), il reste 0,875 de chair, **1 headshot à 1,125** finit. **6 coups = 50 % du chargeur**, précisément comme annoncé.

C'est un **nerf assumé et lisible** : tous les autres DMR du jeu sont calibrés au tiers de chargeur, le M6D est le seul à la moitié. La fiche le dit sans détour et c'est le bon choix — le Magnum CE a historiquement cannibalisé toute la sandbox, et le limiter par la **fraction de chargeur** plutôt que par les dégâts bruts préserve sa sensation de brutalité tout en bornant son emprise.

**La cadence de précision est le vrai système de l'arme.** 2,5 tirs/s possibles, 1,66 réellement exploitables : le joueur qui spamme perd en spread ce qu'il gagne en cadence. Un chargeur de 12 tiré proprement à 1,66 tir/s dure 7,2 s et abat deux Minors. Tiré vite, il en abat peut-être un. C'est du contrôle pur, exactement le M6D de 2001.

Le **report sans gaspillage** est important à noter : c'est ce qui rend le 6ᵉ coup létal. Sans lui, les 0,125 ART de surplus seraient perdus et le Minor survivrait au headshot avec 0,000… ART. La règle §0.4 n'est pas décorative ici, **elle est structurelle au TTK de l'arme**.

Point de vigilance : **60 balles de réserve totale**, la plus faible du CSNU hors armes lourdes. À 6 coups par Minor, c'est **10 Elites Minor par ramassage complet** — et beaucoup moins contre des cibles plus solides. Le M6D est une arme qu'on économise, pas une arme qu'on tient.

---

### 1.4 — Pistolet M6C

| Champ | Valeur |
|---|---|
| **Classe** | Légère |
| **Variante** | **M6C/SOCOM** |
| **Puissance** | **0,15 ART** · ART/s variable |
| **Cadence** | **Variable — limitée par la vitesse de clic du joueur** · 8 clics/s = **1,20 ART/s** |
| **Chargeur / Recharges** | 15 / 10 · réserve **150** |
| **Portée efficace** | 10–45 m max · *fall-off* dès **25 m** |
| **Perforation** | **Grognards et Rapaces** — headshot mortel |
| **Recul** | Fort · partiellement compensé sur le SOCOM |
| **Mise en joue** | Aucun changement |
| **Dual handling** | 16 recharges (**240**) · **voir tableau ci-dessous** |

**Dual handling — contreparties** *(point 11 tranché)*

| Point | Mono | **Dual** |
|---|---|---|
| Portée efficace | 10–45 m · *fall-off* dès 25 m | **6–20 m** |
| Cadence max par pistolet | libre (clic joueur) | **bornée à 6 coups/s** *(0,1666 s)* |
| DPS combiné max | 1,20 ART/s *(8 clics/s)* | **1,80 ART/s** |
| Spread | normal | **augmenté en rafale à vitesse maximale uniquement** — aucun spread si la rafale est contrôlée, même minimement |
| Seuil sans spread | — | **≤ 8 coups/s combinés** *(0,25 s entre deux tirs)* |
| Réserve | 150 | **240** |

**Variante SOCOM** — pas de *fall-off* à 25 m · moins de recul vertical · **peut tirer sans éveiller les ennemis** · **pas de réapparition lors du tir pendant un camouflage actif**.

**Notes**

Arme conforme à la correction antérieure : **0,12 ART contre bouclier** (0,15 × 0,80 si le malus balistique standard s'applique — à confirmer, la fiche ne mentionne pas de ligne anti-bouclier explicite), burst au clic rapide, perforant sur petites cibles, dual handling. Intouchable.

Le vrai intérêt de design est la **cadence pilotée par le joueur**. À 8 clics/s le M6C sort **1,20 ART/s**, soit plus que le M6D (0,563) et plus que le MA5B en palier 1 (0,885). C'est l'arme au plus haut plafond de DPS instantané du bas du roster — mais elle le paie en recul, en réserve, et en fatigue réelle du joueur. **Un burst à pas cher**, littéralement.

La perforation limitée aux **Grognards et Rapaces** est le bon garde-fou : ça en fait un nettoyeur d'escouade redoutable sans jamais menacer un Elite. Sur des formations qui « laissent peu de répit dès l'héroïque », pouvoir supprimer les Grognards d'un clic par tête pendant que le Triangle s'occupe des gradés est un rôle net.

Le **SOCOM silencieux qui n'éveille pas les ennemis** ouvre une porte que la sandbox n'a nulle part ailleurs sauf sur le SRS99/SSR : **l'ouverture furtive**. Deux armes seulement portent cette propriété, et elles sont aux deux extrêmes du roster. C'est une paire cohérente — sniper d'approche + pistolet de finition — et je recommande de la traiter comme un **couple de chargement** volontaire plutôt que comme deux accidents.

✅ **Les trois armes silencieuses — M6C/SOCOM, M7-S, SRS99C SSR — portent désormais la clause
« pas de réapparition lors du tir pendant un camouflage actif ».** Elle est le second étage du silence :
ne pas éveiller les ennemis règle le **son**, ne pas réapparaître règle la **vue**. Les deux réunis font
que ces trois armes sont les seules du roster à pouvoir tirer **sans sortir de la furtivité**, et cela
ferme définitivement la liste — *cf.* la règle posée avec l'abandon du BR75-S : plus aucune arme
généraliste silencieuse hors de ce trio.

⚠️ **Le camouflage actif n'est défini nulle part dans les documents.** Ni durée, ni source, ni
conditions de rupture, ni statut *(booster Yumiko ? objet de niveau ? propriété d'unité ?)*. Par
§0.7, la clause est donc **transcrite mais inactive** : elle décrit une exception à une règle qui
n'existe pas encore. Elle attend sa fiche — laquelle relève de `arcade-yumiko.md` si le camouflage est
une ressource du personnage.

✅ **Le dual est nerfé, et il l'est par la bonne variable.** Le point 11 relevait 2,40 ART/s à 8 clics avec 240 balles contre un M6D à 0,563 et 60 balles — un écart que le seul spread ne pouvait pas porter. La correction attaque sur **trois axes simultanés** plutôt que sur les dégâts :

| Levier | Effet |
|---|---|
| Cadence bornée à 6 c/s par arme | Plafonne le DPS à **1,80** au lieu de 2,40 — **−25 %** |
| Portée ramenée à **6–20 m** | Retire au duo la moitié de son domaine et **tout le tir à distance** |
| Spread conditionnel | Ne punit que le spam pur, pas le jeu contrôlé |

**La borne de cadence est la bonne trouvaille.** Elle retire au dual ce qui faisait sa force absurde — l'échelle libre du clic — tout en lui laissant 1,80 ART/s, soit **plus de trois fois le M6D**. Le duo reste le plus haut DPS soutenu du bas de roster ; il ne le tient plus qu'à **20 m maximum**, contre 45 m pour le mono. C'est une **conversion de portée en puissance**, pas un nerf sec, et elle est lisible par le joueur en une phrase : *deux pistolets, deux fois plus de balles, moitié moins de terrain.*

**Le seuil « pas de spread sous 8 coups/s combinés » mérite d'être souligné**, parce qu'il évite le piège classique du dual wielding punitif. Le joueur qui alterne proprement ses deux gâchettes à 4 c/s chacun n'est **jamais** pénalisé — il obtient 1,20 ART/s parfaitement précis, exactement le mono à 8 clics, avec le double de réserve. Le spam à 12 c/s combinés, lui, part en dispersion. **La compétence récompensée est le rythme, pas la vitesse**, ce qui est cohérent avec le M7-S et la cadence de précision du M6D. Trois armes légères, trois fois la même leçon : *tapoter vite est un piège.*

Reste l'écart de réserve — 240 contre 60 pour le M6D — mais il ne pose plus problème une fois la portée à 20 m : les deux armes ne travaillent plus au même endroit du terrain.

---

### 1.5 — Mitraillette M7 SMG

| Champ | Valeur |
|---|---|
| **Classe** | Légère |
| **Variante** | **M7-S SMG** *(SOCOM)* |
| **Puissance** | 0,045 ART · 0,540 ART/s |
| **Cadence** | **0,0833 s** · 12 tirs/s — **M7 et M7-S** |
| **Chargeur / Recharges** | 48 / 8 · réserve **384** |
| **Portée efficace** | **M7 : 15 m** · **M7-S : 30 m sans fall-off** |
| **Critique** | **M7 : aucun** · **M7-S : ×1,35 points faibles** → **0,061 ART · 0,732 ART/s** |
| **Mise en joue** | **M7 : aucune** · **M7-S : précision améliorée, recul réduit** |
| **Dual handling** | **M7 uniquement** — 10 recharges (**480**) · spread accru · **M7-S : pas de dual handling** |
| **Camouflage** | **M7-S : pas de réapparition lors du tir pendant un camouflage actif** |

**Notes**

Deux armes en une, et elles ne visent pas le même joueur.

**Le M7 est une arme de volume.** Aucun critique, aucune mise en joue, 15 m, mais 480 balles en dual handling. C'est le nettoyeur brut, celui qu'on prend quand la salle est pleine de Grognards et qu'on ne veut pas réfléchir.

**Le M7-S est désormais une arme de portée, plus une arme de burst.** ✅ *(point 10 tranché)* La mécanique de balle critique en fin de rafale est **entièrement supprimée**, et le critique points faibles descend de ×1,65 à **×1,35** — soit 0,061 ART et **0,732 ART/s** au lieu de 0,891.

C'est un nerf net, et il vise juste. Le problème n'était pas le DPS moyen du M7-S mais son **pic** : 0,223 ART sur une balle unique, la valeur d'un tir de M6D sortie d'une mitraillette, disponible à 30 m avec mise en joue. Cette combinaison le mettait en concurrence frontale avec le BR75 sur son propre terrain. En retirant le pic plutôt qu'en rabotant la portée, la correction **préserve l'identité de l'arme** — une SMG précise à moyenne distance — tout en lui retirant sa capacité à conclure un duel d'un coup.

Le M7-S garde donc : 30 m sans *fall-off*, mise en joue, recul réduit, ×1,35 sur les points faibles. Il perd : le pic de burst, et le dual handling qu'il n'avait déjà pas. **La séparation avec le BR75 se fait maintenant sur la nature du tir** — flux continu contre salve — et non plus sur une course au multiplicateur. Un joueur qui tient 0,732 ART/s à 30 m fait du travail de suppression ; un joueur au BR75 fait du travail d'exécution. Les rôles ne se recouvrent plus.

Le renoncement au dual handling sur le M7-S en échange de 30 m sans *fall-off* + mise en joue + double critique est un **arbitrage franc**, du même type que Principale vs Légère au niveau des classes. J'aime que le choix soit posé à l'intérieur d'une même arme.

✅ Cadence fixée à **0,0833 s** *(écart F)* pour les deux variantes, réserve à **384** *(écart G)* — la convention chargeur × recharges tient sur tout le roster.

---

### 1.6 — Revolver W0-LF M4

| Champ | Valeur |
|---|---|
| **Classe** | Principale |
| **Variante** | **W0-LF « Hunter »** |
| **Puissance** | **0,65 ART** · **0,975 ART/s** |
| **Cadence** | 0,66 s · 1,5 tir/s |
| **Chargeur / Recharges** | 8 / 3 · réserve **24** |
| **Portée efficace** | Variable |
| **Critique** | **×2,00** points faibles → **1,30 ART** · **×1,50 armures** → **0,975 ART** |
| **Scaling** | **Aucun** — pas de perte de dégâts avec la distance |
| **Mise en joue** | Oui · **pas de zoom** |
| **Dispersion** | Précision erratique dès que le joueur se déplace |

**Variante Hunter** — lunette **×2,5** · cadence ralentie à **1,00 s** entre les tirs.

**Notes**

**C'est l'arme la plus intéressante du roster CSNU, et ce n'est pas une arme à dégâts.** La fiche le dit : *« surtout un outil de physique pour la sandbox du jeu »*. Les effets listés sont des **verbes**, pas des chiffres :

- Stun et concussion très élevés
- **Wall splat** sur un ennemi stun par une balle
- **Retourne un véhicule** en tirs répétés
- Fait **exploser grenades et roquettes en vol** (annoncé comme excessivement difficile)

Sur une sandbox où « les ennemis sont tanky » et où « les gradés doivent être perturbés ou saturés », le W0-LF est **la clé de perturbation du CSNU**. Il ne tue pas un Elite Major (3,25 ART = 5 balles sur 8), mais il l'empêche de gagner du terrain, et c'est précisément ce que `comportement-de-l-ennemi.md` réclame.

**Il faut voir l'interaction avec Yumiko.** Un ennemi stun ne peut pas contrer une charge Spartane, ne peut pas esquiver une grenade, et offre son dos. Le combo signature — Bastonneur critique 0,65 puis Demi-tour frappe 0,35 = 1,00 ART — demande d'atterrir **derrière** la cible. Une balle de W0-LF qui fige un Major transforme ce combo d'une prouesse en une routine. **Le revolver est l'ouvre-boîte du sommet Mêlée du Triangle.** C'est le rôle que je lui donnerais explicitement.

**8 balles, 24 en réserve.** C'est le plus petit budget de munitions du CSNU après le lance-roquettes. Chaque balle est une décision. Bon.

La variante **Hunter** échange 33 % de cadence contre une lunette ×2,5. À 1,00 s entre les tirs le DPS tombe à 0,65 ART/s, mais le stun à distance sur un Chasseur en approche vaut probablement plus que le DPS. À traiter comme une arme différente, pas comme un sidegrade.

---

### 1.7 — Fusil de Combat BR75

| Champ | Valeur |
|---|---|
| **Classe** | Principale |
| **Puissance** | **0,12 ART/balle** · **0,36 ART/salve** · **0,536 ART/s** |
| **Cadence** | 0,111 s intra-salve · **0,45 s entre salves** · **1,488 salve/s** |
| **Chargeur / Recharges** | 36 (**12 salves**) / 4 · réserve **144** |
| **Portée efficace** | 10–75 m |
| **Critique** | **×5,00** → **0,60 ART/balle** · **1,80 ART/salve pleine** |
| **Bonus CASQUES** | **×1,35** → **0,162 ART/tir** · **0,486 ART/salve** |
| **Perforation** | **Têtes de Grognards et Rapaces** — mort instantanée |
| **Scaling** | **Aucun** |
| **Lunette** | **×2,5** |

**Notes**

Le BR75 domine le M6D et c'est **assumé**. La correction antérieure l'a acté : 4 salves sur un Minor, refus d'un DMR coup par coup façon Reach.

**Vérification des TTK — les deux comptes tombent.**

| Cible | Bouclier | Report | Chair restante | Finition |
|---|---|---|---|---|
| **Elite Minor** | **3 salves** (1,08) | 0,08 | 0,92 | **2 balles tête** (1,20) |
| **Elite Major** | **5 salves + 2 tirs** (2,04) | 0,04 | 1,21 | **2 balles tête** (1,20) |

✅ **Le Major est résolu, et la fiche avait raison.** *(écart B)* La lecture « 5 salves + 2 tirs » n'était pas une approximation de 6 salves : c'est **5 salves pleines (1,80) plus les deux premiers tirs de la sixième** (0,24), soit 2,04 sur un bouclier de 2,00. Le **troisième tir de la 6ᵉ salve part directement dans les PV** avec son report. Le bouclier du Major reste à **2,00**, chiffre pivot de la matrice, et aucune correction n'était nécessaire — la salve n'est pas une unité indivisible de dégâts, c'est une unité de cadence. **Bien vu.**

✅ **Le critique est bien ×5,00 → 1,80 par salve.** *(écart C)* Le 1,50 était un vestige d'une version antérieure où le BR75 valait 0,10 ART/tir (0,50 en critique, 1,50 par salve). La valeur courante est 0,12, donc **0,60 par tir critique et 1,80 par salve pleine**. Le M6D garde son ×5,00 lui aussi — les deux armes partagent le multiplicateur, elles se séparent sur la cadence et la fraction de chargeur, pas sur le critique.

Conséquence à assumer : **une salve pleine à la tête (1,80) tue la chair d'un Minor et celle d'un Major.** Mais placer trois balles sur une tête à 0,111 s d'intervalle est une exigence réelle, et le bouclier doit être tombé d'abord. C'est un plafond de compétence, pas un raccourci.

**Le nouveau bonus casques ×1,35 est l'ajout le plus important de la fiche.** 0,162 ART/tir, **0,486 par salve** — soit **+35 % contre les trois unités les plus solides de la matrice** : Ultra, Dévot et Général. Il faut mesurer ce que ça change : le BR75 devient la **deuxième arme anti-casque du CSNU**, après la SAW (×1,50). Mais là où la SAW est Lourde, courte portée et exige de tomber le bouclier d'abord avec son ×0,75, le BR75 est **Principale, 75 m, sans malus bouclier**. C'est un accès beaucoup plus large au même rôle.

| Arme | Mult. casque | Classe | Portée | Malus bouclier |
|---|---|---|---|---|
| **SAW** | ×1,50 | Lourd | 12–25 m | ×0,75 |
| **BR75** | **×1,35** | **Principale** | **10–75 m** | **aucun** |
| **MA37** | ×1,40 | Principale | 15–25 m | ×0,80 |

Le trio est cohérent une fois lu ensemble : la SAW **martèle** de près, le MA37 **décape** à moyenne portée contre les Brutes, le BR75 **cueille** à distance. Trois réponses au casque, trois distances, trois classes. ⚠️ Un point de vigilance toutefois : le BR75 dominait déjà le M6D, et ce bonus creuse encore l'écart puisque le M6D n'a rien contre les casques. **C'est le troisième avantage cumulatif du BR75 sur le Magnum** — après la portée et la fraction de chargeur. La domination reste assumée, mais elle n'a plus besoin d'être nourrie.

Le chargeur de 12 salves vaut **4,32 ART au corps** — de quoi vider un Minor et entamer un Major, ou tuer un Ultra en visant la tête. La **perforation sur les têtes de Grognards** en fait aussi un nettoyeur d'escouade à distance. C'est une arme complète, et 144 balles de réserve la rendent tenable. Le M6D n'a aucun argument en face, sinon le dual handling et la classe Légère.

---

### 1.8 — Fusil à Pompe M90 CAWS

| Champ | Valeur |
|---|---|
| **Classe** | Soutien |
| **Puissance** | **1,375 ART** · **0,825 ART/s** |
| **Cadence** | 1,666 s · 0,60 tir/s |
| **Chargeur / Recharges** | 6 / 4 · réserve **24** |
| **Portée efficace** | 5–12 m · *fall-off* dès **7 m** |
| **Critique** | **×1,50** points faibles → **2,062 ART** · **uniquement à moins de 4 m** |
| **Scaling** | *Fall-off* **×0,65** par dispersion à partir de 7 m |
| **Report** | Le surplus qui casse un bouclier passe **sans aucun scaling** |
| **Mise en joue** | *« Tir au jugé »* : précision autour de 10–15 m, recul et dispersion réduits · *fall-off* repoussé de 7 m à **9 m** · **distance critique portée à 5,50 m** |

**Notes**

Conforme à la correction antérieure : 1,375 ART, 0,60 tir/s, 6 cartouches, critique ×1,5 sous 5 m sur points faibles uniquement.

**Fraction de chargeur** — vérification :

| Cible | Cartouches | % du chargeur |
|---|---|---|
| Elite Minor | 2 | **33 %** |
| Apprenti Ultra | 2 | 33 % |
| Elite Major | 3 | **50 %** |

Le Minor tombe pile sur le tiers de chargeur. ⚠️ **Ce n'est pas un critère de conformité ici** : **D2 ne régit que les armes de précision légères**, et le M90 n'en est pas une. Le chiffre est noté comme repère de rythme, pas comme validation — un fusil à pompe se juge sur sa portée efficace et son *fall-off*, pas sur sa fraction de chargeur.

Le **report sans scaling** est ce qui rend l'arme mortelle : le tir qui casse un bouclier à 50 % restant place 0,875 ART dans la chair, en pleine puissance. Contre un Minor, deux cartouches suffisent parce que la première ne gaspille rien.

La note de design de la fiche est la plus lucide du document : *« au moindre déséquilibre, cette arme peut cannibaliser l'équilibrage comme celui de CE l'a fait en son temps »*. Les trois garde-fous posés sont les bons :

1. **6 cartouches, 24 en réserve** — quatre chargeurs, soit 12 Minors maximum sur toute une réserve
2. **Critique à moins de 4 m** — plus court que la portée efficace, il faut *entrer*
3. **1,666 s entre les tirs** — un ennemi tanky survit toujours au premier coup

Mais le vrai garde-fou est ailleurs, et il est structurel : **la classe Soutien taxe le boost en déplacement.** Le M90 exige d'être à 4 m pour critiquer, et il retire précisément l'endurance de course qui permet d'y arriver. **L'arme se contredit elle-même**, et c'est excellent — elle force à passer par le kit de Yumiko (dash, wall jump, slide, charge) plutôt que par la course. La fiche dit vouloir « obliger les joueurs à maîtriser le kit de Yumiko pour l'exploiter » : le choix de classe le réalise mécaniquement, pas seulement par intention.

Le **tir au jugé qui porte la distance critique à 5,50 m** est le déblocage de compétence de l'arme. +37 % de fenêtre de critique contre un ralentissement de course : sur un ennemi qui charge, c'est le bon marché.

---

### 1.9 — Fusil de Sniper SRS99C S2

| Champ | Valeur |
|---|---|
| **Classe** | **Hybride Soutien / Lourd** |
| **Variante** | **SRS99C SSR** *(Stealth Suppressor Recon)* |
| **Puissance** | **1,50 ART** · 3,00 ART/s |
| **Cadence** | 0,50 s · 2,0 tirs/s |
| **Chargeur / Recharges** | 4 / 5 · réserve **20** |
| **Portée efficace** | Infinie (> 50 m) |
| **Anti-bouclier** | **×0,75** → **1,125 ART/tir** |
| **Perforation** | **PERFORATEUR — nécessite un coup critique** *(voir notes)* |
| **Lunette** | **×3** puis **×8** |
| **Mobilité** | **Maniabilité NON pénalisée** · **interdiction de porter une arme spéciale** — donc **pas d'ambidextrie avec une arme de CAC spéciale** |

**Variante SSR** — silencieux · tissus enroulés autour du corps (chargeur découvert) · **n'éveille pas les ennemis à bonne distance** si les cadavres ne sont pas vus · dégâts de base **1,00 ART**, **0,75 ART contre bouclier** *(malus ×0,75, identique au S2)* · chargeur **5 / 7 · réserve 35** · **pas de réapparition lors du tir pendant un camouflage actif**.

**Notes**

**Le perforateur du SRS99 est un sous-système à trois clauses**, et c'est le plus complexe du CSNU :

1. **Le headshot tue n'importe quel ennemi**
2. Les dégâts passent **à travers les armures même hermétiques**, sans scaling ni multiplicateur
3. **Si la balle termine la protection, les dégâts restants sont reconvertis en headshot mortel** — sauf protection hermétique, où seul le reliquat est infligé

La clause 3 est la plus forte du jeu : elle transforme le report en **exécution**. Vérification par cible, bouclier attaqué à 1,125 ART/tir :

| Cible | Balles sur bouclier | Report | Effet |
|---|---|---|---|
| Elite Minor | 1 | 0,125 | **Mort** (reconversion) |
| Elite Major | 2 | 0,250 | **Mort** |
| Elite Ultra | 3 | 0,625 | **Mort** |
| Elite Dévot | 4 | 1,000 | Casque **anti-perforation** → 1,00 ART seulement sur 2,25 de chair |
| Elite Général | 6 | 0,750 | **Mort** |

**Le Dévot est la seule unité du jeu qui survit à la clause 3**, exactement comme sa fiche le prévoit. C'est une belle articulation entre la matrice de solidité et le sous-système d'une arme : le casque anti-perforation n'est pas une statistique décorative, c'est **la réponse de la sandbox au SRS99**.

Le **malus bouclier ×0,75** est le contrepoids. Il coûte 1 à 2 balles sur les cibles à gros bouclier, et avec un chargeur de 4, un Général mobilise **1,5 chargeur** rien qu'en bouclier. Sur 20 balles de réserve, c'est trois Généraux et rien d'autre. L'arme est chirurgicale par contrainte de munitions, pas par choix.

**L'hybride Soutien/Lourd est bien pensé** : Yumiko garde sa mobilité de Soutien — donc le dash, la charge, le wall jump, à la seule perte du boost en déplacement — mais perd les armes spéciales, donc la **Lance Spartane**. Le sniper et la lance sont mutuellement exclusifs. C'est un vrai choix de chargement, et il oppose les deux extrémités du Triangle : portée infinie contre corps à corps.

✅ **L'écart E était une confusion de lecture de ma part, pas une erreur de fiche.** Le « 0,75 » n'était pas une pénalité soustraite de 1,50 : c'est le **malus anti-bouclier ×0,75**, exactement le même que celui du S2, appliqué à une base de **1,00 ART**. Le SSR tape donc **1,00 sur la chair et 0,75 sur le bouclier**. Aucune valeur à corriger — la règle générale s'appliquait, il fallait simplement la lire comme telle.

Conséquence sur le terrain : à 0,75 contre bouclier, il faut **2 balles** pour percer celui d'un Minor là où le S2 n'en demande qu'une (1,125 > 1,00). Le chargeur de 5 et les 35 balles de réserve compensent exactement ce doublement. Le SSR est l'arme de **l'engagement long et discret**, le S2 celle du **retrait rapide**. La hiérarchie est nette et le rôle d'ouverture furtive est préservé.

---

### 1.10 — Lance-Roquettes M41 SSR MAV/AW

| Champ | Valeur |
|---|---|
| **Classe** | Lourd |
| **Puissance** | Impact **1,00 ART** · Souffle **2,50 ART** · **Total 3,50 ART** |
| **Cadence** | 1,75 s · 0,567 tir/s |
| **Chargeur / Recharges** | 2 / 3 · réserve **6** |
| **Portée efficace** | Tir **15 m** · souffle **0–7 m** de diamètre |
| **Anti-bouclier** | **Souffle seul** ×0,66 → **1,65 ART** · **l'impact n'est jamais affecté** — un contact direct passe à 1,00 ART même sur cible protégée |
| **Nature** | **Impact et souffle sont tous deux cinétiques** |
| **Scaling** | Souffle par diamètre — voir tableau |
| **Lunette** | **×2** puis **×4** |
| **Anti-véhicule** | Même scaling de souffle appliqué |

**Scaling du souffle**

| Diamètre | Mult. | ART |
|---|---|---|
| 0–3 m | ×1,00 | 2,50 |
| 3,01–7 m | ×0,70 | 1,75 |
| 7–10 m *(max)* | ×0,45 | **1,125** |

> **Souffle (§0.9)** — l'explosion de cette arme **éteint un feu d'un seul coup**, au sol comme sur un ennemi.

**Notes**

**CHOC** : le souffle **ne peut pas être arrêté par les boucliers de Rapace lourds**. C'est la réponse du CSNU aux porte-boucliers, et elle est unique dans le roster.

Le point structurant : **un contact direct ne tue qu'un Elite Minor.**

| Cible | Solidité | 1 roquette au contact (1,00 + 1,65) | Reste |
|---|---|---|---|
| Elite Minor | 2,00 | **2,65** | **Mort** |
| Elite Major | 3,25 | 2,65 | 0,60 |
| Elite Ultra | 5,25 | 2,65 | 2,60 |
| Elite Général | 8,50 | 2,65 | 5,85 |

Le malus bouclier ×0,66 sur le souffle est **très sévère** : il retire 0,85 ART, soit 24 % du total de l'arme. Un Major survit à une roquette en pleine poitrine. Sur une arme à **2 tirs et 6 en réserve**, ça veut dire que **le lance-roquettes n'est pas une arme anti-Elite** — c'est une arme anti-véhicule et anti-groupe, ce que confirme le rayon de 10 m et le scaling par diamètre.

C'est un choix défendable et je pense qu'il est bon : le roquette-spam a ruiné l'équilibrage de plusieurs Halo. Mais il faut l'assumer jusqu'au bout dans le level design — **6 roquettes dans toute une réserve, c'est un moment de niveau, pas une arme de chargement.**

✅ **Impact et souffle sont tous deux cinétiques**, et **seul le souffle** porte la pénalité anti-bouclier. Une roquette qui **touche** l'ennemi place donc ses 1,00 ART pleins, protection ou non ; c'est uniquement l'onde qui est dégradée à ×0,66. Le total au contact reste **2,65 ART** contre une cible protégée.

Ça donne au M41 une propriété que sa fiche ne soulignait pas : **viser juste vaut 0,34 ART de plus que viser aux pieds** face à un bouclier. Sur une arme à 6 roquettes de réserve totale, l'écart est réel — c'est un cinquième de la chair d'un Minor par tir. Le lance-roquettes récompense le tir direct, ce qui va à l'encontre de l'habitude Halo du tir au sol, et c'est très bien : ça le distingue du M319, qui lui travaille par zone.

---

### 1.11 — Laser Spartan M6 G/GNR

| Champ | Valeur |
|---|---|
| **Classe** | Lourd |
| **Puissance** | **3,50 ART** |
| **Cadence** | Charge **2,50 s** · surchauffe **4,50 s** |
| **Chargeur / Recharges** | Batterie **100 %** — **5 tirs** *(20 %/tir)* · **pas de recharge au sol** |
| **Recharge cinétique** | **+0,35 %** de batterie par **0,01 ART ou ANB** infligé **en attaque de mêlée** · **taux amélioré +0,525 %** *(×1,50)* si le joueur porte une **Lance Spartane** |
| **Portée efficace** | Infinie (> 50 m) |
| **Perforation** | **Headshots mortels** hors protections hermétiques · perfore les **armures hermétiques** sans scaling · headshot mortel **dès que le tir outrepasse la protection** |
| **Anti-véhicule** | **PERFORATEUR** — tirer sur le conducteur = **critique** |
| **Lunette** | **×2**, **×3,5**, **×6** |

**Notes**

**3,50 ART en un tir, sans malus bouclier.** C'est la seule arme du CSNU à ne subir **aucune pénalité** contre les boucliers énergétiques — le SRS99 est à ×0,75, le M90 et le MA37 à ×0,80, la SAW à ×0,75, le lance-roquettes à ×0,66 sur son souffle. Le laser passe intégralement.

Conséquence directe : **il tue d'un tir tout ce qui est en dessous de 3,50 ART de solidité totale** — Furtif, Minor, Disciple Dévot, Apprenti Ultra, Major (3,25). Le Spec-Ops à 3,75 survit avec 0,25. Et la clause « headshot mortel dès que le tir outrepasse la protection » signifie qu'**en visant la tête, il tue tout ce qu'il perce**, quelle que soit la chair derrière.

Le contrepoids est entièrement temporel : **2,50 s de charge**. À l'échelle du jeu c'est une éternité — le MA5B place 37 balles dans le même temps, Yumiko traverse 3 m au palier 2. Et **4,50 s de surchauffe** si on relâche mal. Le laser est une arme de **prédiction**, pas de réaction : il faut avoir raison 2,5 s à l'avance sur une sandbox où les ennemis esquivent, paniquent et se déplacent.

Le **perforateur anti-véhicule sur le conducteur** est le complément du lance-roquettes : la roquette détruit la carcasse, le laser tue le pilote. Deux armes lourdes, deux réponses au même problème, aucune redondance. Bien.

✅ **Batterie fixée à 5 tirs à 20 %** *(écart I)*, alignée sur la Lance Spartane. Chaque tir est un cinquième visible : la ligne « énergie CSNU » est homogène.

**Le rework de recharge cinétique change entièrement l'arme.** La batterie ne se recharge pas au sol — elle se recharge **à la mêlée**, à raison de **0,35 % par 0,01 ART ou ANB infligé**, porté à **0,525 % avec une Lance Spartane**.

Ce que ça donne en pratique, sachant qu'**un tir coûte 20 %** :

| Source de mêlée | Dégâts | Batterie *(0,35 %)* | Taux amélioré *(0,525 %)* |
|---|---|---|---|
| Mêlée de base | 0,35 ART | **12,25 %** *(0,61 tir)* | 18,375 % |
| Mêlée critique *(≥ 1,10)* | 0,65 ART | **22,75 %** *(1,14 tir)* | 34,125 % |
| Mêlée aérienne | 0,80 ART | 28,0 % | 42,0 % |
| Critique dorsal | 1,00 ART | **35,0 %** *(1,75 tir)* | 52,5 % |
| Lance Spartane, 3 unités | 1,05 ART | — | **55,125 %** |
| Critique dorsal sur base 0,65 *(D14)* | 1,95 ART | 68,25 % | **100 %** *(plafond ; 102,375 théoriques)* |

**À 0,35 %, la recharge devient un appoint et non une source.** Le taux de change s'établit à **0,571 ART de mêlée pour un tir**, soit **1,6 mêlée de base** — deux coups de poing pour une charge, avec du reste perdu. Remplir une batterie vide demande **2,857 ART de mêlée cumulés** (1,905 au taux amélioré), c'est-à-dire huit mêlées de base ou près de trois critiques dorsaux, sur un socle sans sprint et au contact d'ennemis tanky.

Le seuil intéressant est le **critique dorsal à 35 %** : il rend 1,75 tir, donc **un dorsal ne finance pas deux tirs**. Aucune mêlée unique du répertoire ne rend une batterie pleine, sauf le cas extrême du dorsal sur base 0,65 *(D14, 1,95 ART)* qui plafonne — et encore, seulement au taux amélioré.

Cinq tirs restent cinq tirs : la mêlée en ajoute un, deux au mieux sur un engagement long. **La rareté reste l'identité de l'arme**, la recharge n'est qu'une prime à l'agressivité. Mon point de vigilance tombe définitivement.

Le **taux amélioré à 0,525 %** *(×1,50)* garde tout son sens et devient même le vrai argument du couple : il fait passer le dorsal de 1,75 à 2,6 tirs et un coup de lance sur trois unités à 55 % de batterie. **Le chargement laser + lance reste explicitement récompensé**, sans être obligatoire.

Note de cohérence : le taux est indexé sur les **ANB** autant que sur l'ART, donc frapper un véhicule recharge aussi. Le barème ANB étant encore à poser, **ce taux devra être revérifié une fois la grille véhicule publiée** — 0,35 % par 0,01 point ANB n'aura pas le même rendement selon l'échelle retenue.

---

### 1.12 — Lance-Grenades M319 IGL

| Champ | Valeur |
|---|---|
| **Classe** | **Hybride Principale / Lourd** |
| **Variante** | **M101 FGL** / prototype **FL01** |
| **Puissance** | **1,25 ART** · 0,550 ART/s |
| **Cadence** | Chargement **2,25 s** · 0,44 tir/s |
| **Chargeur / Recharges** | **1** · réserve **24** |
| **Portée efficace** | 7–25 m |
| **Anti-bouclier** | **×0,60** → **0,75 ART** — inefficace contre les boucliers |
| **Charge — adhésive** | **×1,40** → **1,75 ART** · **endommage à travers le bouclier** |
| **Charge — détonation aérienne** | Effet **anti-bouclier** · IEM **1,25 ART** · **×0,40** contre PV et armures → 0,50 ART |
| **Mise en joue** | Supprime **100 %** du spread — grenade parfaitement droite |
| **Anti-véhicule** | IEM **4 s d'immobilisation** *(valeurs ANB à définir — grille à venir)* |

**Variante FL01** — tire les **grenades incendiaires** ramassables sur les cadavres · maintenir *recharger* pour transférer les grenades vers la réserve de l'arme, **jusqu'à 6**.

> **Souffle (§0.9)** — l'explosion de cette arme **éteint un feu d'un seul coup**, au sol comme sur un ennemi.

**Notes**

**L'arme la plus riche du CSNU en nombre de décisions par tir.** Trois modes qui ne visent pas les mêmes cibles :

| Mode | Contre bouclier | Contre chair / armure | Contre véhicule |
|---|---|---|---|
| Direct | 0,75 *(mauvais)* | 1,25 | *ANB à définir* |
| **Adhésif** | **traverse** — 1,75 sur la chair | 1,75 | *ANB à définir* |
| **IEM aérien** | **1,25 anti-bouclier** | 0,50 *(mauvais)* | **4 s d'immobilisation** |

C'est un **triangle interne à l'arme**, et il reproduit à l'échelle du chargeur la logique du Triangle global. Le joueur ne choisit pas « une bonne option » : il choisit **contre quoi** il tire. L'adhésif tue un Elite sans percer son bouclier — c'est la clé anti-bouclier la plus élégante du CSNU, et elle est **contextuelle** (il faut coller, donc s'approcher, donc s'exposer). L'IEM fait l'inverse : il décape le bouclier à distance mais ne finit personne.

**Chargeur de 1.** C'est le vrai coût. 2,25 s de rechargement entre chaque tir, avec un choix de mode à faire à chaque fois. Sur 24 grenades de réserve, c'est 54 s de rechargement cumulé. L'IGL n'est pas une arme d'engagement continu, c'est une arme de **ponctuation**.

L'**hybride Principale/Lourd** porte le **verrou d'interdiction de port** *(**D16**)* : **maniabilité non pénalisée**, mais **aucune arme spéciale**, donc pas de Lance Spartane. À distinguer du MA5B, qui ne l'interdit pas mais **taxe la mobilité** en duo ambidextre — les deux verrous ne se déduisent jamais l'un de l'autre. C'est cohérent : **les armes qui donnent une réponse à tout perdent le corps à corps signature.**

La variante **FL01 qui recycle les grenades incendiaires ramassées** est une très bonne idée d'économie de sandbox : elle donne une seconde vie à une ressource de niveau et crée une raison de fouiller les cadavres. Elle croise aussi le système de kits de soin partiels récupérables sur certains ennemis — même boucle de ramassage, deux récompenses différentes. À exploiter dans le level design.

Les valeurs anti-véhicules chiffrées ont été **retirées de la fiche** : l'équilibrage ANB constitue une grille à part entière et sera traité en temps voulu. Seule subsiste l'immobilisation IEM de **4 s**, qui est un effet de contrôle et non une valeur de dégâts.

---

### 1.13 — Lance-Flammes

> ### ⚠️ Fiche à double régime — lire avant tout
>
> | Ce que couvre… | Régime |
> |---|---|
> | **Cette fiche** | **Le jet de flammes direct.** Tous les chiffres ci-dessous **restent valides** *(arbitrage auteur)* |
> | **La matrice §5** | **La flaque au sol et la brûlure résiduelle** — type **Incendier**, 0,18 ART/s · flaque 5,00 s · brûlure 3,00 s |
>
> Sont donc **périmés dans cette fiche** : le résiduel **3,60 s**, la flaque **3,00–5,40 s**, le seuil
> des **10 flammes** et l'extension **+8 flammes**. Tout le reste — 0,125 par flamme, le cumul ×12,
> l'escalade 0,1375 / 0,15, le burst **1,50 ART/s**, le malus **×0,35** — **fait toujours foi**.
>
> **La conversion tombe juste au millième** : ancien résiduel maximal **0,15 × 3,60 s = 0,540 ART**,
> nouveau résiduel Incendier **0,18 × 3,00 s = 0,540 ART**. **Exactement la même valeur.** Le type
> Incendier reproduit le sommet de l'ancien système sans que le joueur ait à cumuler douze flammes —
> il concentre le même total sur une fenêtre plus courte et plus intense. **Rien ne se perd.**

| Champ | Valeur |
|---|---|
| **Classe** | **Hybride Lourd / Soutien** |
| **Puissance** | Flamme **0,125 ART** *(instantanés)* · **1,25 ART/s** de base · **1,50 ART/s max au cumul plein** |
| **Cadence** | Flamme 0,1 s · 10 tirs/s · brûlure 0,1 s · 10 effets/s |
| **Chargeur / Recharges** | 100 / 3 · réserve **300** |
| **Portée efficace** | 4–8 m · **max 12 m** |
| **Brûlure résiduelle** | **0,125 ART** par flamme · **0,30 s** de base, durée cumulative |
| **Anti-armure** | **×0,35** sur la puissance (**0,50 ART/s max**) **et** sur la durée résiduelle cumulée (**1,2 s max**) · la brûlure **passe à travers l'armure** — **2 s max**, **sans scaling**, et **tant que la cible reste sous le feu** |

**Système de brûlure** *(rework complet)*

| Point | Règle |
|---|---|
| Effet d'une flamme | **0,125 ART instantanés** + une **brûlure résiduelle de 0,125 ART** |
| Durée d'une brûlure | **0,30 s** |
| Seconde flamme | **Cumule les instantanés** *(0,25 ART sur 0,2 s)* et **double la durée résiduelle** |
| Cumul maximum | **12 flammes** |
| Durée résiduelle max | **3,60 s** |
| Escalade au-delà de 10 flammes | La **11ᵉ** porte les 10 précédentes à **0,1375 ART** · la **12ᵉ** les porte à **0,15 ART** |
| **Burst maximum** | **1,50 ART/s** |

**Montée en puissance du feu nourri**

| Flammes placées | Valeur unitaire | ART/s | Résiduel |
|---|---|---|---|
| 1 | 0,125 | 0,125 | 0,30 s |
| 10 | 0,125 | **1,25** | 3,00 s |
| **11** | **0,1375** | **1,375** | 3,30 s |
| **12** | **0,15** | **1,50** | **3,60 s** |

**Flamme au sol**

| Point | Règle |
|---|---|
| Seuil d'apparition | **10 flammes minimum** → **3,00 s** de durée |
| Extension | **+8 flammes** *(18 au total)* → **5,40 s**, durée maximale |
| Montée en puissance | **+2 flammes** → **0,15 ART/s** |
| Sur une cible | 1 s passée dans la flamme au sol = **3 s** de brûlure résiduelle |

**Notes**

La fiche parle d'une arme « injustement méprisée », et le système proposé la réhabilite par un mécanisme que le CSNU n'a nulle part ailleurs : **la puissance différée**. Tout ce que le lance-flammes place continue de brûler après que le joueur a arrêté de tirer et s'est mis à couvert. Sur un socle sans sprint, où rompre le contact coûte cher, une arme qui **continue de travailler pendant le repli** a une valeur tactique réelle.

**Le cumul est la mécanique centrale, et le rework le rend beaucoup plus fort qu'il ne l'était.** Chaque flamme vaut désormais **0,125 en instantané et 0,125 en résiduel** — la brûlure n'est plus un dixième de la flamme, elle en est le **double emploi**. Douze flammes, soit 1,2 s de tir continu, produisent 1,50 ART/s au burst **et** laissent 3,60 s de brûlure derrière elles.

Sur une cible non blindée, un joueur qui arrose 1,2 s puis décroche a placé **1,50 ART directs**, et laisse un résiduel qui continue de courir sur 3,60 s. Le total dépasse largement la chair d'un Elite Minor. **Le lance-flammes n'est plus l'anti-Grognard du roster : c'est une arme qui tue un Élite Minor en une passe**, à condition de réussir cette passe.

**Et c'est là que la puissance se justifie.** Le projectile est **lent, à la manière du Halo CE d'origine** : la flamme met du temps à parcourir la distance, l'arme est peu mobile, et maintenir douze flammes sur un ennemi qui se déplace constamment relève de la performance. Les 12 flammes ne sont pas un régime nominal, c'est **le cas parfait** — celui d'une cible acculée, surprise, ou trop lente. Contre une IA qui esquive, panique et se replie, le joueur réaliste place quatre à sept flammes et compte sur le résiduel pour finir.

**La puissance par seconde très élevée est donc assumée**, et le contrepoids n'est pas dans les chiffres : il est dans la difficulté de les atteindre. C'est un design qui récompense la lecture du déplacement adverse plutôt que le réflexe, ce qui est cohérent avec le reste de la sandbox. La vraie question du lance-flammes n'est pas *« combien inflige-t-il ? »* mais *« combien de flammes le joueur pose-t-il réellement ? »* — et la réponse dépend entièrement du comportement ennemi, donc de `comportement-de-l-ennemi.md`, pas de cette fiche.

L'escalade des deux dernières flammes est une jolie trouvaille technique : plutôt que d'ajouter un 11ᵉ et un 12ᵉ tick, elle **revalorise rétroactivement les dix premiers** (0,125 → 0,1375 → 0,15). Le joueur ne gagne pas en volume, il gagne en densité. Mécaniquement c'est la même chose ; en ressenti, ça donne une sensation d'embrasement plutôt que d'accumulation, ce qui est exactement ce qu'on veut d'un lance-flammes.

**Le malus ×0,35 contre les blindages est le bon contrepoids**, et il porte sur les deux axes : la puissance tombe à **0,50 ART/s max** et la durée résiduelle cumulée à **1,2 s**. Mais la clause de traversée est plus généreuse qu'avant : la brûlure passe à travers l'armure **sans scaling**, jusqu'à **2 s**, et surtout **tant que la cible reste sous le feu**.

Cette dernière condition est celle qui compte. Un Chasseur maintenu sous la flamme subit une brûlure **non dégradée** en continu — le malus ne s'applique qu'à ce qui persiste après le décrochage. **L'arme récompense donc le maintien du contact contre les blindés** et le décrochage contre la piétaille. Deux usages opposés pour la même gâchette, décidés par la nature de la cible. C'est de la profondeur obtenue sans ajouter un seul bouton.

**La flamme au sol a maintenant un coût d'entrée, et c'est la meilleure correction du rework.** Elle n'apparaît qu'à partir de **10 flammes** — un joueur qui tapote n'en produit pas. Il faut **1 s de tir continu** pour poser 3,00 s de feu au sol, et **1,8 s** pour atteindre les 5,40 s maximum.

| Investissement | Retour |
|---|---|
| 10 flammes *(1,0 s)* | 3,00 s de zone |
| 12 flammes *(1,2 s)* | 3,00 s de zone à **0,15 ART/s** |
| 18 flammes *(1,8 s)* | **5,40 s** de zone |

C'est un **taux de change explicite entre exposition et contrôle de terrain** : le joueur paie en secondes d'immobilité offensive ce qu'il obtient en secondes d'interdiction. Sur un socle sans sprint où la couverture se paie en temps d'exposition, 1,8 s le doigt sur la gâchette est un vrai engagement.

La règle « 1 s dans la flamme au sol = 3 s de brûlure résiduelle » est le multiplicateur qui rend la zone dissuasive : un ennemi qui traverse ne prend pas 1 s de feu, il en prend quatre. **Le rapport est de 1 pour 3**, ce qui est assez brutal pour que l'IA doive réellement contourner — et c'est là que la flamme au sol devient un outil de **direction de flux** plutôt qu'un simple tapis de dégâts. À exploiter dans les goulots.

✅ **L'écart H est résolu par le rework, et les deux branches tombent d'elles-mêmes.** Le 1,50 ART/s n'était pas une erreur : c'est bien le **burst maximum au cumul plein**, obtenu par l'escalade des 11ᵉ et 12ᵉ flammes, tandis que 1,25 reste le régime nominal à dix flammes. Quant au 0,175 ART/s résiduel, il disparaît purement : la brûlure vaut désormais **0,125 par flamme**, alignée sur l'instantané, et ce n'est plus un débit mais une **valeur adossée à une durée cumulative**. Le système est arithmétiquement clos.

**Sur la puissance par seconde : rien à ajuster, et le débat est clos.** Les chiffres bruts placent le lance-flammes très haut, mais trois contraintes simultanées les rendent difficiles à réaliser — **projectile lent façon CE**, portée de 4 à 8 m, mobilité réduite. Le vrai plafond de l'arme n'est pas son ART/s, c'est **le nombre de flammes que le joueur parvient à maintenir sur une cible mobile**.

| Flammes réellement placées | Contexte plausible | ART direct |
|---|---|---|
| 3–5 | Ennemi mobile, engagement de passage | 0,375–0,625 |
| 6–9 | Ennemi ralenti, couloir, ou surpris | 0,75–1,125 |
| **10–12** | Cible acculée, *stun*, ou flamme au sol traversée | **1,25–1,50** |

Le régime haut est un **cas parfait**, pas une moyenne. C'est un profil de risque inverse de celui du laser : le laser demande d'avoir raison 2,5 s à l'avance, le lance-flammes demande d'avoir raison **pendant** 1,2 s. Les deux se paient en exposition, sur un socle sans sprint.

Si un ajustement devenait nécessaire au playtest — ce que je n'anticipe plus — **le levier resterait le nombre de flammes cumulables** (12 → 8, ce qui retire l'escalade et plafonne à 1,00 ART/s), jamais les 0,125 unitaires qui font la cohérence du système.

**Cohérence avec §0.3 et §0.9** *(⚠️ section absorbée — voir §5.0, §5.2 et §5.4)* — deux vérifications qui devaient être faites : le cumul du lance-flammes ne contredit pas la règle « ni dégressivité ni cumul, le dernier foyer remplace », parce que celle-ci arbitre le cumul **entre plusieurs sources de feu distinctes**, alors qu'il s'agit ici du **cumul interne d'une même source continue**. Les deux règles vivent à des échelles différentes. En revanche §0.9 s'applique pleinement : **un souffle d'explosion éteint d'un coup la flamme au sol comme la brûlure sur cible**, y compris au cumul 12. Une frag bien placée annule 1,8 s de travail au lance-flammes.

L'**hybride Lourd/Soutien** est le seul du roster à combiner deux classes restrictives — la SAW ayant basculé en **Lourd FIXE – Lourd** *(point 6)*. ✅ **Tranché — le Lance-Flammes prend le verrou d'interdiction de port** *(**D16**)* : maniabilité non pénalisée, mais **aucune arme spéciale**, donc pas de Lance Spartane. Le principe **R6** reste valable — les hybridations sont décidées au cas par cas, jamais déduites d'une convention — mais ce cas-ci est désormais décidé et versé à la liste des sept.

---

### 1.14 — Lance Spartane

| Champ | Valeur |
|---|---|
| **Classe** | **SPÉCIALE** — arme signature de Yumiko · systématique en mode **Ronin** |
| **Puissance** | **0,35 ART par unité touchée** |
| **Cadence** | **1 s de recovery** après chaque coup |
| **Chargeur / Recharges** | Batterie **100 %** unique · **20 % par tir** |
| **Portée efficace** | **0–6 m** · **critique de 6,01 à 7,50 m** · mêlée 2,50 m |
| **CAC** | À très courte portée, **ajoute les dégâts d'un coup de mêlée** à 0,35 |
| **Mise en joue** | **Charge une attaque** |
| **Dual handling** | **Possible** — c'est une arme spéciale |
| **Passif** | **Marche portée à 1,10** de vitesse |

**Système d'unités**

| Repère | Valeur |
|---|---|
| 1 unité | Largeur d'épaule d'Élite |
| Élite | **2,50 unités** de haut |
| Spartan | **2,15 unités** de haut · **0,85 unité** vu à 7,50 m |
| Largeur en bout de course | **7 unités** |
| Dégâts | **0,35 ART par unité** touchée |
| Cible < 1 unité | Arrondi à **1 unité** |
| Cible ≥ 1 unité | Multiplication **précise** par la longueur touchée |
| **Plafond par ennemi** | **3 unités** — au-delà, scaling **×0,85** → 0,0525 par unité |
| **Dégâts max sur une cible** | **1,05** + 0,21 = **1,26 ART** |

**Consommation par palier de vitesse**

| Palier | Momentum réel | Coût par coup | Tirs par batterie |
|---|---|---|---|
| 0 | **< 1,10** | **20 %** | 5 |
| 1 | **1,10** *(marche portée, momentum atteint)* | **10 %** *(÷2)* | **10** |
| **2** | **1,11–1,35** | **5 %** *(÷4)* | **20** |

> **Le palier est indexé sur le momentum réel, pas sur la vitesse nominale.** Le passif « marche à 1,10 » place Yumiko au palier 1 **dès qu'elle a effectivement atteint cette vitesse**. Elle retombe au palier 0 (20 %) chaque fois que son momentum passe sous 1,10 : accélération non terminée, perte d'inertie, freinage au *slide*, sortie de BRS, ou dérapage dont la dérive dissipe momentanément la vitesse avant reprise de la course linéaire.

**Recharge cinétique**

| Source | Gain |
|---|---|
| Consommation de booster (accélération) | **+5 %** — *même si la lance n'est pas en main* |
| Attaque plongeante critique | **+5 à +35 %** selon la hauteur de chute |
| **Parade** | **+20 %** — un tir entier rendu |

**Les deux coups**

| Entrée | Effet | En mise en joue |
|---|---|---|
| **Tir** | Trait cinétique · horizontal **ou** vertical au choix · ralentit après 6 m puis se dissipe | **Frappe au sol** — ligne touchant tous les ennemis alignés · *fall-off* après 8 m · stop à 12 m |
| **Mêlée 1** | Coup **horizontal** — large nombre d'ennemis | Plus rapide |
| **Mêlée 2** | Coup **vertical** — un seul ennemi, plusieurs unités de hauteur | Plus rapide |

**Notes**

**C'est la pièce maîtresse du Triangle, et le seul objet du jeu qui relie les trois sommets simultanément.** Elle tire (sommet Tir), elle frappe (sommet Mêlée), et **elle se recharge sur la mobilité** (sommet Hornet). Aucune autre arme du roster ne fait ça.

**La recharge sur le booster est le mécanisme le plus important de la fiche.** +5 % par accélération, *même la lance rangée* : Yumiko qui joue son kit de mobilité recharge passivement son arme signature. Le Triangle cesse d'être une alternance et devient une **boucle** — la mobilité finance la mêlée, la mêlée finance le tir. C'est la réalisation mécanique de D15 (aucun sommet n'est optionnel).

**Le palier de vitesse comme diviseur de coût** est du même ordre. La mêlée de Yumiko utilise déjà la vitesse comme paramètre de dégâts (0,35 → 0,65 à ≥ 1,10, 0,80 au-delà de 1,25) ; la lance utilise la vitesse comme **paramètre d'économie**. Même variable, deux effets distincts. Au palier 2 elle passe de 5 à **20 coups par batterie** — quadruplement. Un joueur immobile a une arme de 5 tirs, un joueur en charge a une arme d'assaut.

**La parade à +20 % ferme la boucle défensive.** Un tir rendu par parade réussie, c'est-à-dire que **bien se défendre recharge l'attaque**. Combiné à l'attaque plongeante (+5 à +35 %), on obtient une arme dont le rechargement est intégralement composé d'actions de gameplay — jamais d'attente. C'est un design remarquable et je n'ai rien à y redire.

**Sur le système d'unités** : le plafond de 3 unités par ennemi (1,05 ART) est bien calibré. **1,05 ART, c'est exactement la chair d'un Elite Minor** (1,00) plus une marge. La lance tue un Minor déprotégé d'un coup vertical, et pas un Major. Le scaling ×0,85 au-delà de 3 unités (0,0525) rend les unités surnuméraires quasi symboliques — 4 unités de plus n'ajoutent que 0,21 ART. **Le maximum absolu est donc 1,26 ART sur une cible unique.**

Le **tips pro** (tourner la vision pour concentrer les unités) est exactement le genre de compétence invisible qui récompense la maîtrise sans être obligatoire. Bon.

✅ **Le facteur 2 est tranché, et la réponse est la plus intéressante des trois possibles.** *(point 1 — bloquant principal du lot CSNU)* La marche portée à 1,10 **active bien le palier 1** — donc **10 tirs par batterie en régime normal**, pas 5. Mais le coût de 20 % n'est pas mort pour autant : il redevient actif **chaque fois que le momentum réel retombe sous 1,10**.

C'est une distinction fondamentale entre **vitesse nominale** et **momentum atteint**, et elle transforme un chiffre en système :

| Situation | Momentum | Coût |
|---|---|---|
| Marche établie *(passif SPÉCIALE)* | 1,10 | **10 %** |
| Charge, course entretenue | 1,11–1,35 | **5 %** |
| Départ arrêté, accélération en cours | < 1,10 | **20 %** |
| Freinage au *slide* | < 1,10 | **20 %** |
| Sortie de BRS avant réaccélération | < 1,10 | **20 %** |
| Dérapage — vitesse dissipée dans la dérive | < 1,10 | **20 %** |

**Le coût de la lance est donc un indicateur d'inertie.** Yumiko qui se bat à l'arrêt paie le plein tarif ; Yumiko qui ne perd jamais son élan paie un quart. L'arme ne récompense pas la vitesse en soi — elle récompense **la continuité du mouvement**, ce qui est exactement le sujet du système Hornet : le propulseur existe pour ne pas subir l'inertie, et la lance facture précisément à celles et ceux qui la subissent.

Ça referme la boucle du Triangle d'une manière que je n'avais pas anticipée. La recharge cinétique (+5 % par accélération) finance l'arme, **et** le maintien du momentum divise son coût par deux ou par quatre. Les deux mécanismes tirent dans le même sens, et le joueur qui joue mal la mobilité est puni deux fois : il recharge moins et il dépense plus. **C'est le meilleur couplage mobilité/arme du roster**, et il n'a coûté aucun chiffre supplémentaire — juste une définition rigoureuse de ce qu'est « être à 1,10 ».

Note d'interface : puisque le coût varie en temps réel avec le momentum, **le joueur doit pouvoir le lire**. Un indicateur de palier — trois états, pas une jauge continue — me paraît nécessaire, sinon le système existe sans être perçu.

Le **mode Ronin** (une arme + la lance obligatoirement) mérite sa propre fiche. C'est un mode de jeu, pas une variante d'arme.

✅ **Le recovery ne bloque pas le déplacement** *(point 2)*. Les mouvements de mêlée — ceux des armes de mêlée comprises — n'affectent ni les déplacements de Yumiko ni ceux de l'ennemi qui les exécute. **Yumiko se déplace pendant la récupération, Hornet compris.**

La seconde de recovery n'est donc pas une immobilisation : c'est un **verrou d'enchaînement**, elle interdit de replacer un coup, pas de bouger. Ma crainte tombe d'elle-même — la lance n'est pas risquée face à trois ennemis, elle demande simplement de circuler entre deux frappes plutôt que de rester planté. C'est cohérent avec tout le reste du kit : la sandbox ne prive jamais Yumiko de mobilité, elle module ce qu'elle peut faire *en plus* de bouger.

La notion de recovery reste utile pour deux usages : les **ennemis** qui manient ces armes, où elle crée les fenêtres de riposte, et les **armes à combos** — l'Épée d'Énergie en tête, dont la fiche viendra en temps voulu.

---

### 1.15 — Grenade à Fragmentation

| Champ | Valeur |
|---|---|
| **Classe** | **Lancer** |
| **Puissance** | **1,25 ART** |
| **Chargeur / Recharges** | Voir `arcade-yumiko.md` — **8 max**, 2 types équipés |
| **Portée efficace** | Rayon **6 m** |
| **Critique** | **×1,50** contre **armures et blindages** → **1,875 ART** |
| **Scaling** | Voir tableau · **appliqué aussi aux véhicules** |
| **Délai** | Explose **1,5 s** après avoir touché le sol |
| **Mise en joue** | Lancer **direct**, moins en cloche · **garde la grenade en main** · délai **3 s après dégoupillage** — risque d'explosion en main |

**Scaling par distance**

| Distance | Mult. | ART |
|---|---|---|
| 0–3 m | ×1,00 | **1,25** |
| 3,01–5 m | ×0,66 | 0,825 |
| 6ᵉ mètre | ×0,35 | 0,4375 |

> **Souffle (§0.9)** — l'explosion de cette arme **éteint un feu d'un seul coup**, au sol comme sur un ennemi.

**Notes**

Conforme à la doctrine : **la grenade est une arme à équiper**, elle appartient au sommet Tir du Triangle, et son budget vit dans le système de Yumiko (8 max, 2 types, cumul possible).

**Le critique ×1,50 contre armures et blindages** est le trait distinctif. À 1,875 ART, une frag bien placée retire 75 % de la chair d'un Elite Ultra ou détruit une plaque de véhicule. Contre les protections, la grenade humaine est **la meilleure valeur ART du CSNU par unité de ressource** — meilleure que la roquette rapportée à la rareté.

**Le scaling est sévère et c'est bien.** Passé 3 m, on perd un tiers ; au 6ᵉ mètre, deux tiers. Le rayon annoncé de 6 m est en réalité un rayon utile de **3 m**. Sur une sandbox où *« les ennemis peuvent esquiver les grenades »*, ce scaling signifie qu'une esquive de 2–3 m suffit à diviser les dégâts par trois. **La grenade ne fonctionne que par prédiction ou par saturation** — exactement ce que dit `comportement-de-l-ennemi.md` à propos des gradés.

Le **délai de 1,5 s après contact au sol** (et non après le lancer) est le bon choix : il rend le rebond et le bank-shot lisibles, et il donne à l'ennemi une fenêtre d'esquive équitable.

**La mise en joue est le meilleur détail de la fiche.** Lancer direct, moins de cloche, mais on **garde la grenade en main** avec un délai de 3 s après dégoupillage. C'est un *cook* explicite, avec le risque assumé de mourir de sa propre grenade. Contre un ennemi qui esquive, cuire 2 s pour supprimer la fenêtre d'esquive est **la contre-mesure du joueur**, et elle se paie en risque réel. C'est du très bon design d'opposition : l'IA a une parade, le joueur a une contre-parade, et la contre-parade coûte quelque chose.

Rappel de budget : la correction Q2 de `comportement-de-l-ennemi.md` posait **10,00 ART portables en 8 frags**. À 1,25 ART l'unité, le compte tombe juste — 8 × 1,25 = 10,00. Face à un Général à 9,75, **le stock complet de grenades vaut exactement un Général**, à condition de toucher au contact à chaque fois. C'est un contrepoids parfait, et l'esquive des gradés est ce qui l'empêche d'être trivial.

---

### 1.16 — Mitrailleuse M739 LMG / SAW

| Champ | Valeur |
|---|---|
| **Classe** | **Lourd FIXE** *(LMG)* — **Lourd** *(SAW décrochée)* |
| **Puissance** | 0,085 ART · **1,105 ART/s** |
| **Cadence** | 0,0769 s · 13 tirs/s |
| **Chargeur / Recharges** | **LMG fixe : 200** · **SAW : 72 / 5 · réserve 360** |
| **Portée efficace** | **SAW : 0–12 m**, *fall-off* dès 25 m · **LMG : 10–25 m**, *fall-off* **×0,50** dès 40 m |
| **Anti-bouclier** | **×0,75** → 0,064 ART · **0,829 ART/s** |
| **Critique** | **×1,50 contre les CASQUES** → 0,128 ART · **1,658 ART/s** |
| **Critique — extension §0.8** | Le même **×1,50 s'applique aux ARMURES** |
| **Scaling** | **×0,65 après 25 m** → **0,0553 ART · 0,718 ART/s** · **×0,35 au-delà de 50 m** → 0,030 ART · 0,386 ART/s |
| **Mise en joue** | **Décrochée seulement** — absorbe un peu de recul, réduit le spread · **ne réduit pas les fall-off** · mobilité encore plus réduite · **aucun tir au jugé** |
| **Précision** | Se dégrade quand la salve se prolonge · **salve de 5 coups max = précision d'un BR55** |

**Notes**

**« LMG » = fixe et grand magasin. « SAW » = arme lourde normale.** C'est le même objet dans deux états, et le passage de l'un à l'autre est la mécanique de §0.6 : on **abandonne le grand magasin carré** pour retrouver la mobilité.

Le marché est explicite :

| | LMG *(fixe)* | SAW *(décrochée)* |
|---|---|---|
| Chargeur | **200** | 72 |
| Réserve | — *(râtelier)* | **360** |
| Portée | **10–25 m** | 0–12 m |
| *Fall-off* | dès 40 m | dès 25 m |
| Mobilité | **Fixe** — 1,05 en ligne droite | **Lourd** — *1,10 libre, slide, wall jump* |
| Recharge | Râtelier dédié | Longue |

**Le critique ×1,50 contre les casques est le vrai rôle de l'arme**, et il est unique dans le roster. Aucune autre arme CSNU ne cible spécifiquement les casques. Or les casques appartiennent aux trois unités les plus solides de la matrice : Ultra (0,75), Dévot (0,75, **anti-perforation**) et Général (1,25). Le SRS99 perforateur **ignore** les casques — sauf celui du Dévot. La SAW, elle, ne les ignore pas : **elle les casse**, à 1,658 ART/s.

**Extension §0.8** — un critique casque vaut aussi contre les **armures**. La SAW n'est donc pas seulement l'anti-gradé du roster : c'est **l'arme anti-protection dure du CSNU**, ×1,50 sur tout ce qui est casque ou armure, à 200 balles de chargeur. Ça la rapproche du MA37 (×1,25 armures et blindages) tout en la plaçant nettement au-dessus, et ça justifie sa classe Lourd FIXE.

C'est une articulation superbe. **Le Dévot est immunisé au perforateur du sniper, mais parfaitement vulnérable à la SAW.** La sandbox propose donc deux réponses opposées au même problème — perforer ou marteler — et l'unité la plus blindée du jeu n'accepte que la seconde. Je recommande de **rendre ce lien explicite dans le level design** : placer des Dévots là où une LMG est disponible.

Le contrepoids est bien posé : **×0,75 contre les boucliers**. La SAW ne perce pas un Elite, elle démolit ce qu'il y a derrière. Il faut d'abord tomber le bouclier avec autre chose. C'est une arme de **deuxième temps**, et sur une sandbox où « les ennemis sont tanky », avoir une arme spécialisée dans le deuxième temps est légitime.

La **salve de 5 coups à précision de BR55** est une mécanique de rythme, cousine du M7-S : le joueur qui tapote a une arme de précision à 25 m, celui qui tient la gâchette a un arrosoir. Deux armes en une, même touche.

✅ **La SAW décrochée est une arme Lourde**, pas Soutien *(point 6 tranché)* — classe officielle : **Lourd FIXE – Lourd**. Le **tir au jugé est supprimé** : décrochée, l'arme n'a plus que la mise en joue.

**Ni l'un ni l'autre état n'est immobile, et c'est la clé de l'arme.** Montée sur son socle elle est en classe **Fixe** *(§0.6)*, décrochée elle passe en **Lourd** *(§0.5)* — deux régimes **emboîtés**, le Fixe reprenant les restrictions du Lourd et les durcissant. Le décrochage ne rend pas « la mobilité » : il rend **la liberté directionnelle**.

| | LMG sur socle *(Fixe)* | SAW décrochée *(Lourd)* |
|---|---|---|
| Marche | **0,90** | Normale |
| Vitesse de pointe | **1,05** *(charge linéaire)* | **1,10** *(palier 1, coût nul)* |
| **Direction en charge** | **Avant uniquement** | **Libre** |
| Dérapage / redirection | **Non** | Oui |
| Slide / wall jump | **Non** | Oui |
| Hauteur de saut | Réduite | Réduite |
| Palier 2 (1,25) | Non | Non |

**L'écart de vitesse est dérisoire — 1,05 contre 1,10 — et c'est volontairement le mauvais indicateur.** Ce que le joueur récupère en décrochant, ce sont les **degrés de liberté** : dériver, rediriger, slider, wall jumper. Sur socle il avance en ligne droite comme un véhicule sur rail ; décroché il redevient une Spartane. **Le vrai coût d'une arme fixe est la prévisibilité, pas la lenteur** — et contre une IA qui vise l'anticipation, c'est un coût bien plus lourd que 0,05 de vitesse.

À noter : la **hauteur de saut réduite est commune aux deux états** — elle vient du Lourd et le décrochage ne la rend pas. Une arme de cette classe **plafonne durablement le jeu vertical de Yumiko**, ce qui compte sur un socle bâti sur des sauts hauts et flottants.

Ça change complètement la lecture du marché. Décrocher la LMG ne troque pas le magasin contre l'immobilité : ça troque **200 balles et un poste fixe** contre **72 balles, 360 en réserve, et un joueur qui court à 1,10 avec une mitrailleuse**. Le palier 1 étant aussi le seuil de la mêlée critique à 0,65 ART, la SAW décrochée reste **compatible avec le sommet Mêlée du Triangle** — ce que je croyais perdu.

⚠️ Ma recommandation de porter la portée décrochée à 18 m **tombe** : à 1,10 de vitesse, 12 m se comblent vite, et l'arme n'a plus besoin de compensation. **En revanche la version FIXE est buffée à 10–25 m** *(au lieu de 25 m nets)*. C'est le bon ajustement, et il corrige une asymétrie que je n'avais pas relevée : une arme de poste fixe qui ne peut rien faire sous 25 m est aveugle exactement là où on l'assaille. Avec 10 m de plancher, la LMG couvre son propre pied.

Le marché final est donc net et honnête :

| | LMG *(fixe)* | SAW *(décrochée)* |
|---|---|---|
| Volume de feu | **200 balles** | 72 + 360 |
| Domaine | **10–25 m**, *fall-off* 40 m | 0–12 m, *fall-off* 25 m |
| Mobilité | **Ligne droite, 1,05** | **1,10 libre + slide + wall jump** |
| CAC | **0,55 + stuns facilités** *(§0.6)* | Mêlée standard |

On échange de la **densité** contre de la **présence**. Deux façons de tenir un terrain, pas une bonne et une mauvaise — et le joueur bascule de l'une à l'autre en cours d'engagement, ce qui est le vrai intérêt de l'arme.

Une conséquence à noter : **sur socle, la SAW donne accès au CAC des armes fixes**, donc à des **stuns qui portent sur des ennemis normalement insensibles au stun** *(§0.6)*. Une arme de poste fixe qui peut ouvrir un gradé au corps à corps, c'est un outil de dernier recours que je n'avais pas compté dans son profil — et ça compense largement la marche à 0,90.

---

## 2. Covenant – Élites

> 13 entrées. Les valeurs proviennent de la fiche d'équilibrage de l'auteur.
> Les lignes marquées ⚠️ signalent un **écart arithmétique** relevé à la transcription — voir `## 6. Matrice consolidée`.

---

### 2.1 — Fusil à Plasma

| Champ | Valeur |
|---|---|
| **Classe** | **Hybride Principale / Légère** |
| **Puissance** | **0,125 ART** · **0,4375 → 0,625 ART/s** |
| **Cadence** | 0,285 s · 3,5 tirs/s · **après 1 s de tir** : 0,200 s · **5 tirs/s** |
| **Chargeur / Recharges** | **250** · batterie unique |
| **Portée efficace** | 5–16 m |
| **Malus cible non protégée** | **×0,80** → 0,10 ART · 0,350 à 0,500 ART/s |
| **Surchauffe** | **6,25 s de tir** (≈ 30 tirs) |
| **Mise en joue** | **Aucune** |
| **Dual handling** | **Oui** — classique |

**Mode Charge — Estoc Plasma**

| Point | Règle |
|---|---|
| Activation | *Recharger* — concentre l'énergie dans les **dents bleues** |
| Coût | Équivalent de **25 tirs** |
| Effet | Le tir devient **indisponible** · le coup de crosse **traverse le bouclier** et frappe directement la cible derrière |
| Puissance | **0,65 ART** — base de tous les combos CAC *(grille de mêlée standard **+0,30**)* |
| Annulation | *Recharger* à nouveau hors frappe → **récupère la moitié** de l'énergie consommée |
| Surchauffe | 3,5 s · **1,75 s seulement** après avoir donné le coup chargé |

**Notes**

**C'est l'arme principale du principal ennemi du jeu, et la fiche dit « aucun effet à déclarer ».** C'est exactement le bon positionnement : le Fusil à Plasma est le mètre-étalon Covenant, le pendant du MA37 côté CSNU. Une arme que le joueur ramasse en permanence, jamais celle qu'il choisit.

Le renversement par rapport à Halo est total et il est **conforme à D9** : le malus ×0,80 s'applique **aux cibles non protégées**, pas aux boucliers. Le plasma frappe les boucliers à pleine puissance et peine sur la chair. Contre Yumiko : **8 tirs pour le bouclier** (1,00 ART) puis **15 tirs sur la chair** (0,10 × 15 = 1,50), soit **23 tirs / 4,60 s** à cadence haute. Un Élite Minor seul ne tue pas ; trois Minors qui convergent tuent en 1,5 s. **C'est l'arme qui rend l'escouade dangereuse, pas l'individu** — et sur un socle sans sprint, c'est la bonne façon de faire mal.

La **cadence évolutive** (3,5 → 5 tirs/s après 1 s) récompense l'entretien du feu, comme les rafales longues du MA5B. Deux factions, deux armes de base, même philosophie : **tenir la gâchette est un choix tactique**. Bonne symétrie, et elle rend les deux fusils comparables sans les rendre identiques.

**L'Estoc Plasma est la trouvaille de la fiche.** Sacrifier 25 tirs de batterie pour un coup de crosse qui **traverse le bouclier** à 0,65 ART, c'est donner à l'arme la plus banale du jeu une clé anti-bouclier contextuelle. Et la clause d'annulation — récupérer la moitié si on relâche sans frapper — transforme la charge en **pari réversible** : on charge en approche, et si l'Élite recule, on récupère 12,5 tirs. C'est du design d'engagement, pas du bonus passif.

✅ **Le +0,30 sur la grille de mêlée est tranché par D14 (R5), et il ne bute sur aucun plafond.**

Le plafond de 1,00 ART **ne vaut que sur la base de mêlée classique à 0,35**. Dès que la base est
modifiée — et l'estoc la modifie — c'est l'autre règle qui s'applique : **×3,00 fixe, sans plafond**.

| Coup | Base | Avec estoc *(+0,30)* | Crit dorsal ×3 |
|---|---|---|---|
| Mêlée classique | 0,35 | 0,65 | **1,95 ART** |
| Mêlée critique *(≥1,10)* | 0,65 | 0,95 | **2,85 ART** |

**Un crit dorsal à l'estoc chargé vaut 1,95 ART qui traverse le bouclier.** Sur les 2,50 de Yumiko c'est
78 % de sa solidité en un coup, et sur un Élite Minor c'est une exécution nette. Le chiffre est énorme, et
il est mérité : il faut avoir chargé *(25 tirs de batterie)*, être dans le dos, et avoir renoncé à tirer
pendant tout ce temps. **Trois conditions cumulatives pour un coup.** C'est le bon prix.

Ce que ça dit du design : le plafond D14 n'a jamais eu pour objet de borner la puissance, il avait pour
objet de **protéger la mêlée nue**. Une fois qu'une arme investit dans son corps à corps, elle sort du
barème — c'est ce qui distingue l'estoc du simple coup de crosse.

✅ **Arrondis corrigés** : 0,125 × 3,5 = **0,4375** *(la fiche disait 0,443)* · surchauffe à **6,25 s**
*(3,5 tirs la première seconde puis 26,25 tirs en 5,25 s, soit 29,75 tirs)*.

---

### 2.2 — Pistolet à Plasma

| Champ | Valeur |
|---|---|
| **Classe** | Légère |
| **Variantes** | **Pistolet à Plasma Instable** · **Pistolet à Plasma Véloce** |
| **Puissance** | **0,12 ART** · variable · **max 1,08 ART/s** *(erratum auteur — 0,96 était une coquille)* |
| **Cadence** | **Selon exécution** — vitesse de clic seule · max **0,11 s · 9 tirs/s** |
| **Chargeur / Recharges** | **300 tirs** · batterie unique |
| **Portée efficace** | 0–15 m |
| **Anti-bouclier** | **×1,35** → **0,16 ART** |
| **Malus cible non protégée** | **×0,75** → **0,090 ART** |
| **Surchauffe** | Après **27 tirs consécutifs** · **3,50 s** · refroidissement normal **20 %/s** |
| **Dual handling** | **Oui** — ⚠️ **perd le multiplicateur sur les boucliers** |
| **Mise en joue** | Aucun changement de comportement · absorbe le peu de recul · *« en principe ne s'utilise jamais »* |

**Charge Plasma**

| Point | Valeur |
|---|---|
| **Temps de charge** | **2,00 s** · **maintien possible** *(relâcher pour tirer)* |
| Effet | **IEM Plasma** · projectile plus lent à **léger guidage** *(feeling Halo CE)* |
| Véhicule | **Désactivé 3,50 s** |
| Cible non protégée | **×2,5** du montant critique *(0,18)* → **0,45 ART** |
| **Bouclier** | **×5,00** → **2,25 ART** *(225 %)* |
| **Coût** | **50 tirs** — **16,67 %** de la batterie *(6 charges)* |

**Variante — Pistolet à Plasma Instable**

| Point | Valeur |
|---|---|
| **Apparence** | Carrosserie **rouge/orangée**, **dents rouges**, projectiles de plasma **Brute** |
| **Multiplicateurs** | **AUCUN** — ni bonus ni malus · **0,12 ART sur tout** |
| **Batterie** | **175 tirs** |
| **Surchauffe** | **18 tirs consécutifs** · **3,50 s** · redescente de jauge **40 %/s** |
| **Charge — durée** | **3,00 s** · **aucun guidage** · trajectoire **en légère cloche** |
| **Charge — effet** | **0,50 ART à l'impact** + **flaque de Plasma Instable** + **brûlure** |
| **Charge — pénétration** | La brûlure **traverse les protections** — **PV directs**, bouclier compris *(§5.1 · §5.2)* |
| **Charge — coût** | **40 tirs** — **22,86 %** de la batterie *(4 charges)* |

**Variante — Pistolet à Plasma Véloce**

| Point | Valeur |
|---|---|
| **Apparence** | Carrosserie **argentée**, **dents violettes**, projectile de plasma **Véloce** |
| **Anti-bouclier** | **×0,75** → **0,090 ART** |
| **Points faibles** | **×1,25** → **0,15 ART** |
| **Batterie** | **425 tirs** |
| **Surchauffe** | **Identique à la base** — **27 tirs**, **3,50 s**, refroidissement **20 %/s** *(aucune précision = aucun changement)* |
| **Projectiles** | **Plus rapides** que la forme normale ou Brute *(base Halo CE)* — **vaut aussi pour la charge** |
| **Charge — durée** | **1,50 s** · **ne se maintient pas** — **relâchée automatiquement** en fin de charge |
| **Charge — nature** | **FRAPPE Dynamo sans souffle** *(§5.3)* — dégâts **et** effet **cantonnés au seul ennemi touché** · **aucune zone** |
| **Charge — effet** | **0,35 ART** d'impact · **stun**, **même sur cible protégée** |
| **Charge — coût** | **50 tirs** — **même nombre de tirs que la charge IEM de la base**, donc **11,76 %** seulement *(8 charges)* |
| **Charge — tag** | **CINÉTIQUE** — au sens **mêlée/impact**, **pas** au sens souffle du §5.4 |
| **Charge — multiplicateurs** | **AUCUN** — la frappe n'est plus au régime strict du Dynamo |
| **Charge — réserve** | *(exception nommée : un ennemi **trop lourd pour vaciller** exige des **stuns critiques**)* |
| **Charge — vs saignement** | **+0,20 ART additif** *(§5.6)* contre une cible **non protégée qui saigne** → **0,55 ART** |
| **Charge — contre Yumiko** | **Repousse** *(état **SUBI**)* · **Wall Splat** si elle heurte un mur · **aucune coupure de contrôle** |

**Notes**

**Le châssis unique tient, et c'est la charge qui distribue les rôles.** Trois déclinaisons d'une même
arme, trois cases de §3.1 : la base garde l'**anti-bouclier**, l'Instable prend la **zone**, la
Véloce prend le **déni de mobilité**. Le roster ne bouge pas — **43 armes** — et la variété passe par la
dotation, exactement comme annoncé.

| | Charge | Case §3.1 | Sort de D9 ? |
|---|---|---|---|
| **Base** | IEM · 2,25 sur bouclier | COURTE / **ANTI-BOUCLIER** | Non — **seule porteuse** |
| **Instable** | Flaque + brûlure | COURTE / **ZONE** | **Oui** |
| **Véloce** | Frappe Dynamo | COURTE / **DÉNI DE MOBILITÉ** | **Oui** |

✅ **D9 survit intact.** Les deux variantes **perdent l'IEM** — l'énoncé ne le mentionne nulle part chez
elles — donc la **liste fermée à trois** *(Pistolet à Plasma chargé, Fusil Électrique, Grenade Dynamo)*
n'est pas élargie : c'est **la base seule** qui la porte. Et l'objectif annoncé est atteint sans toucher
à un seul chiffre de doctrine — **là où le joueur ramasse une variante, il ne ramasse pas le noob
combo.** La rareté fait le travail que l'équilibrage n'a pas eu à faire.

**L'Instable est l'arme à DPS plat, et c'est le meilleur chiffre de la fiche.** « Aucun multiplicateur,
ni bonus ni malus » a l'air d'un renoncement ; combiné à la chauffe, c'est une identité. Le calcul qui
compte n'est pas la rafale unique mais le **régime d'équilibre** — la cadence qu'on peut tenir sans
jamais surchauffer, jauge stabilisée.

| Régime d'équilibre | Chauffe/tir | Récup. | **Cadence tenable** | vs bouclier | vs chair |
|---|---|---|---|---|---|
| **Base** | 3,70 % | 20 %/s | **5,4 t/s** | **0,875 ART/s** | 0,486 ART/s |
| **Instable** | 5,56 % | 40 %/s | **7,2 t/s** | 0,864 ART/s | **0,864 ART/s** |

**L'Instable tient exactement le DPS anti-bouclier de la base — mais sur tout.** 0,864 contre 0,875 :
l'écart est de 1 %. Contre la chair en revanche, elle fait **+78 %**. La variante ne troque donc pas de
la puissance contre de la polyvalence, elle **supprime la question de la cible** : le porteur tire pareil
sur un bouclier, une armure ou un Grognard nu. C'est l'arme qui ne demande jamais au joueur de réfléchir
à ce qu'il vise — et c'est le bon profil pour une horde.

⚠️ **Le prix est payé en fenêtre, et il est raide.** 18 tirs, c'est **2,00 s** de tir avant blocage
contre 3,00 s à la base : la **plus courte fenêtre continue du jeu**. La redescente à 40 %/s la
rattrape presque entièrement en régime géré, mais un joueur qui vide sa jauge d'un trait subit
3,50 s d'arrêt tous les 2,00 s de tir. **L'arme récompense le tir en salves brèves et punit la gâchette
tenue** — même leçon que le Fusil à Plasma Brute, une classe plus bas.

**La batterie de 175 est le vrai régulateur, et elle est mieux placée que la chauffe.** 175 tirs contre
300, c'est **−42 %**, et la charge y coûte 40 tirs : **4 charges** au lieu de 6. Une variante qui pose des
flaques ne doit pas pouvoir en poser indéfiniment ; la rareté est écrite dans la réserve plutôt que dans
un cooldown, ce qui la rend lisible à l'écran *(la jauge descend)* au lieu d'être une règle invisible.

**La Véloce est la seule des trois à savoir viser, et c'est ce qui la sauve.** Le ×1,25 points faibles est
**inédit sur ce châssis** — ni la base ni l'Instable n'ont de critique de placement. Avec des projectiles
plus rapides, la variante devient la seule déclinaison où **la précision paie** : 0,15 ART sur un point
faible contre 0,12 à l'Instable et 0,090 à la base sur cible nue. Elle est la moins bonne partout et la
meilleure sur un seul geste. C'est un profil honnête.

⚠️ **Mais elle est très faible contre les boucliers, et il faut le voir en face.** ×0,75, soit
**0,090 ART** — **−44 %** face à la base. Sur une sandbox Covenant où les boucliers sont partout, une
arme courte portée qui ne les entame pas n'a de valeur que par sa charge. **Tout le poids de la variante
repose donc sur le stun** : s'il ne tient pas, il ne reste rien.

**La charge Véloce à 1,50 s auto-relâchée est le meilleur détail des trois fiches.** Elle ne se maintient
pas — donc pas de charge gardée en poche, pas d'embuscade préparée. Le joueur *engage* la charge et
s'engage avec elle. Comparée aux 2,00 s de la base et aux 3,00 s de l'Instable, elle est la plus rapide
et la moins libre : **la seule des trois qui décide à la place du joueur quand elle part.** Ça en fait un
outil de réaction, là où les deux autres sont des outils de préparation.

**Le 0,35 tombe sur l'ancre.** C'est la base mêlée, c'est le souffle Dynamo, c'est l'onde du Fusil
Électrique. La sandbox a désormais **quatre sources de poussée au même chiffre** : le joueur apprend une
valeur, pas quatre. Bien.

**L'exception « trop lourd pour vaciller » se branche sur un précédent qui existe déjà.** Le Grenadier à
Plasma *(§2.6)* porte la seule hiérarchie de résistance mentale du projet — Grognards désorientés d'un
tir, Ultras et Spec-Ops à deux, **Chieftains immunisés**. La réserve de la fiche Véloce en est la
transposition exacte, et je recommande de **réutiliser ce tableau tel quel** plutôt que d'en écrire un
second : deux sources de concussion, une seule table de résistance.

---

**Un seul écart subsiste** *(§0.7)*

**Le « montant de dégât critique » de 0,18** sur la charge de la **base**. Elle est décrite comme
« ×2,5 fois le montant de dégât critique **(0,18 → 0,45)** ». Or **0,18 = 0,12 × 1,50**, c'est-à-dire
l'**ancien** multiplicateur anti-bouclier, celui qui a été abaissé à ×1,35. Avec le multiplicateur
actuel, le critique vaut 0,162 et ×2,5 donnerait **0,405**. **La valeur de 0,45 est retenue telle
quelle** puisqu'elle est écrite en clair — mais elle n'est plus dérivable des autres chiffres. C'est
**une constante, pas un calcul.** *(Ce point ne concerne **que la base** : la Véloce n'a plus aucun
multiplicateur de charge.)*

*Erratum intégré : le plafond de DPS est **1,08 ART/s** *(0,12 × 9)*, le 0,96 était une coquille. La
cadence maximale reste **9 tirs/s** et l'arbitrage antérieur — cadence montée à 9 contre critique
bouclier abaissé à ×1,35 — **n'est pas rouvert**.*

---

✅ **La charge Véloce est une FRAPPE Dynamo, pas un souffle — et ça change tout son classement.**

| | Dégâts | Effet | Zone | §5.4 ? | Trie les feux ? |
|---|---|---|---|---|---|
| **Grenade Dynamo** | 0,35 | concussion + IEM véhicule | **diamètre fini** | Non | **Oui** *(§5.3)* |
| **Fusil Électrique** *(4ᵉ tir)* | 0,35 | onde, cible non protégée | zone | Non | Oui |
| **Charge Véloce** | 0,35 | **stun + repousse** | **AUCUNE — la cible seule** | **Non** | **Non — rien à trier** |

**C'est la première entrée Dynamo purement mono-cible du projet, et elle règle la contradiction sans
créer d'exception.** Le §5.4 tient sa liste fermée à cinq armes : la Véloce n'y entre pas, donc elle
**n'éteint aucune flamme**. Et comme elle n'a pas de souffle, le tri Dynamo du §5.3 *(entretient
Combustible et Plasma Instable, éteint les trois autres)* **ne s'applique nulle part** — il n'y a pas
de volume pour rencontrer une flaque. **La Véloce et l'Instable ne se contrarient plus.** Un Rapace à la
Véloce peut stunner un ennemi debout dans la mare qu'un Grognard vient de poser : le stun tient, la mare
brûle, personne ne défait le travail de l'autre.

✅ **Sortir du régime strict du Dynamo retire aussi les multiplicateurs de charge — et c'est cohérent.**
La charge ne porte plus ni ×1,50 sur cible non protégée ni ×3,00 sur bouclier : **0,35 ART, un point,
sur tout**. Le tag CINÉTIQUE ne sert qu'à **une** chose, ouvrir le **+0,20 additif du §5.6**.

| Charge Véloce | ART | Part de Yumiko |
|---|---|---|
| Cible quelconque | **0,35** | 14 % |
| **Cible non protégée qui saigne** | **0,55** | 22 % |

**Le stun devient la totalité de la valeur de la charge, et c'est le bon dépouillement.** Avec les
multiplicateurs, la Véloce avait deux raisons d'exister — un peu de dégât et un effet ; elle n'en a plus
qu'une. Une arme dont la charge fait 0,35 partout ne se juge plus au chiffre, **elle se juge au moment
où on l'emploie**. C'est le profil le plus lisible des trois déclinaisons, et le seul où le porteur ne
gagne rien à viser la bonne matière.

**Le coût de charge est le vrai cadeau, et il passe presque inaperçu.** « Aucune précision = aucun
changement » : la charge coûte **50 tirs**, comme la base. Mais la Véloce porte **425 tirs** au lieu de
300, donc le même prix nominal ne vaut plus que **11,76 %** de la réserve.

| | Batterie | Coût charge | % | **Charges** |
|---|---|---|---|---|
| **Base** | 300 | 50 | 16,67 % | **6** |
| **Instable** | 175 | 40 | 22,86 % | **4** |
| **Véloce** | **425** | 50 | **11,76 %** | **8** |

**Le classement des trois variantes est un dégradé propre : 8, 6, 4.** Plus la charge est puissante, plus
elle est rare. La Véloce en tire **le double de l'Instable**, ce qui est exactement le rapport qu'il faut
entre un stun mono-cible et une flaque qui traverse les boucliers. Et la charge la plus rapide *(1,50 s)*
est aussi la plus abondante : **la Véloce est la seule des trois qui peut charger en boucle**, à raison
d'une frappe toutes les 1,50 s pendant huit fois. C'est une arme de rythme, pas de burst.

⚠️ **La contrepartie, c'est que la Véloce est presque une arme à charge exclusive.** Son tir normal est
la pire ligne du châssis — **0,090 ART** sur bouclier, **−44 %** face à la base — et ses 425 tirs
n'existent que pour financer huit charges. Le porteur qui tire au coup par coup gaspille sa réserve ;
celui qui la garde pour huit stuns joue l'arme comme elle est écrite. **Je le signale sans le corriger** :
c'est peut-être exactement l'intention, mais la fiche crée une arme dont le tir principal est un déchet.

---

✅ **Le stun contre Yumiko est tranché — repousse et Wall Splat, sans coupure de contrôle.**

**La solution respecte les trois non-négociables en même temps**, ce qui n'était pas gagné. Le Hornet
n'est jamais coupé, **le contrôle directionnel reste inviolable** *(Yumiko garde la main pendant qu'elle
recule)*, et l'effet passe par la seule prise déjà autorisée : l'état **SUBI** de `base-de-travail.md`
— **40 % de précision, +25 % de dégâts reçus**. Aucune règle nouvelle n'a été créée.

**L'asymétrie directionnelle est la meilleure idée de la fiche, et elle est rare.** La même charge n'a pas
la même valeur selon ce que le joueur était en train de faire :

| Intention de Yumiko | Effet de la repousse | Verdict |
|---|---|---|
| **Dive** — fondre sur la ligne ennemie | Annule l'approche, renvoie d'où elle vient | **Punition franche** |
| **Repli** — décrocher vers un couvert | **Pousse dans le sens du mouvement** | **Aide involontaire** |

**C'est un contre-jeu qui punit l'agression et récompense la prudence, sans jamais rien retirer au
joueur.** Presque tous les outils de déni de mobilité du roster taxent indistinctement ; celui-ci
**taxe une direction**. Un joueur qui apprend l'arme apprend à ne pas foncer face à une carrosserie
argentée — et découvre qu'il peut s'en servir comme accélérateur de repli. **La lecture visuelle est déjà
en place** *(la couleur du bolt annonce la charge)*, donc l'information est disponible avant l'impact.

**Le Wall Splat referme la boucle avec le vocabulaire du jeu.** Il existait déjà côté Yumiko — demi-tour
frappe, uppercut, W0-LF sur cible stun — mais **uniquement comme quelque chose qu'elle inflige**. La
charge Véloce est **la première source ennemie de Wall Splat contre le joueur**, et donc le premier
moment où Yumiko subit une mécanique qu'elle pratique. C'est une bonne symétrie de sandbox : le level
design devient lisible autrement, **un mur derrière soi cesse d'être un abri** face à cette arme.

⚠️ **Un point à surveiller au playtest, pas à corriger maintenant** : la repousse pendant une phase
aérienne. Yumiko poussée en plein boost garde son contrôle directionnel, donc la règle tient — mais
elle perd son vecteur, et **+25 % de dégâts reçus en l'air** au-dessus d'un vide n'est pas la même
punition qu'au sol. C'est la même réserve que celle déjà notée sur le shot antigrav du Déchiqueteur
*(§3.8)*, et elle se règle de la même façon : **répulsion horizontale**, jamais vers le haut.

### 2.3 — Needler

| Champ | Valeur |
|---|---|
| **Classe** | Légère |
| **Puissance** | Pic **0,01 ART** · **explosion individuelle 0,12 ART** (0,96 ART/s) · **Super-Combine 1,25 ART** |
| **Cadence** | 0,125 s · 8 tirs/s |
| **Chargeur / Recharges** | 24 / 4 · réserve **96** |
| **Portée efficace** | Variable |
| **Super-Combine** | **8 pics** plantés — **1,25 ART directement aux PV**, l'explosion **endommage aussi le bouclier** · répétable en rafale longue |
| **Report** | **Sans objet** — le dégât au bouclier vient de **l'intérieur**, il n'y a rien à reporter |
| **Comportement** | **Ricoche sur tous les BLINDAGES** · **se plante dans les ARMURES** |
| **Physique** | Suivi proche de **Halo CE** — bon mais moins fort · **projectiles lents et visibles** |
| **Mise en joue** | **Aucune** |

**Notes**

**Le Needler est le deuxième porteur anti-bouclier de fait**, même si la fiche ne le dit pas dans ces termes : la Super-Combine se déclenche **« même avec bouclier »**. Huit pics, une seconde exactement à 8 tirs/s, et 1,25 ART qui tombent d'un coup.

Le rapport est net : 8 pics en explosions individuelles valent **0,96 ART**, la Super-Combine en vaut **1,25**. La SC est **toujours** le meilleur choix (+30 %), ce qui est le bon design — l'arme a une seule ligne de jeu, planter ses huit pics, et le joueur n'a jamais à arbitrer. Un chargeur de 24 donne **3 Super-Combines = 3,75 ART**, de quoi tuer un Elite Minor et entamer un Major.

**Le retour à la physique CE est le bon appel.** Les Needlers modernes ont un suivi si fort que l'arme se joue sans viser ; celui de CE demande d'anticiper le déplacement. Sur une sandbox où les ennemis esquivent activement, un suivi partiel crée exactement la bonne tension — **assez pour pardonner, pas assez pour dispenser de viser**.

**« Ricoche sur les blindages, se plante dans les armures »** est une distinction fine et très utile. Elle donne au Needler un profil de cible clair : redoutable contre l'infanterie lourde (armures), inutile contre les véhicules et les Chasseurs (blindages). Aucune autre arme Covenant ne trace cette ligne aussi nettement.

⚠️ **Le tableau des menaces sous-estimait la Super-Combine, et il faut le corriger dans le bon sens.**
Les 1,25 ART ne sont pas des dégâts génériques : ils tombent **directement sur les PV**, **et**
l'explosion **abîme le bouclier au passage**. Une seule Super-Combine ne laisse donc pas Yumiko à
1,25 ART de vie — elle la laisse à **moins que ça**, chair entamée de moitié *(1,50 → 0,25)* et bouclier
déjà mordu.

**Une Super-Combine de Needler tue presque Yumiko à elle seule.** Deux la tuent avec une marge
confortable, pas « exactement ». C'est la menace la plus sèche du roster à distance moyenne, et elle
n'admet aucun report — non par exception de règle, mais **parce qu'il n'y a rien à reporter** : le dégât
naît à l'intérieur de la protection, il ne la traverse pas.

Le garde-fou est le bon, et il est physique : **le projectile est lent et visible.** Huit pics à planter,
une seconde pleine, sur une cible qui voit venir chaque aiguille. Contre une Yumiko qui joue la mobilité
HORNET, planter huit pics demande soit la surprise, soit la saturation à plusieurs porteurs — ce qui
ramène la menace à sa vraie nature : **une menace d'escouade, pas d'individu.**

Point ouvert : la fiche donne le DPS des pics comme **« Y/sec »**, non renseigné. À 0,01 ART × 8 tirs/s cela ferait 0,08 ART/s — négligeable, et c'est probablement l'intention (les pics ne sont qu'un compteur vers la SC). Conformément à §0.7, je transcris tel quel sans inventer.

---

### 2.4 — Répéteur à Plasma

| Champ | Valeur |
|---|---|
| **Classe** | **Hybride Soutien / Principale** |
| **Puissance** | **0,076 ART** · 0,684 ART/s · **idéal 0,912 ART/s** |
| **Cadence** | 0,111 s · 9 tirs/s · **chauffe idéale** 0,084 s · **12 tirs/s** |
| **Chargeur / Recharges** | **380** · batterie unique |
| **Portée efficace** | 0–8 m · **augmente avec la chauffe** · puis **~35 m** |
| **Surchauffe** | **5,33 s de tir** (64 tirs) |
| **Pénalité de surchauffe** | **8 s** · **impossible de changer d'arme** · le porteur ne peut plus que se déplacer, frapper à la crosse et utiliser ses mouvements |
| **Mobilité** | Maniabilité d'**arme principale** · **pénalité lourde en tandem avec une arme spéciale** |
| **Mise en joue** | Absorbe le recul · améliore la précision en **chauffe idéale et en mode froid** |

**Système de chauffe**

| Point | Règle |
|---|---|
| Atteindre la chauffe idéale | **15 tirs** (1,666 s) ou **0,75 s de préchauffe** = 24 % de la chauffe totale |
| Effets | Dispersion **drastiquement réduite** · vitesse des projectiles **supérieure à tous les autres plasmas** |
| Préchauffe sans tirer | Maintenir *recharger* — **ne consomme pas de batterie** |
| Refroidissement rapide | Appuyer *recharger* · **réappuyer** pour l'arrêter et conserver la chauffe idéale |
| Annulation | *Tirer* annule le refroidissement rapide |
| Dégradation | Le spread s'élargit **à partir de 60 % de chauffe** |

**Notes**

**C'est l'arme la plus technique du Covenant et la mieux construite du lot.** Toute la fiche tourne autour d'une seule ressource — la chaleur — et le joueur la pilote dans les deux sens : il la monte gratuitement à la préchauffe, il la descend au refroidissement contrôlé, et il peut s'arrêter **exactement** dans la fenêtre utile.

La fenêtre est étroite et bien placée : **idéale à 24 %, dégradation à 60 %, surchauffe à 100 %**. Le joueur compétent vit entre 24 et 60 %, soit une bande de 36 % qu'il faut entretenir tir après tir. C'est un **BRS thermique** : même logique de timing que la Charge Spartane, appliquée à une arme.

**La pénalité de surchauffe est la plus violente du jeu et c'est justifié.** 8 secondes, sans pouvoir changer d'arme. Sur une sandbox où les formations ne laissent pas de répit, huit secondes désarmé, c'est une condamnation — sauf que Yumiko conserve **ses mouvements et ses coups de crosse**. La fiche laisse donc au joueur exactement le kit du Triangle : la mobilité Hornet et la mêlée. **Surchauffer, c'est être renvoyé de force sur les deux autres sommets.** C'est une punition qui enseigne le jeu au lieu de le suspendre. Excellent.

Tous les chiffres tombent juste : 0,076 × 9 = 0,684 ✓ · × 12 = 0,912 ✓ · 15 tirs à 9/s = 1,666 s ✓ · 64 tirs à 12/s = 5,33 s ✓. **Aucun écart sur cette fiche.**

La batterie de 380 tirs donne **31,7 s de tir en cadence idéale** — c'est le plus gros réservoir Covenant après le Pistolet à Plasma. Mais la surchauffe intervient toutes les 5,33 s : la vraie limite n'est pas la batterie, **c'est la thermique**. Le réservoir n'est là que pour ne jamais être la contrainte, ce qui est le bon choix : une seule ressource à gérer, pas deux.

**L'hybride Soutien/Principale** est l'inverse exact du MA5B (Principale/Soutien) : maniabilité de principale, pénalité en tandem avec une spéciale. Le Répéteur exclut donc de fait la Lance Spartane, comme le SRS99 et l'IGL. **Quatre armes portent maintenant ce verrou.** C'est une règle de chargement qui se dessine clairement et qui mérite d'être affichée : *les armes à réponse universelle renoncent au corps à corps signature*.

---

### 2.5 — Fusil à Aiguille

| Champ | Valeur |
|---|---|
| **Classe** | Principale |
| **Puissance** | Pic **0,05 ART** (0,125 ART/s) · **explosion individuelle 0,167 ART** (0,417 ART/s) · **Super-Combine 1,25 ART** |
| **Cadence** | 0,40 s · 2,5 tirs/s |
| **Chargeur / Recharges** | 21 / 5 · réserve **105** |
| **Portée efficace** | **70 m** |
| **Super-Combine** | **3 pics** — **contre les armures** destructibles ou non |
| **Critique** | **Headshot → inflige les dégâts de la Super-Combine** |
| **Comportement** | Rebondit sur les **blindages** et sur les **boucliers de Rapace** · **perforant contre les armures** |
| **Suivi** | **AUCUN** — projectile balistique pur, la visée n'est jamais assistée |
| **Contre bouclier** | **Explosion individuelle directe à l'impact** · **pas de Super-Combine sur les boucliers** |
| **SC sur armure** | Endommage aussi la cible, **non critique**, malus **×0,50** → **0,625 ART** |
| **Lunette** | **×1,5** puis **×2,5** |

**Notes**

**Le Fusil à Aiguille est le Needler retourné**, et la symétrie est superbe :

| | Needler | Fusil à Aiguille |
|---|---|---|
| Pics pour une SC | **8** | **3** |
| SC sur bouclier | **Oui** | **Non** — explosion individuelle directe |
| SC sur armure | — | **Oui**, à ×0,50 |
| Portée | Variable, courte | **70 m** |
| Temps pour une SC | 1,00 s | **1,20 s** |

Les deux armes coûtent presque le même temps pour la même Super-Combine à 1,25 ART, mais **elles ne la déclenchent pas sur la même protection**. Le Needler perce les boucliers, le Fusil à Aiguille perce les armures. **Un joueur qui porte les deux couvre toute la matrice de protections** — et c'est probablement voulu, vu que ce sont les deux seules armes à pics du roster.

**Le critique est le vrai sujet.** Un headshot inflige **1,25 ART d'un coup**, sans avoir à planter trois pics. À 2,5 tirs/s et 70 m de portée avec une lunette ×2,5, ça fait du Fusil à Aiguille **un DMR à 1,25 ART par headshot** — plus fort que le BR75 (1,80 par salve pleine mais en trois balles) rapporté au coût. Le chargeur de 21 vaut **7 Super-Combines = 8,75 ART**, ou 21 headshots à 1,25 = **26,25 ART**. C'est de très loin le meilleur rendement de chargeur du Covenant.

✅ **Tranché — aucun suivi.** Un headshot à 1,25 ART tue net un Elite Minor déprotégé, et deux tuent
Yumiko. L'arme occupe déjà le créneau du **DMR de Halo Reach** dans cette sandbox : mi-longue portée,
sniper léger à headshot. Lui ajouter un guidage sur les têtes **par-dessus** la Super-Combine l'aurait
placée hors barème.

**C'est le seul système à pics du jeu sans assistance**, et c'est ce qui le sépare des deux autres :

| | Needler | Grêleur | **Fusil à Aiguille** |
|---|---|---|---|
| Suivi | Partiel *(CE)* | Guidage chaotique | **Aucun** |
| Ce que l'arme demande | Anticiper | Se placer | **Viser** |

Les trois armes à pics facturent donc trois compétences différentes, et aucune ne facture la même. **La
famille est complète et sans doublon** — le suivi aurait été le seul élément capable de la faire
s'effondrer sur elle-même.

Le **rebond sur les boucliers de Rapace** est une belle contrainte : l'arme la plus précise du Covenant est stoppée par le porte-bouclier le plus basique. Il faut le contourner, pas le percer. Ça crée une hiérarchie de menaces intéressante pour le level design.

Tous les chiffres tombent juste sur cette fiche : 0,05 × 2,5 = 0,125 ✓ · 0,167 × 2,5 = 0,4175 ✓ · 21 × 5 = 105 ✓ · 1,25 × 0,5 = 0,625 ✓.

---

### 2.6 — Grenadier à Plasma

| Champ | Valeur |
|---|---|
| **Classe** | Soutien |
| **Puissance** | **0,40 ART** · 0,664 ART/s · **chargé 1,60 ART** *(consomme 3 munitions)* |
| **Cadence** | 0,6 s · 1,66 tir/s |
| **Chargeur / Recharges** | 8 / 4 · réserve **32** |
| **Portée efficace** | Variable — **plus facile de près** *(temps de trajet)* |
| **Critique cible collée** | **×1,50** → **0,60 ART** (1,00 ART/s) · **tir chargé 2,40 ART** |
| **Malus armures / blindages** | **×0,66** — **n'abîme pas la cible à travers** · le tir chargé passe à **1,056 ART** |
| **Charge dégressive** | Moins de 4 coups au chargeur → **−0,30 ART** par munition manquante |
| **Zone plasma** | **Exactement la même** que celle de la Grenade à Plasma, sur le tir chargé |
| **Reconversion** | Maintenir **X** en visant → **1 grenade plasma = 2 tirs** |
| **Mise en joue** | Réduit le spread · permet de viser correctement le tir chargé |

**Concussion — cibles affectées**

| Unité | Effet |
|---|---|
| Grognards *(sauf Diacre)* | **Désorientés, panique** |
| Ultra, Spec-Ops | Désorientés — **2 tirs nécessaires** |
| Rapaces sans bouclier *(sauf Minor)* | Désorientés |
| Ultra, Champion | Bouclier plus petit que Major/Spec-Ops → affectés **après 2 souffles** |
| **Chieftains** | **IMMUNISÉS** |

L'explosion fait **bondir l'ennemi dans la direction du souffle** → perturbe la visée de toute unité, avec une **diminution drastique de la précision** à régler ennemi par ennemi, l'effet s'atténuant avec la montée en grade.

**Notes**

**C'est l'arme de perturbation du Covenant, l'équivalent fonctionnel du W0-LF côté CSNU.** Elle ne tue pas efficacement — 0,664 ART/s est le plus faible DPS soutenu du roster Élite — mais elle **désorganise**, et sur une sandbox construite autour d'ennemis à conscience collective, désorganiser vaut plus que tuer.

Le tableau de concussion est le morceau le plus important de la fiche, et c'est aussi **le premier document du projet qui établit une hiérarchie explicite de résistance mentale**. Grognards désorientés d'un tir, Ultras et Spec-Ops à deux, Chieftains immunisés. Ça donne au joueur un **outil de lecture du champ de bataille** : ce qui bondit est faible, ce qui tient est gradé. Je recommande de rendre cette lecture visible — animation de bond franche sur les faibles, encaissement planté sur les gradés.

**La reconversion à 1 grenade = 2 tirs** est excellente. Elle branche l'arme sur l'économie de ramassage du niveau, exactement comme le FL01 côté CSNU, et elle crée un arbitrage réel : **une grenade plasma vaut 2,25 ART lancée, ou 0,80 ART tirée en deux coups**. Lancer est presque trois fois plus rentable en dégâts bruts — donc reconvertir n'a de sens que pour la **concussion** et le **contrôle de zone**. Le choix est réel et lisible. Bien.

**La charge dégressive est une mécanique rare et je l'aime beaucoup.** Sous 4 munitions, chaque coup manquant retire 0,30 ART : 3 restants → 1,60 · 2 → 1,30 · 1 → 1,00. L'arme **s'affaiblit en fin de chargeur** au lieu de simplement s'arrêter. C'est le contraire du MA5B qui se renforce en cours de rafale, et les deux mécaniques se répondent bien à l'échelle de la sandbox.

Contre Yumiko, le tir chargé collé à **2,40 ART** laisse 0,10 ART de vie sur 2,50. **Une seule munition de marge.** C'est extrêmement serré, et volontairement : le Grenadier ne one-shot pas, mais il place le joueur à un cran de la mort.

✅ **Le double tir chargé est tranché par §0.11.** Une IA qui **maîtrise les sous-systèmes d'armes et en
est explicitement dotée** peut enchaîner deux charges — 3 munitions chacune sur un chargeur de 8, soit
**4,80 ART en environ 2 s**. Mais c'est désormais l'exception nommée, pas la règle : **par défaut, aucun
porteur ne charge**. Le sous-système est un attribut d'unité, déclaré dans
`comportement-de-l-ennemi.md`, jamais une capacité générique de l'arme.

Cela transforme un problème d'équilibrage en **outil de mise en scène** : quand un Grenadier commence à
charger, le joueur apprend qu'il a en face un porteur d'élite, et le tir chargé devient une **information
lisible** plutôt qu'un pic de dégâts arbitraire. Je recommande un tell visuel franc sur la charge — c'est
la contrepartie naturelle d'un coup qui laisse Yumiko à 0,10 ART.

✅ Le malus armure est fixé à **×0,66 → 1,056 ART** sur le tir chargé, cohérent avec le reste du roster.

---

### 2.7 — Fusil de Précision / Focus Rifle

> **Fiche entièrement révisée par l'auteur.** Le système de chaleur et le tir de Railgun ont été
> réécrits ; les douze seuils antérieurs sont caducs.

| Champ | Valeur |
|---|---|
| **Classe** | Soutien |
| **Puissance** | **0,088 ART** · 0,88 ART/s · **Railgun 1,50 ou 2,50 ART** |
| **Cadence** | 0,1 s · **10 impulsions/s** · consommation **2,75 %/s** |
| **Chargeur / Recharges** | **100 %** · batterie unique |
| **Portée efficace** | **> 50 m — infinie**, comme le sniper humain · seule la **lunette** borne la précision |
| **Surchauffe** | **4 s de tir** · **25 % de chauffe par seconde** |
| **Refroidissement lent** | **7,50 s** pour 100 % *(13,33 %/s)* |
| **Refroidissement rapide** | Appui bref sur *recharger* — **25 %/s** · **valable entre 20 % et 80 % de chauffe seulement** |
| **Malus** | **×0,50** contre armures et boucliers destructibles → 0,44 ART/s · **ne perfore pas** ces protections |
| **Critique** | **×1,75 sur les ennemis brûlés** → **1,54 ART/s** |
| **Lunette** | **×2,5** puis **×7** puis **mise en joue** |

**Tir de Railgun** — *sous-système d'arme · n'applique **aucun** critique du tir de base*

| Voie | Condition d'entrée | Sens | Coût batterie |
|---|---|---|---|
| **À froid** | Chauffe **< 20 %** · maintenir **X** | La chauffe **monte** à 40 %/s | **9 %** |
| **À chaud** | Chauffe **> 80 %** · appuyer **X** | La chauffe **descend** à 40 %/s | **14 %** |

Dans les deux cas : **2 secondes**, soit **80 points de chauffe** parcourus. **RT** pour tirer.
Annulation du tir à froid : **rappuyer sur X**.

**Matrice des marges d'erreur** *(en % de charge / décharge parcourue)*

| Fenêtre | Amplitude | Durée | Résultat |
|---|---|---|---|
| **< 65 %** | — | — | **Raté** — consomme la batterie du tir **sans tirer** · animation de surchauffe **2,0 s** |
| **65 à 72,50 %** | 7,50 pts | **0,1875 s** | **1,50 ART** |
| **72,51 à 80 %** | 7,50 pts | **0,1875 s** | **2,50 ART** |
| **80,01 à 87,50 %** *(tolérance)* | 7,50 pts | **0,1875 s** | **2,50 ART** — frames de rattrapage après la fin de la charge |
| **> 87,50 %** | — | — | **Surchauffe normale — 7,50 s** |

> **Atteindre 100 % / 0 % avant la fin de la fenêtre est impossible** : le déclenchement est borné de
> façon à laisser **20 points de battement** de chaque côté.

**Effet PERFORATEUR du Railgun** : headshot mortel · touche à travers les armures **même
indestructibles** · le headshot reste mortel si le tir outrepasse la protection par sa puissance.

**Tell sonore** : **2 s de charge** et un **sifflement audible par-dessus les bruits ambiants**. L'arme est
rare et portée par peu d'ennemis, jamais en nombre.

**Notes**

**Le rework règle le problème de fond, et il le règle par le bouton plutôt que par la jauge.**

C'était mon reproche principal : douze seuils temporels à tenir en tête en plein combat. Ils ne sont
plus douze, et surtout **le joueur n'a plus à les connaître** — il a une seule touche, **X**, dont le sens
change selon l'endroit où se trouve l'aiguille :

| Chauffe | Ce que fait **X** | Ce que ça veut dire |
|---|---|---|
| **0 – 20 %** | **Charge le Railgun** *(+40 %/s)* | *L'arme est froide : je peux préparer un coup* |
| **20 – 80 %** | **Refroidissement rapide** *(−25 %/s)* | *Je suis en régime de travail, je gère ma chaleur* |
| **80 – 100 %** | **Railgun à chaud** *(−40 %/s)* | *Je suis au bord de la faute : je la convertis* |

**Trois zones, trois sens, un seul bouton.** C'est exactement la jauge à trois couleurs que je
recommandais, sauf que vous ne l'avez pas obtenue en simplifiant l'affichage — vous l'avez obtenue en
faisant coïncider les zones avec les intentions du joueur. C'est nettement mieux : il n'y a plus rien à
mémoriser, il y a une **habitude motrice** à prendre. Le joueur apprendra les bornes en appuyant sur X au
mauvais moment et en récoltant un refroidissement au lieu d'un tir — une erreur bénigne, immédiatement
lisible, jamais fatale. C'est de la pédagogie par le contrôle.

**La marge d'erreur est bien calibrée, et sa générosité est cachée au bon endroit.**

À 40 %/s, chaque tranche de 7,50 points dure **0,1875 s**, soit **11 frames à 60 Hz**. La fenêtre totale
exploitable court de 65 à 87,50 %, soit **0,5625 s** — et le tir à **2,50 ART** occupe à lui seul
**0,375 s**, les deux tiers.

| Instant *(depuis le début de la charge)* | État |
|---|---|
| 0 → 1,625 s | Raté |
| **1,625 → 1,8125 s** | **1,50 ART** |
| **1,8125 → 2,1875 s** | **2,50 ART** |
| au-delà de 2,1875 s | Surchauffe 7,50 s |

**Le joueur qui charge et relâche « à la fin » obtient le tir fort.** C'est le point le plus important de
la matrice : la bande de tolérance 80–87,50 % prolonge le tir maximal *après* la fin nominale de la
charge. Autrement dit, **le comportement naïf est récompensé**, et seuls deux comportements sont punis —
paniquer trop tôt *(< 65 %)* et s'endormir *(> 87,50 %)*. Une fenêtre de 0,375 s pour le coup fort, c'est
la générosité d'un *just frame* de jeu de combat grand public, pas d'un jeu de niche. Bon dosage.

**La nouvelle consommation change l'échelle de l'arme : la batterie n'est plus une contrainte de tir.**

À **2,75 %/s**, une batterie pleine donne **36,4 secondes de tir continu**, soit **32 ART** de dégâts
bruts. C'est de loin la plus grande réserve d'énergie du roster Covenant. Et surtout, elle se cale
exactement sur l'autre limite :

| Repère | Calcul | Résultat |
|---|---|---|
| Un cycle complet jusqu'à la surchauffe | 4 s × 2,75 %/s | **11 % de batterie** |
| Cycles disponibles sur une batterie | 100 ÷ 11 | **9 cycles pleins** |
| Impulsions par cycle | 4 s × 10/s | **40 tirs** |

**Neuf surchauffes avant la panne sèche.** Le joueur ne mourra jamais d'une batterie vide sur cette arme :
il mourra d'avoir surchauffé au mauvais moment. **La chaleur est la vraie ressource, la batterie n'est
qu'un compteur de patience** — et c'est cohérent avec le rôle de soutien, où l'arme doit rester
disponible sur la durée d'une rencontre entière.

**Le rapport de change entre les deux ressources est le chiffre à retenir :**

| Usage | ART par 1 % de batterie |
|---|---|
| **Railgun à froid *(9 %)*** | **0,278** |
| Tir normal, cible nue | 0,320 |
| Tir normal, cible **brûlée** *(×1,75)* | **0,560** |
| Railgun à chaud *(14 %)* | 0,179 |
| Tir normal, cible protégée *(×0,50)* | 0,160 |

**Le rendement le plus élevé de l'arme n'est pas le Railgun, c'est le tir normal sur une cible en feu** —
0,56 contre 0,278, exactement le double. La hiérarchie que ça installe est excellente : le Railgun est
l'outil de **puissance ponctuelle**, la synergie du feu est l'outil d'**efficacité**. Une arme qui a deux
optima différents selon le contexte est une arme qu'on ne joue pas en pilote automatique.

**Et le nouveau barème inverse le sens du choix froid / chaud. C'est le vrai changement.**

Dans la version précédente, le tir à chaud coûtait moins cher que le tir à froid, et l'arithmétique
rattrapait discrètement le déséquilibre. Ce n'est plus le cas : **le tir à chaud coûte 14 %, soit 55 % de
plus que les 9 % du tir à froid.** La voie chaude est désormais la plus chère, franchement, et
explicitement.

| Voie | Batterie | Prérequis | Ce que l'état rend possible |
|---|---|---|---|
| **À froid** | **9 %** | Chauffe < 20 % | Rien de particulier — c'est l'état de départ |
| **À chaud** | **14 %** | Avoir tiré **3,2 s** *(8,8 % de batterie, 2,82 ART déjà placés)* | **Purge intégralement la chaleur** au lieu de subir 7,50 s de refroidissement |

**Ce qu'on achète avec les 5 % d'écart, c'est du temps, pas des dégâts.** Un joueur à 80 % de chauffe a
deux options : subir **6 secondes** de refroidissement lent pour redescendre à zéro, ou payer 14 % et
faire **2,50 ART pendant que l'arme se purge**. Le Railgun à chaud n'est pas un tir, **c'est un
refroidissement offensif** — la conversion d'un temps mort en dégâts. À ce titre, 14 % est le bon prix :
cher en absolu, dérisoire face à six secondes d'immobilité tactique dans une fusillade.

Notez la conséquence sur la ligne complète. Un joueur peut enchaîner **froid → 3,2 s de tir → chaud** :

> **23 % de batterie pour 5,00 ART de Railgun plus 2,82 ART de tir soutenu, en 4 secondes environ, et
> l'arme finit froide.** Soit 7,82 ART pour moins d'un quart de batterie.

C'est la séquence optimale, et je la trouve bien équilibrée parce qu'**elle exige de tenir les deux
fenêtres d'affilée** — deux *just frames* de 0,375 s séparés par 3,2 s de tir maintenu. Rater la seconde
coûte 7,50 s de refroidissement plein, juste après avoir dépensé la moitié du cycle. **Le risque croît
avec l'engagement**, ce qui est exactement la bonne courbe.

Un dernier repère pour la fiche d'ennemi : **11 Railguns froids par batterie** *(27,5 ART)* contre **7 à
chaud** *(17,5 ART)*. Pour un tireur IA habilité au sous-système *(§0.11)*, la voie froide est la seule
raisonnable — une IA n'a aucune raison de convertir sa chaleur, elle a le temps d'attendre. **La voie
chaude est une mécanique de joueur**, et c'est très bien ainsi.

**Le Railgun reste une mort exacte sur Yumiko, à 2,50 ART.**

C'est le chiffre le plus lourd de la fiche et il est inchangé : **2,50 ART = la solidité totale de
Yumiko**, bouclier plus chair, à zéro près.

| Fenêtre | ART | Sur les 2,50 de Yumiko |
|---|---|---|
| 65 – 72,50 % | 1,50 | 1,00 restant |
| **72,51 – 87,50 %** | **2,50** | **Mort exacte** |

**Une arme qui tue en un tir, à portée infinie, sans que la mobilité HORNET puisse y répondre.** Sur un
socle sans sprint, c'est le profil de menace le plus dur du jeu — et il est assumé. Ce qui le rend
acceptable tient en trois verrous, tous inscrits sur la fiche :

| Verrou | Effet |
|---|---|
| **2 s de charge** | Le joueur a deux secondes pleines pour rompre la ligne de vue |
| **Sifflement audible par-dessus l'ambiance** | La menace est **sonore**, donc perceptible hors du champ de vision |
| **Arme rare, jamais en nombre** | Elle ne peut pas saturer une rencontre |

Côté ennemis, le Railgun reste une **arme d'ouverture** plutôt qu'une arme d'exécution : un Élite Dévot
*(3,50 bouclier + 2,25 chair)* encaisse **trois tirs maximaux**. Il casse une protection lourde d'un coup
pour que quelqu'un d'autre finisse — cohérent avec le rôle Soutien et la place de troisième temps.

**La sandbox compte donc toujours quatre morts exactes à 2,50** : le Railgun, la double Super-Combine du
Needler, le Déchiqueteur en dual, et à 0,10 près le Grenadier chargé collé. **Quatre coïncidences au
centième sur quarante-trois fiches ne sont plus des coïncidences** — le bouclier de Yumiko à 100 % reste
le curseur n° 1 du playtest, et le passer à 1,50 ferait basculer une dizaine de lignes.

**Trois morts s'y ajoutent depuis §5.6**, toutes au corps à corps et toutes en dorsal : **lancer de Tourelle Spiker** *(3,15 ART)*, **estoc de Tourelle Plasma sur cible saignée** *(4,60)* et **estoc de Fusil à Plasma sur cible saignée** *(2,55)*. Contrairement aux quatre autres, elles **dépassent** 2,50 au lieu de le frôler — mais elles exigent toutes un dos exposé.

**Le refroidissement lent à 7,50 s est le vrai nerf de la fiche, et personne ne le verra.**

Il passe de 5,0 à 7,50 s — **+50 %** — et le refroidissement rapide, autrefois disponible partout à
33 %/s, est désormais **enfermé dans la bande 20–80 %**. Conséquence : un joueur qui surchauffe n'a
**aucun recours**. Il subit 7,50 s pleines, là où il pouvait auparavant écourter. Combiné à la pénalité de
raté de charge *(2,0 s d'animation, batterie perdue, aucun tir)*, la fiche punit maintenant l'erreur à
deux niveaux différents et avec deux durées différentes. **C'est beaucoup pour une arme de soutien**, et
c'est le seul endroit où je vous invite à surveiller le ressenti au playtest — pas parce que c'est
injuste, mais parce que 7,50 s sur un socle sans sprint, c'est très long.

**Le critique ×1,75 sur les brûlés reste la meilleure interaction inter-armes du projet**, et il gagne en
valeur avec le rework : 0,88 → **1,54 ART/s**. Le Focus Rifle ne perce toujours rien *(×0,50 sur les
protections destructibles, sans perforation)* ; il **cuit ce qui est déjà nu**. Arme de troisième temps,
rôle inchangé et parfaitement clair.

**Arithmétique** : 0,088 × 10 = 0,88 ✓ · 0,88 × 0,50 = 0,44 ✓ · 0,88 × 1,75 = 1,54 ✓ · 7,50 % ÷ 40 %/s =
**0,1875 s** ✓ · 80 pts ÷ 40 %/s = **2,0 s** ✓ · 100 % ÷ 25 %/s = **4 s de tir avant surchauffe** ✓ ·
100 % ÷ 7,50 s = 13,33 %/s ✓. **La fiche tombe juste partout.**

⚠️ **Un seul point à confirmer.** Le Railgun *« n'applique aucun critique du tir de base »* — donc pas de
×1,75 sur les brûlés, c'est clair. Mais le **malus ×0,50 contre armures et boucliers destructibles** est
écrit comme un *malus*, pas comme un critique : au pied de la lettre, il s'appliquerait encore. Or le
Railgun est déclaré **perforateur** et *« touche à travers les armures même indestructibles »* — les deux
lignes se contredisent. Je pars du principe que **le Railgun ignore le ×0,50**, sans quoi son effet
perforateur n'aurait plus d'objet. À confirmer d'un mot.

---

### 2.8 — Canon à Combustible

| Champ | Valeur |
|---|---|
| **Classe** | Lourd |
| **Puissance** | Impact **0,30 ART** (0,66/s) · Souffle **0,65 ART** (1,43/s) · **Total 0,95 ART** · **2,09 ART/s** |
| **Cadence** | 0,455 s · 2,2 tirs/s |
| **Chargeur / Recharges** | 5 / 5 · réserve **25** |
| **Portée efficace** | 7–25 m |
| **Projectile** | **Soumis à la gravité** — vélocité satisfaisante |
| **Mise en joue** | **Aucune** |

**Système de combustible**

| Point | Valeur |
|---|---|
| **Flaque au sol** | **0,08 ART/s** dans le rayon · **4 s** |
| **Critique de la flaque** | **×2,50** sur toutes protections **destructibles** (boucliers, armures) — **sauf blindage** → **0,20 ART/s** |
| **Cumul de zones** | **Aucun** — une zone nouvelle, **de quelque nature que ce soit**, remplace celle qui brûle *(§0.3)* |
| **Marcher dans la flaque** | **0,05 ART** de brûlure au corps · persiste **4 s** après la sortie · **ne se cumule pas** avec la brûlure de flaque · **traverse les protections** |
| **Impact direct** | Brûlure **0,08 ART/s pendant 4 s** · **se cumule** avec la brûlure de flaque · **traverse les protections** · subit les bonus/malus de protection |

**Notes**

**Le Canon à Combustible est un générateur d'état, pas une arme à dégâts.** 0,95 ART par tir avec un projectile balistique, c'est peu ; mais chaque tir laisse une flaque, et la flaque **critique à ×2,50 contre les protections destructibles**. C'est l'inverse exact de tout le reste du roster : une arme dont l'effet secondaire vaut plus que l'effet principal.

Le ×2,50 mérite qu'on s'y arrête. Contre un bouclier, la flaque inflige **0,20 ART/s**. Sur ses 4 secondes de vie, une seule flaque décape **0,80 ART de bouclier** — soit 80 % du bouclier de Yumiko, sans le moindre tir supplémentaire. Un Élite qui pose trois flaques dans un couloir a **transformé le sol en anti-bouclier**. C'est de loin la meilleure valeur défensive du Covenant, et elle est **passive**.

**La distinction flaque / brûlure au corps est très bien pensée** :

| | Source | Valeur | Traverse les protections | Cumul |
|---|---|---|---|---|
| Flaque | Zone au sol | 0,08 ART/s *(0,20 vs protections)* | Non | — |
| Brûlure au corps | Marcher dedans | **0,05 ART** · 4 s après sortie | **Oui** | Non |
| Brûlure d'impact | Coup direct | **0,08 ART/s** · 4 s | **Oui** | **Oui, avec la flaque** |

Un joueur touché directement **puis** traversant une flaque cumule les deux, à travers son bouclier. C'est le seul moyen du Covenant d'attaquer la chair sans avoir percé quoi que ce soit — et c'est cohérent avec D9, qui retire au plasma cette capacité : **le feu la récupère.**

**L'interaction avec le Pistolet à Plasma est le vrai système.** Une charge plasma rallume une flamme, +6,5 s, jusqu'à 10 s après extinction. Ça veut dire qu'une flaque de 4 s peut être entretenue **quasi indéfiniment** par un allié au pistolet. Une escouade Covenant bien composée — un Canon, un Pistolet, un Focus Rifle — produit une zone de feu permanente où le Focus critique à ×1,75. **Trois armes, un système.** C'est la démonstration la plus convaincante de la doctrine « armée vivante et intelligente », et je recommande d'en faire un **archétype d'escouade nommé** dans `comportement-de-l-ennemi.md`.

Le **projectile soumis à la gravité** est le garde-fou : il faut anticiper la chute, donc l'arme est mauvaise à longue portée et contre les cibles mobiles. Sur une Yumiko qui joue la mobilité Hornet, c'est le bon contrepoids — **on esquive un Canon, on n'esquive pas ce qu'il a déjà posé au sol**. L'arme punit la stagnation, exactement ce que le kit de mobilité est censé combattre.

✅ Arrondi corrigé : 0,95 × 2,2 = **2,09 ART/s**.

---

### 2.9 — Épée à Énergie

> **Fiche entièrement révisée par l'auteur.** La batterie devient une **jauge de chauffe**, et la
> **perforation est retirée**. Les quatre taux de consommation antérieurs sont caducs.

| Champ | Valeur |
|---|---|
| **Classe** | **SPÉCIALE / Principale** |
| **Puissance** | **1,50 ART** |
| **Cadence** | **Recovery variable** selon les coups |
| **Ressource** | **Chauffe** — voir le barème ci-dessous |
| **Surchauffe** | À **100 %** : l'épée **se désactive 10 s** |
| **Mode dégradé** | Pendant ces 10 s, le socle fait **poing américain** — mêlée de base **0,50 ART** |
| **Portée efficace** | **Corps à corps** |
| **Perforation** | **AUCUNE** — l'épée ne frappe plus à travers les protections |
| **Dual handling** | **Possible** — **×0,66** → **1,00 ART** *(voir §0.10 : double identique uniquement)* |
| **Mise en joue** | Inexistante · **sauf en gameplay Élite** : dispose d'une **Stance** |

**Barème de chauffe** *(par coup porté)*

| Cible | Chauffe | Coups avant surchauffe |
|---|---|---|
| **Non protégée** *(chair)* | **+15 %** | **7** |
| **Bouclier** | **×0,66** → **+9,90 %** | **11** |
| **Armure** | **Aucune** — 0 % | **illimité** |

**Scaling de combo**

| Coup | Multiplicateur | ART |
|---|---|---|
| 1ᵉʳ | ×1,00 | **1,50** |
| 2ᵉ | **×1,25** | **1,875** |
| **3ᵉ et suivants** | **×1,50** | **2,25** |

*Détail des enchaînements : fiche de moveset de l'épée, à venir.*

**Pattern de base**

| Entrée | Coup |
|---|---|
| **Mêlée 1** | **Coup de poing** — 0,35 ART, mêlée classique |
| **Tir** | **Attaque en crochet** — peut **remplacer** Mêlée 1/2 dans les combos *(ex. uppercut)* |
| **Mêlée 2** | **Attaque verticale** |

Movelist à développer, calquée sur celle du **Dévot** — voir la fiche d'arcade dédiée aux armes de corps
à corps *(§2.9 bis (Épée à Énergie), à venir)*.

**Notes**

**Le rework répond à la contradiction et il fait bien plus que ça : il change la nature de l'arme.**

L'ancienne épée était une **arme de ressource** — quatre taux de consommation, une batterie qui se vide,
un porteur qui peut se retrouver les mains vides. La nouvelle est une **arme de rythme** : elle ne se
vide pas, elle **chauffe**, et elle chauffe *uniquement quand elle fait son travail*. C'est un bien
meilleur objet de design, et pour une raison précise :

> **Le coût n'est plus prélevé sur l'inventaire, il est prélevé sur le tempo.**

Une batterie vide, c'est un joueur qui a mal géré ses ressources dix minutes plus tôt. Une épée en
surchauffe, c'est un joueur qui vient d'être trop gourmand **il y a trois secondes**. La punition est
adjacente à la faute, elle est lisible, et elle enseigne. La ligne « batterie illimitée » devient vraie
au sens strict, sans contredire quoi que ce soit.

**Le compteur dépend entièrement de ce qu'on frappe, et c'est là que le système devient intéressant.**

Trois régimes de chauffe, donc trois durées de vie très différentes pour la même arme :

| Cible | Chauffe/coup | Coups | ART cumulés avec scaling |
|---|---|---|---|
| **Chair nue** | 15 % | **7** | **14,625** |
| **Bouclier** | 9,90 % | **11** | **24,375** |
| **Armure** | **0 %** | **∞** | **illimité** |

**L'épée ne s'use jamais contre ce qui est dur, et elle s'use vite contre ce qui est mou.** C'est
l'inverse exact de l'intuition, et l'inverse exact de l'ancienne fiche — qui facturait 15 % contre les
armures et 5 % contre les boucliers, donc le plus cher pour le plus difficile.

Le sens narratif est immédiat : **la lame se consume dans la matière**, pas dans le métal ni dans
l'énergie. Frapper une plaque d'armure, c'est un choc ; frapper de la chair, c'est une lame qui traverse
et qui brûle. Thématiquement irréprochable.

Mécaniquement, ça produit une règle que le joueur comprendra sans jamais lire un chiffre :

> **On ne paie que quand on tue.**

Ouvrir est gratuit ou presque, achever coûte. L'épée est donc **excellente pour casser des protections**
et **coûteuse pour finir le travail** — soit l'exact opposé de sa réputation, et une raison très concrète
de la jouer en duo avec autre chose. Un porteur d'épée qui ouvre pendant qu'une escouade finit est un
archétype de combat qui naît tout seul de ce barème.

**Le cas de l'armure à 0 % mérite un mot, parce qu'il est plus radical qu'il n'en a l'air.** Combiné au
retrait de la perforation, il dessine un profil très net : contre une cible en armure, l'épée frappe
**indéfiniment**, sans jamais surchauffer, mais **sans traverser** — elle doit détruire la protection
pièce par pièce. C'est lent, c'est sûr, et ça ne coûte rien d'autre que du temps. **Le temps devient la
seule monnaie** face aux unités blindées, ce qui est cohérent avec un socle Halo CE sans sprint où
l'engagement au contact est déjà un pari.

**Les chiffres qui comptent contre les unités réelles** *(en supposant que le scaling tient sur toute la
séquence)* :

| Cible | Coups | Chauffe consommée |
|---|---|---|
| Élite Minor *(0 / 1,00)* | **1** | 15 % |
| Yumiko *(1,00 / 1,50)* | **2** | 24,9 % |
| Élite Major *(2,00 / 1,25)* | **2** | 19,8 % |
| Spec-Ops *(2,00 / 1,75)* | **3** | 34,8 % |
| Élite Ultra *(2,75 / 2,50)* | **3** | 34,8 % |
| Élite Dévot *(3,50 / 2,25)* | **4** | 44,7 % |
| **Élite Général *(6,00 / 2,50)*** | **5** | **54,6 %** |

**Une épée pleine tue deux Généraux d'affilée.** Le plafond n'est donc pas une contrainte offensive —
c'est une **contrainte de continuité** : on ne tient pas un couloir indéfiniment à l'épée, il faut
s'arrêter. Et le fait que les cibles les plus dures coûtent proportionnellement **moins** de chauffe que
les plus molles *(54,6 % pour un Général contre 24,9 % pour Yumiko)* signifie que **l'arme est calibrée
contre l'élite, pas contre le menu fretin**. Faucher des Grognards à l'épée est le pire usage possible de
la ressource. C'est un très bon garde-fou anti-*power fantasy*, entièrement implicite.

**Le scaling de combo est le vrai gain de skill ceiling, et il est agressif.**

Passer de 1,50 à 2,25 au troisième coup, c'est **+50 %**. Rapporté à la chauffe, le rendement explose :

| Régime | ART par coup | ART par % de chauffe |
|---|---|---|
| Coups isolés | 1,50 | **0,100** |
| Combo maintenu *(3ᵉ+)* | 2,25 | **0,150** |

**Enchaîner vaut 50 % de rendement en plus, à coût de chauffe identique.** Le joueur qui frappe, recule,
revient, frappe — le pattern instinctif — brûle son arme une fois et demie plus vite que celui qui tient
son enchaînement. **La ressource récompense l'engagement**, ce qui est exactement ce qu'on attend d'une
arme de corps à corps sur un socle sans sprint.

Et le barème de chauffe **multiplie** cet effet au lieu de l'aplatir :

| Régime | ART par % de chauffe |
|---|---|
| Coups isolés sur la chair | 0,100 |
| Combo maintenu sur la chair | 0,150 |
| Coups isolés sur bouclier | 0,152 |
| **Combo maintenu sur bouclier** | **0,227** |
| Contre une armure | **∞** |

**Le meilleur usage de l'épée est un combo sur une cible protégée** — deux fois et demie le rendement du
pire usage. L'arme pousse donc à ouvrir sur les gradés et à enchaîner, ce qui est précisément la
situation la plus dangereuse pour le porteur. **Le rendement maximal coïncide avec le risque maximal**, et
c'est la marque d'un bon système de ressource. Excellent.

Le crochet sur le **bouton de tir** est la clé technique de ce système : il donne une **troisième entrée**
à la movelist et permet des enchaînements type Mêlée 1 → Tir → Mêlée 2 sans jamais lâcher la garde. Sur
une arme dont le tir est vide par nature, réemployer la gâchette comme entrée de combat est une très
bonne économie de contrôleur — et ça vaudra d'être répliqué sur les autres armes de CAC quand la fiche
d'arcade dédiée arrivera.

**Le poing américain à 0,50 ART est la meilleure trouvaille du rework.**

La question que je posais était : *que se passe-t-il quand l'arme signature tombe à zéro ?* La réponse
n'est pas « rien », c'est **0,50 ART de mêlée de base pendant 10 s** — soit **+43 % au-dessus de la mêlée
Spartane standard (0,35)**, et exactement la valeur du deuxième cran de la grille de Yumiko.

| État | Mêlée de base | Comparaison |
|---|---|---|
| Épée active | 1,50 *(coup d'épée)* | — |
| **Épée en surchauffe** | **0,50** | **> mêlée Spartane 0,35** |
| Mains nues | 0,35 | référence |

**Un porteur d'épée n'est jamais désarmé, il est rétrogradé.** Et il est rétrogradé à un niveau qui reste
supérieur à la norme. C'est cohérent avec le statut d'arme **Principale** : une principale ne peut pas
cesser d'exister. Notez aussi ce que ça fait à la grille de mêlée : à 0,50 de base, le **crit dorsal ×3**
vaut **1,50 ART** *(D14 : le plafond 1,00 ne vaut que sur la base 0,35)* — c'est-à-dire exactement un coup
d'épée. **L'épée en surchauffe rend dans le dos ce qu'elle ne peut plus donner de face.** Je ne sais pas
si c'était calculé, mais c'est une très belle symétrie.

**Le retrait de la perforation était nécessaire, et il coûte moins cher qu'il n'y paraît.**

L'ancienne clause — *« la frappe qui abolit la dernière protection inflige l'entièreté des dégâts au
cuir »* — donnait **le plein montant deux fois**. Combinée à l'ignorance totale des armures, elle faisait
de l'épée une arme sans contre-jeu : un coup qui ouvre était un coup qui tue. Vous avez raison de la
retirer.

Ce qui reste est largement suffisant :

| | Ancienne épée | **Nouvelle épée** |
|---|---|---|
| Coup de base | 1,50 | 1,50 |
| 3ᵉ coup de combo | 1,50 | **2,25** |
| Perforation | **Oui** — plein montant deux fois | **Non** |
| Ignore les armures | Oui | **Non** |
| Contre Yumiko *(2,50)* | 1 coup ouvrant = mort | **2 coups** — ou 1 seul dans le dos |

**Le kill passe de un coup à deux**, ce qui laisse à la mobilité HORNET une fenêtre pour exister. C'était
tout l'enjeu : une arme de corps à corps qui tue en un coup contre un joueur sans sprint ne se joue pas,
elle se subit. Deux coups, c'est un engagement — le premier est une information, le second est une
sanction. **Et le scaling compense la perte** : là où l'ancienne épée plafonnait à 1,50 par coup, la
nouvelle monte à 2,25 si le porteur tient son enchaînement. L'arme n'a pas été affaiblie, **elle a été
déplacée du burst vers la durée**.

**Le dual handling à ×0,66 → 1,00 ART par lame** *(2,00 pour la paire)* reste la meilleure conversion du
jeu, et il tombe désormais sous **§0.10** : deux épées, pas une épée plus autre chose. Avec le scaling,
une paire au troisième coup vaut **3,00 ART par passe** — au-dessus de la solidité totale de Yumiko. Sur
un Dévot, c'est la menace la plus sèche du corps à corps Covenant, et le seul recours reste de ne pas
être là.

⚠️ **Trois points à préciser quand la fiche de moveset arrivera** :

1. **La chauffe suit-elle la protection touchée coup par coup ?** Un enchaînement qui casse un bouclier
   au 2ᵉ coup facture-t-il 9,90 puis 15 % ? *(Je suppose que oui — c'est la lecture littérale, et c'est
   celle que j'ai retenue pour les tableaux ci-dessus.)*
2. **Le scaling se réinitialise-t-il, et après combien de temps ?** Sans fenêtre de reset explicite, un
   joueur qui frappe toutes les 5 s reste au ×1,50 indéfiniment. Une fenêtre de **2 à 3 s** entre deux
   coups semble le bon ordre de grandeur.
3. **Le mode poing américain fait-il monter une chauffe ?** Je pars du principe que non : les 10 s
   s'écoulent, l'épée revient à 0 %.

---

### 2.10 — Grenade à Plasma

| Champ | Valeur |
|---|---|
| **Classe** | **Lancer** |
| **Puissance** | **2,25 ART** |
| **Chargeur / Recharges** | Voir `arcade-yumiko.md` — **8 max**, 2 types équipés |
| **Portée efficace** | Rayon **6 m** |
| **Collage** | Inflige ses dégâts **à travers toute forme de protection** |
| **Mise en joue** | Lancer **direct**, moins en cloche · **garde la grenade en main** · délai **4,50 s** — risque d'explosion en main |
| **Détonation** | **3,50 s** après amorçage · **1,00 s de marche** entre la détonation et l'explosion en main |

**Scaling par distance**

| Distance | Mult. | ART |
|---|---|---|
| 0–2,50 m | ×1,00 | **2,25** |
| 2,51–5 m | ×0,66 | **1,485** |
| 6ᵉ mètre | ×0,35 | **0,7875** |

**ZONE PLASMA**

| Point | Valeur |
|---|---|
| Activation | Un tir de **lance plasma / ravageur / grenadier**, une **charge de tourelle plasma**, un **fusil à plasma**, ou frapper la zone à l'**épée à énergie** |
| **Fenêtre d'activation** | **5 à 6 s** après l'explosion |
| Dégâts | **0,35 ART/s** · brûle **6 s** |
| Brûlure résiduelle *(cible qui s'extrait)* | **0,22 ART/s** pendant **3,50 s** |
| **Cumul** | **Aucun** — une zone nouvelle, **de quelque nature que ce soit**, remplace celle qui brûle *(§0.3)* |

**Notes**

**2,25 ART, c'est 80 % de plus que la grenade à fragmentation** (1,25), et le rapport mérite d'être posé clairement :

| | Frag CSNU | Plasma Covenant |
|---|---|---|
| Puissance | 1,25 ART | **2,25 ART** |
| Rayon plein | 3 m | 2,50 m |
| Collage | Non | **Oui, traverse tout** |
| Critique | ×1,50 armures → 1,875 | — |
| Délai *(mise en joue)* | 3 s | **4,50 s** |
| Zone persistante | Non | **Oui** — 0,35 ART/s pendant 6 s |
| **Stock de 8** | **10,00 ART** | **18,00 ART** |

**Un stock complet de grenades plasma vaut 18 ART, soit près de deux Généraux.** C'est considérable, et c'est équilibré par trois choses : le rayon plein est plus court (2,50 contre 3 m), la frag garde son critique ×1,50 contre les armures, et surtout **une plasma collée est un engagement** — il faut toucher directement une cible mobile qui esquive.

**Le collage qui traverse toute protection est la vraie clé anti-bouclier du Covenant**, et elle est brutale : 2,25 ART sur une Yumiko qui en a 2,50 au total. **Une grenade collée laisse 0,25 ART de vie.** Un quart de cran. C'est la menace la plus sèche de tout le roster ennemi, et elle justifie à elle seule que les Élites sachent viser le collage — c'est le comportement IA le plus rentable qu'ils puissent avoir.

✅ **Le délai est ramené de 5,50 à 4,50 s, et le vrai chiffre est le troisième : 1,00 s de marche.**

La lecture correcte de la nouvelle fiche n'est pas « 4,50 s », c'est **3,50 s de détonation + 1,00 s
avant l'explosion en main**. Le joueur ne joue pas contre le délai total, il joue contre cette seconde-là.

| | Frag CSNU | **Plasma Covenant** |
|---|---|---|
| Délai total | 3 s | **4,50 s** |
| Détonation | — | **3,50 s** |
| **Fenêtre de lancer utile** | ~1 s | **1,00 s** |

**Une seconde, c'est exactement la bonne réponse.** C'est assez pour qu'un joueur qui compte réussisse, et
trop court pour qu'un joueur qui hésite s'en tire. Sur soixante frames, la marge d'erreur est perceptible
sans être confortable — le *cook* redevient une **compétence**, là où 5,50 s en faisaient un pari
inutilisable et 3 s en auraient fait un réflexe gratuit.

Notez la symétrie avec le rework du Focus Rifle traité plus haut : les deux fiches convergent vers des
fenêtres **franches et courtes**, annoncées, sans dégressivité. **0,1875 s pour le Railgun, 1,00 s pour la
plasma cuite.** Ce n'est pas la même exigence — le Railgun demande un timing, la grenade demande du
sang-froid — mais c'est la même grammaire, et le joueur l'apprendra une fois pour toutes.

Reste la question du **risque réel** : une plasma qui explose en main inflige **2,25 ART** sur les 2,50 de
Yumiko, à zéro distance donc sans scaling. **Rater le cook laisse un quart de cran de vie.** C'est le prix
le plus élevé que le jeu fasse payer pour une erreur de timing, et il est cohérent avec le gain — cuire
une plasma, c'est retirer à l'ennemi son unique contre-mesure, l'esquive.

**La Zone Plasma trouve ici sa forme la plus puissante** : 6 secondes, et une brûlure résiduelle plus forte (0,22 contre 0,16). La grenade est donc **le meilleur générateur de zone du jeu**, à condition qu'un allié l'allume dans les 5 à 6 s. Encore une fois, **c'est une mécanique de coordination d'escouade** : un Élite lance, un autre allume. Le joueur solo ne peut le faire qu'en portant deux armes plasma, ce qui est un vrai coût de chargement.

---

### 2.11 — Tourelle à Plasma Fixe

| Champ | Valeur |
|---|---|
| **Classe** | **Lourd FIXE** |
| **Puissance** | **0,109 ART** · **1,199 ART/s** |
| **Cadence** | 0,0909 s · 11 tirs/s |
| **Chargeur / Recharges** | **250 tirs** · batterie · **râtelier de recharge plasma** compatible |
| **Portée efficace** | **40 m** les premiers tirs · **~10 m à partir du 7ᵉ tir** *(dispersion)* |
| **Anti-bouclier** | **×1,25** → 0,136 ART · **1,499 ART/s** |
| **Malus cible non protégée** | **×0,50** → 0,0545 ART · **0,600 ART/s** |
| **Rafales courtes** | De **3 à 6 tirs**, le **dernier coup ×2** |
| **Entretien** | **Entretient les flammes de type plasma (bleues)** — entretenir n'est pas rallumer : aucune zone nouvelle n'est créée *(§0.3)* |
| **Mise en joue** | Réduit le recul, **pas le spread** |

**Estoc-Plasma** — même système que le Fusil à Plasma : coût **35 tirs**, **1,333 ART**, **traverse les boucliers**, fort impact et concussion. *Recharger* pour charger.

**Notes**

**La Tourelle est le troisième porteur anti-bouclier Covenant**, avec un ×1,25 modeste mais appliqué à 11 tirs/s : **1,499 ART/s contre un bouclier**. C'est le meilleur DPS anti-bouclier soutenu du jeu, toutes factions confondues. Le bouclier de Yumiko tombe en **0,67 s**.

Le contrepoids est immédiat et il est excellent : **×0,50 contre les cibles non protégées**. Une fois le bouclier tombé, le DPS s'effondre à 0,600 ART/s — il faut **2,5 secondes de plus** pour finir la chair. La Tourelle décape magnifiquement et achève très mal. **C'est une arme de premier temps**, l'exact complément du Focus Rifle qui est une arme de troisième temps. Deux armes Covenant, deux moitiés d'un même kill.

**La dispersion à partir du 7ᵉ tir est le vrai système.** 40 m sur les six premiers tirs, 10 m ensuite : la Tourelle est un fusil de précision pendant une demi-seconde, puis un arrosoir. Ça pousse au **tir en rafales courtes** — et la fiche récompense précisément ça avec le **dernier coup ×2 sur les rafales de 3 à 6**. Les deux mécaniques pointent dans la même direction : *tapoter, ne pas tenir*. C'est cohérent, lisible, et ça donne à une arme fixe un skill ceiling réel.

Une rafale de 6 optimale vaut donc 5 × 0,109 + 1 × 0,218 = **0,763 ART**, ou **0,954 ART contre un bouclier**. Deux rafales suffisent à ouvrir Yumiko. Sur une tourelle tenue par un Élite en position, c'est une menace sérieuse qui oblige à contourner — exactement ce qu'une arme fixe doit produire en level design.

**L'Estoc-Plasma partagé avec le Fusil à Plasma est un très bon choix de cohérence**, mais la valeur est très différente : **1,333 ART** ici contre 0,65 sur le fusil, pour 35 tirs consommés contre 25. La Tourelle a donc un coup de crosse **deux fois plus fort**. Sur 250 tirs de batterie, ça fait **7 estocs**. Une tourelle arrachée devient une arme de mêlée traversant les boucliers à 1,333 ART — soit plus que le crit dorsal plafonné de Yumiko (1,00). ✅ **Tranché (R1)** : oui, c'est voulu. La base CAC des armes fixes est **0,55 ART**, et l'Estoc Plasma de la Tourelle est une **exception assumée à 1,333 ART** — au-dessus du crit dorsal plafonné de Yumiko (1,00). Une tourelle arrachée est censée être un objet excessif.

L'**entretien des flammes plasma bleues** rattache la Tourelle au système de Zone Plasma. Une tourelle placée à côté d'une zone la maintient allumée en permanence. **C'est le meilleur argument pour placer des tourelles Covenant près de couloirs étroits** en level design.

---

### 2.12 — Grêleur

| Champ | Valeur |
|---|---|
| **Classe** | **Lourd FIXE / Lourd** |
| **Puissance** | **3 × 0,13 ART** · 0,228 ART/s **par projectile** · **0,682 ART/s** en salve |
| **Cadence** | **0,5714 s** · 1,75 tir/s |
| **Chargeur / Recharges** | **165** *(fixe, râtelier Cristaux oranges)* · **33 par chargeur** une fois décroché |
| **Portée efficace** | 7–30 m · **FIXE : jusqu'à 42 m** |
| **Super-Combine** | **9 pics** (3 tirs) → **1,75 ART** |
| **Contre bouclier** | **N'explose PAS** — s'accroche sans infliger de dégâts à travers · **la Super-Combine, elle, fonctionne malgré les protections** |
| **Comportement** | 3 projectiles à vitesse intermédiaire · **peu précis** · ciblage chaotique |
| **Mise en joue** | Aucune · **grossissement ×1,5** une fois décroché |

**Notes**

**Le Grêleur est la SAW du Covenant**, et le parallèle est explicite dans la fiche : chargeur fixe de 165, décrochage par **Mêlée 2**, retour à 33 par chargeur avec maniement Lourd/Soutien. Même verbe, même marché, deux factions. J'aime beaucoup cette symétrie — elle donne au joueur une grammaire de sandbox qu'il apprend une fois et réutilise partout.

**Comme la SAW, il traverse deux régimes de mobilité** *(§0.5–§0.6)* : sur socle, charge **linéaire à 1,05** vers l'avant, sans dérapage ni slide ; décroché, **1,10 libre** avec dérive, redirection et wall jump. La **hauteur de saut reste réduite dans les deux cas** — elle vient du Lourd, le décrochage ne la rend pas. Ici encore, ce que le joueur rachète en décrochant n'est pas de la vitesse (0,05) mais de la **liberté de trajectoire**.

⚠️ Une différence avec la SAW mérite d'être notée : le décrochage se fait par **Mêlée 2**, or en classe Fixe c'est justement le bouton qui **jette l'arme vers l'avant** pour 0,75 ART *(§0.6)*. Les deux actions se disputent la même entrée. Il faut soit un **contexte discriminant** (viser le socle, maintien vs appui court), soit renoncer à l'un des deux sur cette arme — sinon le joueur qui veut frapper lâchera sa tourelle, et inversement.

**La ligne qui définit l'arme est celle-ci** : *« n'explose pas contre les boucliers, s'accroche sans faire de dégâts à travers → l'arme ne s'utilise QUE par sa super-combine »*. Le Grêleur n'a donc **aucun DPS utile contre une cible protégée**. Ses 0,682 ART/s en salve ne s'appliquent qu'à de la chair nue. Contre tout ce qui a un bouclier, l'unique ligne de jeu est : **planter 9 pics, encaisser 1,75 ART d'un coup**.

Le rythme est très lent : 3 tirs à 1,75 t/s = **1,71 s** pour une Super-Combine, soit **1,021 ART/s**. C'est comparable au Fusil à Aiguille (1,042 ART/s), mais avec un ciblage chaotique et une portée trois fois plus courte. **Le Grêleur est donc le plus faible des trois systèmes à pics** — et c'est logique, c'est le seul qui soit aussi une arme fixe avec 165 munitions.

Récapitulatif des trois armes à pics, qui forme maintenant une famille cohérente :

| | Needler | Fusil à Aiguille | Grêleur |
|---|---|---|---|
| Pics par SC | 8 | **3** | 9 |
| SC | 1,25 | 1,25 | **1,75** |
| Temps par SC | 1,00 s | 1,20 s | **1,71 s** |
| ART/s en SC | **1,25** | 1,042 | 1,021 |
| SC sur bouclier | **Oui** | Non | **Oui** |
| SC sur armure | — | **Oui** (×0,50) | — |
| Portée | Courte | **70 m** | 30 m |

**Trois armes, trois vitesses, trois cibles.** La progression est propre : le Needler est rapide et court, le Fusil à Aiguille est précis et long, le Grêleur est lourd et fixe. Aucune ne rend les autres inutiles. C'est le meilleur travail d'archétype de la fiche Covenant.

Contre Yumiko, une Super-Combine de Grêleur retire **1,75 ART sur 2,50** — le bouclier plus la moitié de la chair, en une fois, **malgré le bouclier**. Deux Super-Combines tuent. Sur une arme fixe tenue par un Grognard artilleur, c'est une menace qui oblige à traiter la tourelle en priorité. Bon design d'objectif.

✅ **Cadence fixée à 0,5714 s par tir** *(1,75 tir/s)* — c'est la valeur en secondes qui a été alignée sur
la cadence, et non l'inverse.

**Et la Super-Combine tue plus haut que je ne l'avais écrit.** 1,75 ART **à travers les protections**,
c'est la mort d'un seul déclenchement **jusqu'à l'Élite Spec-Ops inclus** — pas seulement une grosse
entame sur Yumiko. Sur le papier, c'est le coup le plus létal de la famille des pics.

**En pratique, le papier ment, et c'est le meilleur équilibrage de la fiche.** Neuf pics en trois tirs
supposent **trois salves parfaites sur trois** — or l'arme est explicitement *« peu précise, à ciblage
chaotique »*. Il n'y a que deux façons d'y arriver :

| Distance | Pourquoi ça marche | Pourquoi c'est rare |
|---|---|---|
| **Très près** | La dispersion n'a pas le temps de s'ouvrir | Portée minimale 7 m · arme fixe ou Lourde, donc lente à replacer |
| **Assez loin** | Le guidage a le temps de ramener les pics sur la cible | Il faut la **bonne** distance, et une cible qui ne s'écarte pas |

**Entre les deux — c'est-à-dire à la distance de combat normale — la Super-Combine ne sort pas.** Le
Grêleur est donc une arme dont la puissance théorique est plafonnée par sa propre dispersion, et cette
dispersion est un paramètre de terrain, pas de fiche. Hors véhicules, **1,021 ART/s reste très optimiste**.

C'est aussi ce qui le sépare définitivement des deux autres armes à pics : le Needler et le Fusil à
Aiguille facturent une compétence *(anticiper, viser)*, le Grêleur facture une **position**. Trois armes,
trois monnaies. La famille est cohérente et personne n'empiète.

---

## 3. Brutes / Jiralhanae

> 12 entrées. Les valeurs proviennent de la fiche d'équilibrage de l'auteur.
> Les lignes marquées ⚠️ signalent un **écart arithmétique** relevé à la transcription — voir `## 6. Matrice consolidée`.

---

### 3.1 — Fusil à Plasma Brute

| Champ | Valeur |
|---|---|
| **Classe** | **Hybride Principale / Soutien** |
| **Puissance** | **0,125 ART** · **0,750 ART/s** |
| **Cadence** | 0,167 s · **6,0 tirs/s** — cadence maximale **immédiate** |
| **Chargeur / Recharges** | **200** · batterie unique |
| **Portée efficace** | 5–15 m |
| **Malus cible non protégée** | **×0,80** → **0,100 ART** · **0,600 ART/s** ✅ |
| **Surchauffe** | **27 tirs** · **4,50 s** de tir continu · refroidissement **5 s** ✅ |
| **Refroidissement rapide** | *Recharger* → **3,5 s** pour 100 % |
| **CAC** | **0,55 ART** ✅ · lame sous le canon · **pattern propre** (Mêlée 1, Mêlée 2…) |
| **Dual handling** | **Impossible** *(sauf certains Brutes / Élites)* |
| **Mise en joue** | **Aucune** |
| **Critique** | **Aucun** |

**Brûlure**

| Point | Règle |
|---|---|
| Déclencheur | **Dernier tir** sur une cible **sans bouclier** — y compris blindée ou armurée |
| Puissance | **0,05 ART/s** pendant **3,5 s** *(0,175 ART au total)* |
| Cumul | **Aucun** — chaque tir *reset* le compte à rebours et le dégât |
| Malus | Le **×0,80 ne s'applique pas** à la brûlure |

**Tirs cumulés — flaque de plasma instable**

| Point | Règle |
|---|---|
| Déclencheur | **16 tirs consécutifs** sans se rater sur la même cible *(2,67 s de tir)* |
| Effet | **Flaque de plasma en feu** aux pieds de la cible |
| Durée / Puissance | **PLASMA INSTABLE** — **0,16 ART/s** · flaque **4,50 s** · brûlure **2,50 s** *(§5.1)* |
| Entretien | **Chaque salve de 6 tirs** entretient la brûlure *(§5.2)* |
| Compatibilité | **Effet identique** pour tout feu plasma déclenché par une autre arme **Plasma Brute** |

**Notes**

**C'est le miroir déformé du Fusil à Plasma Élite, et la déformation est bien choisie.** Même dégât par tir (0,125), même malus de principe sur la chair, mais tout le reste s'inverse : là où l'arme Élite monte progressivement de 3,5 à 5 tirs/s et récompense l'entretien du feu, la Brute crache **6 tirs/s dès la première frame** et punit exactement le même comportement — 27 tirs et l'arme est morte pour 5 s. **L'Élite récompense la tenue de gâchette, la Brute la sanctionne.** Deux fusils de base, deux philosophies opposées : c'est la meilleure façon de rendre une faction reconnaissable à l'oreille avant même de la voir.

Le rapport est brutal en chiffres : **0,750 ART/s contre 0,625** pour l'Élite à cadence haute, mais seulement **4,50 secondes** de fenêtre. Sur un engagement long, l'Élite gagne largement ; sur une embuscade de 3 secondes, la Brute inflige **2,25 ART** — de quoi vider le bouclier de Yumiko et entamer sa chair avant qu'elle ait pu répondre. Sur la **fenêtre pleine de 27 tirs**, elle délivre **3,375 ART contre bouclier** : le chargeur entier tue Yumiko, mais il faut les 27 tirs au but. **L'arme est un outil d'ouverture, pas d'attrition.** Le refroidissement rapide à *Recharger* (3,5 s au lieu de la redescente lente) est le geste qui sépare un Brute joué correctement d'un Brute qui s'arrose.

**La flaque à 16 tirs consécutifs est la mécanique la plus intéressante de la fiche, et elle est en tension avec la surchauffe.** Il faut 16 tirs sans se rater pour déclencher la flaque, et l'arme surchauffe à **27**. La fenêtre de réussite est donc de **11 tirs de marge, soit 1,83 s** — assez serrée pour que ce soit une vraie performance, assez large pour être atteignable. ✅ **Le passage de 24 à 27 tirs desserre volontairement cet étau** : l'ancienne marge de 8 tirs rendait la flaque presque théorique contre une cible mobile. Le décompte bénéficie d'un **cooldown de 2,00 s** entre deux salves *(§5.2)*. C'est du bon *skill gating*. Deux conséquences de design : contre une cible qui esquive, la flaque est presque impossible ; contre une cible bloquée ou lente, elle est quasi automatique. **Cela fait du Fusil à Plasma Brute une arme anti-position, pas une arme anti-mobilité** — cohérent avec un socle sans sprint où le joueur qui se plante derrière une couverture doit être délogé.

**La brûlure ignore le malus ×0,80, et c'est important.** C'est la seule voie par laquelle cette arme frappe la chair à pleine puissance. 0,05 ART/s pendant 3,5 s, non cumulable, entretenue par chaque tir : un Brute qui garde le contact maintient **0,05 ART/s permanent** en plus de ses **0,600**. Modeste seul, décisif à trois — et le rapport s'est **accentué** avec l'arbitrage ×0,80 : la brûlure vaut désormais **8,3 %** du DPS chair de l'arme au lieu de 7,4 %.

✅ **Écart O tranché — le multiplicateur fait foi, pas le chiffre.** Le malus chair est **×0,80**, soit **0,100 ART** par tir et **0,600 ART/s**. Les valeurs de 0,112 et 0,672 impliquaient un ×0,896 qui n'était écrit nulle part et qui aurait fait de cette arme **la meilleure arme plasma contre la chair** — en contradiction directe avec son rôle d'ouverture et avec **D9**. Le roster des malus chair plasma est désormais régulier : Tourelle ×0,50 · Pistolet ×0,75 · **Fusil Brute ×0,80** · Fusil Électrique ×0,25.

✅ **Surchauffe fixée à 27 tirs / 4,50 s.** À 6 tirs/s, 27 tirs valent exactement 4,50 s : les deux écritures de la fiche coïncident et le chiffre reste rond en temps. Les anciennes valeurs de 24 et 25 tirs sont abandonnées. Conséquence à retenir : **le refroidissement de 5 s reste plus long que la fenêtre de tir**, donc l'arme passe toujours plus de temps à refroidir qu'à tirer si le porteur la pousse à bout.

✅ **Écart P tranché — le CAC de cette arme est 0,55 ART.** La fiche du Sabre Grenade la citait à 0,65 en la donnant pour référence commune ; c'est l'inverse qui est retenu. **0,55 est la base des armes à lame sous le canon** ; le **0,65 du Sabre Grenade est une exception propre à cette arme**, payée par sa parade et sa Mêlée 2 à 0,8775.

---

### 3.2 — Mauler

| Champ | Valeur |
|---|---|
| **Classe** | Légère |
| **Puissance** | **1,00 ART** par tir — **schrapnel seul** · **1,33 ART/s** |
| **Cadence** | **0,75 s** · **1,33 tir/s** |
| **Chargeur / Recharges** | 5 / 5 · réserve **25** · **dual : réserve 40** *(8 chargeurs)* |
| **Portée efficace** | **2–5 m** — au-delà, le schrapnel se dilue |
| **Bonus armures** | **×1,35** → **1,35 ART** |
| **CAC** | **0,50 ART** — pointe sous l'arme · **saignement à travers les armures** *(§5.6)* · pas de pattern propre |
| **Dual handling** | **Oui** — réserve portée à **40** |
| **Tir au jugé** | **Single handling uniquement** |
| **Mise en joue** | **Hors dual uniquement** · repousse le fall-off des schrapnels |

**Notes**

**Le Mauler perd son tir principal et devient un pur fusil à schrapnel.** Toute la composante « mangler » — le projectile précis à 25 m, le malus ×0,50 contre les protections, le critique sur points faibles — disparaît. Ce qui reste est une arme à une seule munition, une seule portée, une seule lecture : **2 à 5 m, 1,00 ART, sinon rien**. La fiche précédente empilait quatre cadences contradictoires ; il n'en reste qu'une, **0,75 s**, et le DPS en découle sans arbitrage : **1,33 ART/s**.

**La justification de la classe Légère change de nature, et elle est meilleure.** Avant, l'arme était légère parce qu'elle était inoffensive de loin *tout en gardant* une sortie de secours à 25 m. Maintenant elle est légère parce qu'elle **n'a aucune sortie** : hors de cinq mètres, le porteur est désarmé. C'est le prix le plus net qu'une arme paie dans la sandbox pour ne pas taxer la mobilité, et il rend le triangle lisible — le Mauler achète du Tir de contact avec de la portée, pas avec de la Mobilité.

**Le bonus ×1,35 contre les armures inverse complètement le rôle de l'arme.** L'ancien Mauler était puni par les protections *(×0,50)* ; le nouveau les cherche. À **1,35 ART par tir**, deux tirs valent 2,70 ART sur une cible blindée, en 0,75 s d'intervalle. Le Mauler devient **l'ouvre-boîte de contact des Brutes**, là où le Fusil Électrique est leur ouvre-boîte à distance et ne touche justement **pas** aux armures. Les deux armes de la faction se partagent le problème sans se recouvrir : l'une casse le bouclier de loin, l'autre casse l'armure de près.

**Le saignement à travers les armures est l'information la plus lourde de la fiche.** C'est la pointe sous l'arme, pas le tir, qui le porte — et elle est **le seul CAC de la sandbox dont la plaie ignore l'armure** *(§5.6)*. Une arme Légère qui contourne la protection au corps à corps donne au porteur une raison de rester au contact même chargeur vide. Combiné au bonus ×1,35, cela dessine une arme entièrement anti-armure : **tirer pour percer, frapper pour faire durer**. Se référer à la matrice des effets pour le détail de la plaie et de sa cautérisation.

**Le tir au jugé réservé au single handling est le garde-fou du dual.** Deux Maulers font **2,00 ART par salve double** — 80 % de Yumiko en un temps de réaction, 2,70 sur une cible blindée. Ce qui empêche l'abus n'est plus un spread sur un tir principal qui n'existe plus, c'est le **retrait du tir au jugé** : en double, le porteur doit engager de face, sans la liberté de viser à la hanche en mouvement. La réserve portée à **40** *(8 chargeurs au lieu de 5)* est la contrepartie, et elle est correctement dosée — elle donne au double sa durée de vie sans lui donner sa liberté.

**Le contraste avec le M90 reste net et se durcit.** Le CAWS fait 1,375 ART, 6 cartouches, classe Soutien, crit ×1,50 sous 4 m. Le Mauler fait 1,00 ART, 5 cartouches, classe Légère, **×1,35 sur armures**. Le M90 frappe plus fort dans l'absolu ; le Mauler frappe plus fort sur ce qui est protégé, et deux fois. **Arme de couloir contre arme de duel mobile** — la séparation tient, et elle tient mieux qu'avant maintenant que le Mauler a renoncé à la moyenne portée.

---

### 3.3 — Sabre Grenade

| Champ | Valeur |
|---|---|
| **Classe** | Principale |
| **Puissance** | **0,45 ART** · **0,90 ART/s** *(impact + souffle **toujours cumulés**)* |
| **Cadence** | **0,50 s** · **2,0 tirs/s** |
| **Chargeur / Recharges** | 6 / 4 · réserve **24** |
| **Portée efficace** | 5–20 m |
| **CAC** | **0,65 ART** · **pattern propre** · **parade** *(comme marteau / épée / Lance Spartane)* |
| **Mêlée 2** | **0,8775 ART** · **saignement** *(§5.6)* |
| **Mise en joue** | Existe · réduit un spread déjà faible — **sans utilité pratique** |
| **Souffle** | **Arme cinétique** — impact et souffle cumulés, éteint un feu d'un seul coup *(§5.4)* |

**Tirs consécutifs sur la même cible**

| Tir | Multiplicateur | ART |
|---|---|---|
| 1ᵉʳ | — | **0,45** |
| **2ᵉ** | ×1,10 | **0,495** |
| **3ᵉ** | ×1,25 | **0,5625** |
| **4ᵉ et +** | ×1,50 | **0,675** |

**Notes**

**La fiche est désormais arithmétiquement exacte, et c'est la seule du lot Brute à l'être au centième près.** 0,45 × 2,0 = 0,90 ART/s ; les trois crits tombent juste à 0,495, 0,5625 et 0,675. Plus aucun écart à signaler.

**L'arme gagne en puissance ce qu'elle perd en cadence, et le bilan est légèrement à la hausse.** L'ancienne fiche donnait 0,334 à 2,5 tirs/s, soit 0,835 ART/s ; la nouvelle donne 0,45 à 2,0 tirs/s, soit **0,90 ART/s**. Le gain de DPS est modéré *(+8 %)*, mais **le coup unitaire monte de 35 %** — et c'est lui qui compte sur une arme à souffle, parce que c'est lui qui décide si un ennemi est déplacé ou non, si un feu est éteint ou non, si un bouclier tombe en un coup ou deux. **Le Sabre devient plus lourd et moins bavard**, ce qui le rapproche de sa lecture voulue : une arme d'attrition explosive, pas un arrosoir.

**Le chargeur entier sur la même cible vaut désormais 3,53 ART.** 0,45 + 0,495 + 0,5625 + 0,675 × 3 = **3,5325**. C'est 0,91 de plus que l'ancienne fiche *(2,62)*, et cela dépasse Yumiko entière d'une marge nette. Mais la condition n'a pas bougé : **six coups au but sur une cible qu'on vient soi-même de projeter**, en **3,0 s** au lieu de 2,4. La fenêtre s'allonge, la cible a plus de temps pour sortir du champ — **la contradiction interne de l'arme se creuse au lieu de se résoudre**, et c'est très bien. Le tireur qui veut l'escalade complète doit viser où la cible *va être poussée*, six fois de suite, une seconde de plus qu'avant.

**La comparaison avec le M319 se resserre sans se brouiller.** Le lance-grenades humain fait 1,25 ART en un projectile, chargeur de 1, avec des modes. Le Sabre fait **0,45**, six fois, à 2 tirs/s. Le rapport unitaire passe de 3,7:1 à **2,8:1** — le Sabre se rapproche, mais la différence de nature tient : **le CSNU explose une fois fort, la Brute explose six fois vite.** Sur un socle sans sprint, la seconde reste la plus dangereuse.

**La Mêlée 2 à 0,8775 avec saignement est le vrai plafond de l'arme au contact.** C'est presque le double d'un tir plein, et la plaie s'y ajoute *(§5.6)*. Combinée à la parade, elle fait du porteur de Sabre un adversaire complet à toutes les distances de la fiche — **ce qui rend la question du porteur plus urgente qu'avant**. Un troupier standard équipé de cette arme parerait la charge de Yumiko *et* la saignerait en réponse. Il faudra dire quelles unités Brutes la portent.

**L'effet de concussion reste le paramètre non chiffré le plus sensible de la fiche.** À 0,45 ART par détonation au lieu de 0,334, la poussée infligée — si elle est indexée sur la puissance — augmente mécaniquement. Six corrections de trajectoire imposées à Yumiko en vol, plus fortes qu'avant, sur le seul terrain où elle n'a pas de plancher pour se rattraper. **Le déplacement doit être chiffré avant les dégâts**, et il doit être chiffré en valeur fixe, pas en fraction de la puissance, sans quoi chaque futur ajustement de dégâts déplacera aussi le contrôle.

---

### 3.4 — Fusil Électrique

| Champ | Valeur |
|---|---|
| **Classe** | **Principale** — **arme d'assaut Brute**, pendant du MA5B *(§1.2)* et du Répéteur à Plasma *(§2.4)* |
| **Puissance** | **0,40 ART** · **0,727 ART/s** |
| **Cadence** | **0,55 s** · **1,82 tirs/s** ✅ |
| **Chargeur / Recharges** | **12** · **5 recharges** *(réserve 60)* — **72 tirs** au total |
| **Portée efficace** | **12,50 – 25 m** ✅ — projectile qui **ralentit à 17,50 m**, **vitesse nulle à 25 m** : au-delà, le tir ne porte plus |
| **Fall-off** | **17,50 → 25 m** : **critique supprimé** *(plus de ×1,50)* **et dégâts ×0,75** → **0,30 ART/tir** · **0,545 ART/s** |
| **Critique** | **×1,50 contre les boucliers** → **0,60 ART/tir** · **1,091 ART/s** *(sous 17,50 m)* |
| **Malus cible non protégée** | **×0,25** → **0,10 ART/tir** · **0,182 ART/s** |
| **Armures** | **Aucun multiplicateur** — ni bonus, ni malus |
| **Report** | **Intégral** *(D17)* — **aucun gaspillage** sur le tir qui finit une protection ; le reste prend le **×0,25** de la chair |
| **Mise en joue** | **Aucune** |

**Frappe IEM — à la chute d'une protection**

| Point | Règle |
|---|---|
| Déclencheur | **Désactivation d'une armure ou d'un bouclier** |
| Effet sur la cible | **Explosion dynamo — 0,35 ART**, de **type mêlée** |
| Effet de zone | Les **cibles toutes proches** encaissent la même explosion — **sans IEM** |
| Cumul | **Aucun scaling armures, aucun dégât « consécutif » contre une cible protégée** |

**Charge Dynamo — coups consécutifs sur cible NON protégée**

| Tir | Dégât infligé | Détail |
|---|---|---|
| **1er** | **0,10** | Le tir malusé, seul |
| **2e** | **0,20** | Réactive le 1er tir **et** encaisse le sien |
| **3e** | **0,40** | Réactive les deux précédents *(0,10 + 0,20 + tir)* |
| **4e** | **0,40 + explosion** | Dégât du 3e, **puis explosion Dynamo de GRENADE** : onde de choc **0,35** + **IEM 1,05 ART** autour de l'ennemi explosé, **contre les boucliers** |

| Point | Règle |
|---|---|
| Fenêtre d'amorçage | Le **2e tir** doit venir **moins de 3,50 s** après le 1er |
| Entretien | Une cible **chargée** — **quel que soit le stade** — doit être retouchée **dans les 2,50 s**, sinon **la charge se dissipe** |
| Plafond | **3 cumuls multipliants** |

**Propagation par marquage**

| Point | Règle |
|---|---|
| Qui est marqué | Les ennemis pris par l'explosion de Charge Dynamo **sans protection susceptible de subir l'IEM** |
| Ce qu'ils encaissent | **0,35 seulement**, de **type mêlée** |
| Durée du marquage | **2,50 s** |
| Réactivation | Leur **tirer dessus au Fusil Électrique** — ou y **envoyer une Grenade Dynamo** — **relance une explosion dynamo** |
| Entretien de la chaîne | Chaque ennemi **marqué** pris par cette explosion voit son **cooldown de 2,50 s réactivé** |

**Notes**

**Le changement de rôle est net et il est réussi : l'arme est passée de DMR longue portée à arme d'assaut.** La V1 tenait 10–50 m avec deux lunettes ; la V2 meurt à **25 m**, son projectile ralentit dès **17,50 m**, et elle se tire **sans mise en joue**. Ce n'est plus une arme qui tient une ligne de vue, c'est **le fusil d'assaut des Brutes** — le pendant du **MA5B** *(§1.2)* et du **Répéteur à Plasma** *(§2.4)*, troisième pilier d'un trio que chaque faction possède désormais.

**Le trio des armes d'assaut se lit d'un coup d'œil, et il est remarquablement bien réparti.**

| | MA5B *(§1.2)* | Répéteur *(§2.4)* | **Fusil Électrique** |
|---|---|---|---|
| ART/s chair | **0,885** | 0,684 → 0,912 *(idéal)* | **0,182** *(plat)* · **0,500** *(Charge)* |
| ART/s bouclier | 0,708 *(×0,80)* | 0,684 → 0,912 | **1,091** *(×1,50)* |
| Par tir | 0,059 | 0,076 | **0,40** |
| Cadence | 15 t/s | 9 → 12 t/s | **1,82 t/s** |
| Munitions | 60 / 300 | 380 *(batterie)* | **12 / 60** |
| Portée | 10–25 m | 0–8 m puis ~35 m | **12,50–25 m** |

**Les trois DPS bruts se tiennent dans un mouchoir — 0,885 / 0,684 / 0,727 — mais aucune des trois armes ne se joue pareil.** Le MA5B est l'arme du **volume** : 15 tirs/s, 60 balles, il pardonne les tirs manqués et monte en puissance sur la durée de rafale. Le Répéteur est l'arme de l'**entretien** : batterie de 380, il ne recharge jamais mais doit gérer sa chauffe. Le Fusil Électrique est l'arme du **coup placé** : **6,78 fois plus de dégâts par tir que le MA5B** pour **8,25 fois moins de cadence**. Le même DPS, obtenu par le chemin exactement inverse.

**Et c'est là que la répartition devient intéressante : les trois sont inversées sur la cible qu'elles préfèrent.** Le MA5B est **puni** contre les boucliers *(×0,80)* et bon sur la chair. Le Répéteur est **neutre** sur les deux. Le Fusil Électrique est **excellent** contre les boucliers *(1,091 ART/s — le meilleur des trois)* et **catastrophique** sur la chair nue *(0,182, soit cinq fois moins que le MA5B)*. Chaque faction a son arme de base, et chaque arme de base a un angle mort différent. **Un joueur qui ramasse une arme d'assaut adverse change de problème, pas de puissance.**

**La zone de fall-off est le meilleur morceau de la fiche.** Entre 17,50 et 25 m, l'arme perd **le critique et 25 % de ses dégâts en même temps** — contre bouclier elle tombe de **0,60 à 0,30 ART/tir**, soit exactement **la moitié**. Ce n'est pas une dégressivité molle, c'est une **falaise assumée**, et elle est lisible par le joueur parce que le projectile **ralentit visiblement** avant d'y entrer. La lisibilité est portée par la physique du tir, pas par un chiffre caché : c'est la bonne façon de faire.

**Sans mise en joue, c'est la cadence qui sert de verrou — et elle suffit.** Une arme d'assaut se tire en mouvement, donc rien ne bride le porteur côté posture. Ce qui le bride, c'est **0,55 s entre deux tirs** : à cette cadence, **chaque tir manqué coûte une demi-seconde** et repousse d'autant la chute du bouclier. Le MA5B pardonne l'imprécision par le volume, le Répéteur par sa batterie ; **le Fusil Électrique ne pardonne rien**, avec 12 coups au chargeur et un tir toutes les demi-secondes. C'est un fusil d'assaut qui se joue comme une arme de précision, et c'est ce qui le rend brute sans le rendre facile.

**La Charge Dynamo conserve l'intention de la V1 — récompenser l'obstination — mais elle est enfin lisible.** La V1 empilait quatre systèmes dont deux invisibles. Ici il n'en reste **qu'un seul compteur**, de 1 à 4, sur une cible sans protection. Le total du cycle est de **1,10 ART en 4 tirs** contre **0,40** pour quatre tirs plats : la mécanique vaut un facteur **×2,75**. C'est elle, et non le dégât de base, qui rend l'arme viable sur la chair malgré le ×0,25.

**Les deux fenêtres ne punissent pas la lenteur, elles punissent le changement de cible — et la cadence le confirme.** À 0,55 s par tir, la fenêtre d'amorçage de 3,50 s laisse **6,36 tirs** de marge et l'entretien de 2,50 s en laisse **4,55**. Autrement dit : en tirant normalement sur la même cible, **on ne perd jamais sa charge** — il faut manquer quatre tirs d'affilée, ou partir sur quelqu'un d'autre. Les fenêtres ne sont pas un test de vitesse, elles sont un test de **discipline de cible**. L'arme dit une seule chose : **finis ce que tu as commencé.**

**Le chargeur de 12 est calibré, et c'est le meilleur réglage de la fiche.** Il vaut **6,6 s de tir continu** et **7,20 ART contre bouclier** — de quoi dépouiller **presque trois Élites Major** sans recharger. Mais la dotation complète est de **72 tirs**, soit exactement **9 Majors**, pas un de plus. L'arme ne manque jamais de munitions dans un échange ; elle en manque sur **une rencontre entière**. C'est la bonne pression : elle force à choisir **quelles** protections on casse, sans jamais rendre l'arme inutile au mauvais moment.

**Le seuil qui mérite d'être surveillé, c'est l'IEM de 1,05 ART du 4e tir.** C'est **exactement la valeur d'une Grenade Dynamo** *(0,35 × 3, §3.10)*, mais délivrée par une arme à munitions au lieu d'un consommable. La condition d'accès est réelle — il faut une cible **sans protection** à côté de cibles **avec** — mais c'est la composition d'escouade Covenant la plus banale qui soit : des porteurs légers autour d'un Élite. **Acharner sur le plus faible pour dépouiller le plus fort** est un raisonnement excellent et parfaitement dans le ton Brute ; il faut simplement savoir que la Grenade Dynamo devient, dans ces conditions, **reproductible sans coût**.

**Deux résultats de convergence tombent juste, et ils ne sont pas volontaires.** Contre un **Élite Major** *(bouclier 2,00 · chair 1,25)* : 4 tirs cassent le bouclier, le report rend 0,10, l'IEM 0,35, et le cycle de Charge Dynamo complet achève exactement au **4e tir de charge** — soit **8 tirs**, dont le dernier **détone**. Contre un **Élite Minor**, le compte tombe à **5 tirs**, c'est-à-dire **le chiffre exact de la V1**. La refonte a changé toute la mécanique **sans déplacer les temps de mise à mort** : c'est le signe que le rôle a bougé, pas la puissance.

**La cohérence interne est vérifiée.** 0,40 × 1,82 = **0,7272**, et 0,40 ÷ 0,55 = **0,7273** : les trois écritures de la cadence *(secondes, tirs/s, DPS)* coïncident, ce qui n'allait pas de soi — c'est précisément là que les écarts **S** et **U** étaient nés sur les fiches précédentes. **Le 0,727 est confirmé, pas reconduit.**

**Le seuil bas de 12,50 m est le vrai verrou, et il place l'arme précisément entre ses deux homologues.** La portée efficace ne commence pas au canon : sous 12,50 m l'arme n'est pas à son régime, et elle est morte à 25 m. Elle ne travaille donc que dans une **bande de 12,50 m de large** — là où le MA5B couvre 10–25 m et le Répéteur 0–8 m puis ~35 m. **Le Fusil Électrique est le seul des trois qui soit mauvais au contact**, ce qui est un choix fort pour une faction réputée pour la charge : le Brute qui porte cette arme ne peut pas foncer, il doit **tenir sa distance** — le corps à corps appartient au Mauler et au Marteau, la longue portée au Fusil à Faisceau. **Aucune arme Brute ne se marche dessus sur l'axe de la portée.**

✅ **La fiche est complète — aucun chiffre n'est dû** *(point 45 clos)*. L'arme n'ayant **pas de mise en joue**, la question de la lunette est **sans objet**.

### 3.5 — Marteau Antigravité

| Champ | Valeur |
|---|---|
| **Classe** | **HYBRIDE** — arme spéciale **avec** boost de marche à **1,10**, mais **sans dual** |
| **Puissance** | **2,25 ART** |
| **Recovery** | **1,0 s** |
| **Chargeur / Recharges** | **100** · batterie unique |
| **Portée efficace** | **5 m** — zone |
| **Véhicules** | **350 dégâts** |
| **Pattern** | **Unique**, basé sur la **movelist du Chieftain Brute** |
| **Mise en joue** | Prépare une **frappe lourde** avec **onde de choc au sol** |

**Les trois entrées d'attaque**

| Entrée | Effet | Coût |
|---|---|---|
| **Mêlée 1** | Coup classique **avec le manche** | **Rien** |
| **Mêlée 2** | Coups **verticaux**, frappe au sol · onde de choc **7,50 m** glissant **en s'élargissant** · **0,75 ART** cumulés aux dégâts normaux → **3,00 ART** | **7,50 %** de batterie |
| **Bouton de tir** | Frappe au sol, **onde cinétique** | **10 %** de batterie ❓ *(valeur laissée en question par l'auteur)* |

**Recharge cinétique**

| Source | Taux |
|---|---|
| Boost consommé | **1 %** tous les **10 %** de boost |
| **Mêlée donnée** | **3,50 %** par coup — Mêlée 1 **ou** mêlée d'une autre arme, **marteau rangé** |
| **Mêlée reçue** | **5 %** par coup encaissé |

**Effet de souffle**

L'onde de choc **souffle les flammes** — **tout feu, au sol comme sur une cible, éteint d'un seul coup** *(§5.4)*. Si **Yumiko** brûle, sa propre frappe **éteint ses flammes**. Vaut aussi pour les ennemis porteurs et pour le **marteau intégré du Déchiqueteur**.

**Notes**

**2,25 ART en zone de 5 m, ou 3,00 avec la frappe au sol : c'est désormais le coup le plus puissant de la sandbox.** Il tue Yumiko avec 0,50 ART de marge. C'est assumé et c'est juste — le marteau est *l'*arme signature du Chieftain, elle doit terrifier.

**Le passage en classe HYBRIDE renverse la lecture précédente, et il faut le dire franchement : l'ancienne fiche disait l'inverse.** Elle refusait le bonus de marche 1,10 et imposait les pénalités du Soutien ; j'avais lu ça comme « le marteau achète le sommet Mêlée en vendant le sommet Mobilité ». **Ce n'est plus vrai.** Le marteau garde sa mobilité de marche, et ce qu'il vend à la place, c'est **le dual** — là où l'Épée à Énergie, elle, le conserve. La séparation entre les deux armes de mêlée signature ne passe plus par la vitesse mais par **le nombre de mains occupées** : l'épée se double, le marteau non. C'est une distinction plus propre, parce qu'elle ne punit pas le porteur sur un axe *(la mobilité)* qui est justement le cœur du jeu.

**Conséquence directe à acter : le verrou « pas d'armes spéciales » ne s'écrit plus de la même façon pour cette arme.** Le marteau était cité comme l'arme qui *refuse* le bonus 1,10 ; il l'accorde désormais. Voir la liste complète des fiches concernées en fin de réponse — c'est la seule contradiction directe que le rework introduit dans le document.

**La Mêlée 1 gratuite change la nature de l'économie.** Avant, la lame de secours coûtait zéro et rapportait 1 % : c'était un générateur lent. Maintenant le coup de manche **ne consomme rien et rapporte 3,50 %** — trois fois et demie plus. Le porteur à sec n'attend plus, **il travaille** : trois coups de manche rendent 10,50 %, soit une frappe au sol et demie. La boucle se ferme en quelques secondes au lieu de plusieurs dizaines. **Le marteau cesse d'être une arme rare pour devenir une arme entretenue**, et c'est un choix de rythme différent — plus agressif, plus proche de la movelist du Chieftain dont le pattern s'inspire.

**Les 5 % par mêlée reçue sont la meilleure ligne de la fiche.** Le porteur se recharge **en encaissant**. Contre Yumiko, dont tout le jeu de mêlée repose sur la charge et le combo dorsal, cela veut dire que **chaque coup porté au Chieftain lui rend de quoi frapper au sol**. Le joueur qui spamme la mêlée arme lui-même la réponse qui va le tuer. C'est un contre-jeu qui ne coûte aucune ligne d'IA et qui punit exactement le comportement qu'on veut décourager. À 5 % par coup, **vingt mêlées reçues remplissent la batterie entière** — mais treize suffisent à payer une frappe à 3,00 ART.

**Le coût de la Mêlée 2 à 7,50 % donne 13 frappes au sol par batterie pleine**, contre 10 pour le tir à 10 %. L'ancienne fiche annonçait 10 frappes à 5 %, ce qui était arithmétiquement faux *(100/5 = 20)* ; **l'incohérence est résolue** — il n'y a plus de nombre de frappes annoncé en dur, seulement des coûts, et les comptes tombent d'eux-mêmes. Plus rien à signaler sur ce point.

**Sur les 10 % du bouton de tir, laissés en question.** Je recommande de **les garder à 10 %**. Le rapport avec la Mêlée 2 est alors de 1,33 pour 1, ce qui est le bon écart : l'onde cinétique à distance de sécurité doit coûter sensiblement plus cher que la frappe qui exige d'être au contact. À coût égal *(7,50 %)*, personne n'aurait de raison d'aller au corps à corps ; en dessous, le marteau deviendrait une arme de zone à distance, ce qu'il n'est pas. **10 % maintient le contact comme option la moins chère**, et c'est la propriété à préserver.

**La recharge par le boost à 1 % pour 10 % consommé est volontairement maigre, et c'est cohérent.** Vider entièrement une jauge de boost rend **10 %** de batterie, soit une frappe au sol et un tiers. Le mouvement contribue, mais il ne nourrit pas l'arme — **c'est la mêlée qui la nourrit**, donnée ou reçue. Le message de design est net : ce marteau se recharge dans la mêlée, pas dans la course. Combiné au boost de marche 1,10 qu'il accorde désormais, cela donne une arme qui **se déplace vite pour aller au contact**, et qui ne gagne rien à se déplacer vite pour fuir.

**Le souffle anti-flammes reste le contre-jeu le plus fin de la faction** — il est depuis devenu la règle générale **§5.4**, à 5 armes. Les Brutes sont la faction du feu : Fusil à Plasma Brute, Ravageur, Grenade Incendiaire, Tourelle Spiker, tous allument. Et leur arme signature **éteint**. Un Chieftain qui frappe au sol annule les brûlures de ses propres alliés sur la cible : **la faction se marche dessus, délibérément**. Côté Yumiko, l'auto-extinction transforme le marteau ramassé en **outil de survie**, pas seulement en outil de dégâts.

---

### 3.6 — Ravageur

| Champ | Valeur |
|---|---|
| **Classe** | **Hybride Soutien / Lourd** |
| **Puissance** | **3 × 0,45 ART** *(salve = 1,35)* · **1,472 ART/s** |
| **Cadence** | 0,25 s + **0,667 s de recovery** · cycle **0,917 s** · **1,09 salve/s** |
| **Chargeur / Recharges** | **75** *(25 salves de 3)* · batterie unique |
| **Portée efficace** | **Variable** — arme versatile |
| **Véhicules** | **85 dégâts** |
| **Projectile guidé** | **×1,25** → **0,563 ART** — y compris après relâchement |
| **CAC** | **0,65 ART** |
| **Mise en joue** | **Aucune** |
| **Dual handling** | **Aucun** avec arme spéciale · maniement normal de type Soutien |

**Mode focus**

Pas de lunette : **direction manuelle des tirs**, léger suivi temps réel sur la cible dans le réticule. Sortir du focus rend aux projectiles une **physique légèrement tombante**. Les projectiles guidés sont **plus lents** — d'où le ×1,25 de compensation, qui s'applique **même après le relâchement**.

**Effets de feu**

| Point | Règle |
|---|---|
| Type de feu | **PLASMA INSTABLE** — barème **§5.1** : **0,16 ART/s** · flaque **4,50 s** · brûlure **2,50 s** |
| Ciblage | **4 tirs consécutifs sur deux salves** *(**66 %** de réussite nécessaire)* → **brûlure + flaque à ses pieds**, même s'il a bougé · **protégée ou non** |
| Mare de plasma | **2 salves complètes** au même endroit → mare **orange/rouge** |
| Sur zone | **1 seul tir** allume / entretient une **Zone Plasma en Zone Plasma Instable** |
| Pénétration | Brûlure **directement sur les PV** — **traverse le bouclier** *(exception Plasma Instable, §5.1)* |
| Entretien | Tout tir supplémentaire *reset* la flamme, au sol comme sur la cible |
| Critique | **Ne s'applique pas** à la brûlure |

**Notes**

**Le Ravageur est l'arme de contrôle de zone la plus complète de la sandbox, et le mode focus est la meilleure idée mécanique des douze fiches Brutes.**

Le principe : les projectiles guidés sont plus lents, donc plus faibles en vitesse d'arrivée, donc compensés à ×1,25. Et le multiplicateur **reste acquis après le relâchement du guidage**. La fiche en tire elle-même la conséquence, et elle est excellente : *cibler au dernier moment, à longue distance, après un tir en mortier* — on obtient à la fois la vitesse d'un projectile balistique et le bonus d'un projectile guidé. **C'est une technique de haut niveau qui émerge des règles au lieu d'être scriptée**, et c'est rare. Elle mérite d'être protégée telle quelle.

Le second usage — **frapper derrière un angle** en réorientant les projectiles au bon moment — donne à la faction Brute une réponse au jeu de couverture. Sur un socle Halo CE sans sprint, où la couverture est la ressource principale du joueur, **une arme qui contourne les angles est une arme qui invalide la ressource**. C'est très fort, et c'est correctement payé par la lenteur des projectiles guidés : le joueur voit venir, il a le temps de bouger, mais il doit *quitter* sa couverture pour le faire. Exactement le bon type de pression.

✅ **Les 0,18 ART/s × 5 s sont supprimés : ils n'existent pas dans la fiche.** La fiche Ravageur ne
donne **aucune statistique de feu** — elle s'arrête à la puissance, la cadence, le chargeur, le mode
focus et le critique. Par **§0.7**, la mare prend donc le **barème du type**, et le type est le Plasma
Instable : **0,16 ART/s · flaque 4,50 s · brûlure 2,50 s**. Les 0,18 / 5,00 s venaient d'une transcription
qui avait recopié le barème **Incendier** ; c'était une valeur orpheline.

| | Ancien *(orphelin)* | **Retenu** *(§5.1)* |
|---|---|---|
| Puissance | 0,18 ART/s | **0,16 ART/s** |
| Durée flaque | 5,00 s | **4,50 s** |
| **Total flaque** | 0,90 ART | **0,72 ART** |
| Brûlure | — | **2,50 s** *(0,40 ART)* |

**La correction règle l'anomalie sans affaiblir l'arme.** Le Ravageur perd **20 % de sa flaque** et cesse
d'être le feu le plus violent du jeu — ce titre revient à l'**Incendier** *(0,18)*, ce qui est cohérent :
une grenade incendiaire doit brûler plus fort qu'un tir de fusil. En échange le Ravageur garde ce que
personne d'autre n'a : **la traversée de bouclier**. Il échange de l'intensité contre de la pénétration,
et c'est exactement le prix annoncé par la doctrine §5.1.

**Reste le vrai chiffre de l'arme, qui n'a pas bougé : le rythme.** Deux salves suffisent pour poser la
mare, soit **1,834 s** au cycle réel de 0,917 s, sur **25 salves** de batterie. Le Ravageur peut donc
couvrir de zone en continu — c'est l'outil de refus de terrain le plus efficace du jeu, devant le Canon à
Combustible Élite, et il l'est par la **fréquence**, pas par la puissance.

**La clause de ciblage transforme un effet de zone en effet ciblé** : le joueur n'a pas besoin d'anticiper le déplacement, il lui suffit de toucher. Contre Yumiko, la mobilité HORNET **ne protège pas** de la mare — seule la précision du tireur compte. ✅ **Tranché : la séquence est la punition assumée, et rien ne la bride.** Le contre-jeu n'est pas d'esquiver la mare, c'est d'empêcher la séquence d'aboutir.

✅ **Le seuil est passé de 6 tirs consécutifs à 4 tirs au but sur 2 salves.** La fenêtre temporelle ne
bouge pas — 2 salves valent **1,834 s** au cycle de 0,917 s — mais le tireur a désormais droit à **deux
échecs sur six projectiles**. La séquence cesse d'être une exigence de perfection pour devenir un **taux
de réussite de 66 %**.

| | Avant | **Après** |
|---|---|---|
| Projectiles à placer | 6 / 6 | **4 / 6** |
| Marge d'erreur | **aucune** | **2 tirs** |
| Fenêtre | 1,834 s | 1,834 s |
| Cible | non protégée | **protégée ou non** |

⚠️ **C'est un assouplissement double, et il porte sur la seule arme déjà identifiée comme annulant
frontalement HORNET.** Ce que la mobilité pouvait encore faire contre l'ancienne clause, c'était **casser
la série** — un seul projectile esquivé remettait le compteur à zéro. Cette prise disparaît : il faut
maintenant esquiver **trois projectiles sur six** pour survivre à la séquence. La mare devient la
sanction par défaut d'un Ravageur qui vous tient dans son réticule deux secondes.

✅ **« Cible protégée ou non » cumule deux privilèges, et c'est ce qui isole le Ravageur.** La
doctrine §5.1 pose que **le feu ne passe pas les boucliers, sauf le Plasma Instable**. Le Ravageur est
du Plasma Instable **et** il allume sur cible protégée : il coche donc les deux cases là où les autres
n'en cochent qu'une, voire aucune.

| | Allume sur cible protégée ? | Passe le bouclier ? |
|---|---|---|
| **Ravageur** | **Oui** | **Oui** *(Plasma Instable)* |
| **Fusil à Plasma Brute** | Non — déclencheur « sans bouclier » | Oui *(Plasma Instable)* |
| Grenade Incendiaire, Canon à Combustible, Flash… | selon l'arme | **Non** |

**La conséquence est un renversement de l'ordre des phases, et il n'appartient qu'à lui.** Partout
ailleurs la sandbox impose *percer d'abord, brûler ensuite*. Le Ravageur **brûle pendant la première
phase** : sa mare travaille les PV pendant que le bouclier tient encore, donc les deux barres tombent
**en parallèle** au lieu de tomber l'une après l'autre. C'est ce qui en fait la vraie arme de pression
de la faction, plus encore que la mare elle-même — et c'est cohérent avec le fait qu'elle soit déjà
l'arme désignée comme annulant HORNET.

**La classe hybride est la plus restrictive du jeu** : maniement Soutien, **aucun** dual handling avec arme spéciale. Le Ravageur porte donc le **verrou d'interdiction de port** *(**D16**)*, comme le SRS99, le M319, le Lance-Flammes et le Fusil à Faisceau — **cinq armes au total**. Les deux autres armes concernées, MA5B et Répéteur à Plasma, portent l'autre verrou : la **pénalité de mobilité**.

| Verrou | Effet | Armes |
|---|---|---|
| **Interdiction de port** | Maniabilité **non pénalisée**, mais **aucune arme spéciale** — donc pas d'ambidextrie avec une arme de CAC spéciale | **SRS99C S2** *(§1.9)* · **M319 IGL** *(§1.12)* · **Lance-Flammes** *(§1.13)* · **Ravageur** *(§3.6)* · **Fusil à Faisceau** *(§3.7)* |
| **Pénalité de mobilité** | L'arme spéciale reste portable, mais le **duo ambidextre** coûte de la mobilité | **MA5B** *(§1.2)* · **Répéteur à Plasma** *(§2.4)* |

✅ **Liste arrêtée et promue en doctrine — `base-de-travail.md` §D16.** Sept armes, deux verrous, deux exceptions nommées *(Laser Spartan M6, Marteau Antigravité)*. Le Marteau **accorde** désormais le 1,10 : toute mention antérieure le rangeant parmi les armes qui le refusent est caduque.

La distinction est plus fine que la catégorie que je proposais, et elle est meilleure : un joueur privé de Lance Spartane et un joueur ralenti en la portant ne font pas le même arbitrage.

**✅ Cadence et DPS tranchés.** Le cycle est de 0,25 + 0,667 = **0,917 s**, soit **1,09 salve/s** ; à 1,35 ART par salve, le DPS est de **1,472 ART/s**. Les anciennes valeurs de 1,85 salve/s et 0,80 ART/s sont abandonnées.

**1,472 ART/s est un DPS élevé pour un Hybride Soutien/Lourd, et il est correctement payé.** Il place le Ravageur au-dessus de la Tourelle Plasma *(1,199)* et en dessous du Canon à Combustible Élite *(2,09)*, ce qui est le bon rang : plus dangereux que la tourelle fixe qu'on peut contourner, moins que l'arme lourde qui immobilise son porteur. La contrepartie est la **batterie unique de 25 salves** — à 1,09 salve/s, le Ravageur se vide en **23 secondes de tir continu**, et il n'a pas de recharge. **C'est une arme qui dépense vite un stock fini**, pas une arme d'attrition longue.

**Si 1,472 est jugé trop fort, c'est le recovery qu'il faut allonger, pas les dégâts.** La puissance de 0,45 par projectile est déjà indexée sur le ×1,25 du guidage et sur les 85 dégâts véhicule ; y toucher déplacerait trois chiffres au lieu d'un. Passer le recovery de 0,667 à 0,90 s donnerait un cycle de 1,15 s, **0,87 salve/s** et **1,174 ART/s** — sous la Tourelle Plasma. C'est le seul levier propre.

---

### 3.7 — Fusil à Faisceau

| Champ | Valeur |
|---|---|
| **Classe** | **Hybride Soutien / Lourd** — **même hybridation que le SRS99C S2** *(§1.9)* : maniabilité non pénalisée, **interdiction de porter une arme spéciale** |
| **Puissance** | **1,00 ART** · 3,33 ART/s théorique |
| **Cadence** | 0,30 s · **3,33 tirs/s** |
| **Chargeur / Recharges** | **100** de batterie · **32 tirs** *(3,125 % par tir)* |
| **Portée efficace** | Jusqu'à **150 m** |
| **Surchauffe** | **3 tirs consécutifs rapides** *(chauffe **40 %** par tir)* · refroidissement **6,50 s**, **aucune voie rapide** |
| **Critique** | **×1,50** → **1,50 ART** sur points faibles — **quelle que soit la charge** |
| **Critique sur ennemi brûlé** | **×1,75** → **1,75 ART** |
| **Perforation** | **Version allégée** — applique les dégâts restants après une protection, mais **ne tue pas nécessairement** au headshot |
| **Scaling armures** | **×0,50** → 0,50 ART |
| **Lunette** | ×3 et ×8 |
| **Surchauffe volontaire** | **Maintenir X** — consomme **5 tirs**, maintient l'état surchauffé **10 s** |

**Pattern de mêlée** *(Spartan ou Élite uniquement)*

| Coup | Effet |
|---|---|
| **Mêlée 1** | **Crochet** — arme tenue à une main par la poignée, frappe du châssis · **allonge supérieure** aux autres armes |
| **Mêlée 2** | **Estoc** *(start-up)* puis **uppercut du bec** — **stun**, fait reculer · envoie en l'air combiné aux mouvements Spartan ou entre les mains d'un Dévot |
| Parade | **Aucune** |

**Brûlure d'estoc** *(pendant la surchauffe)* — **alignée sur la matrice §5.1 / §5.2**

| Point | Valeur |
|---|---|
| Effet | L'estoc / uppercut inflige une **brûlure de type PLASMA** |
| Durée / Puissance | **2,50 s** · **0,16 ART/s** — **0,40 ART** au total *(statistiques de base du Plasma Instable, §5.1)* |
| Allumage — zone | Peut **allumer une Zone Plasma prête** *(délai absolu de 1,25 s, §5.2)* |
| Allumage — instable | Peut déclencher du **Plasma Instable** même **hors accumulation suffisante** — c'est la seule voie du roster qui court-circuite un décompte de tirs |
| Cumul | **AUCUN.** Une cible = **une seule brûlure active**. Un nouvel allumage **remplace** le foyer existant *(§5.0)* |
| Cautérisation | La brûlure **cautérise** — elle annule la plaie de saignement **et** son effet critique *(§5.6)* |

> ✅ **Point 30 clos.** L'ancienne ligne « les deux brûlures se cumulent et s'alimentent l'une l'autre »
> est **supprimée** : elle contredisait frontalement le non-cumul de la matrice. La valeur unitaire passe
> de 0,13 à **0,16 ART/s** et la durée de 2,5 à **2,50 s** pour rejoindre le barème Plasma Instable — la
> fiche ne porte plus de barème de feu qui lui soit propre.

**Notes**

**Le Fusil à Faisceau est l'arme la plus dangereuse du jeu contre Yumiko, et le calcul est court : deux headshots font 3,00 ART pour 2,50 de solidité, en 0,30 seconde.** Trois tirs au corps font également 3,00. La fenêtre de surchauffe à 3 tirs est donc exactement calibrée sur **une exécution complète** — le tireur a droit à un kill par cycle, pas plus. C'est une contrainte élégante : elle ne bride pas la létalité, elle bride le **volume**.

Le refroidissement de 6,50 s **sans aucune voie rapide** est la contrepartie, et c'est la bonne. Toutes les autres armes plasma de la sandbox ont une sortie de secours — *Recharger* pour le Fusil Brute (3,5 s), redescente progressive ailleurs. Le Faisceau, non : trois tirs et 6,5 s d'impuissance. **Le porteur doit être protégé pendant ce temps, ce qui en fait une unité d'escouade, pas un rôdeur solitaire.** À exploiter en composition d'escouade : un Faisceau seul est une cible, un Faisceau couvert est un problème.

**Le combo uppercut → tir aérien est la meilleure trouvaille offensive du roster ennemi.** Mêlée 2 stun et projette en l'air, puis tir à 1,00 ART sur une cible qui ne peut plus manœuvrer. Sur un jeu bâti sur des **sauts hauts et flottants** et une mobilité aérienne exigeante, envoyer le joueur en l'air est le pire endroit où le mettre — il y reste longtemps, et son contrôle y est le plus limité. La fiche note que c'est « absolument dévastateur » entre les mains d'un Dévot : je confirme, et je recommande d'en faire un **comportement rare et télégraphié**, réservé aux gradés. Si un troupier standard peut l'exécuter, la mobilité aérienne de Yumiko devient un piège plutôt qu'un outil, et c'est le cœur du système HORNET qui se retourne contre le joueur.

**La surchauffe volontaire est le détail qui fait passer la fiche de bonne à excellente.** Maintenir X pour surchauffer *délibérément*, au prix de 5 tirs, afin d'accéder pendant 10 s à un estoc incendiaire. **Le joueur transforme volontairement son sniper en arme de mêlée incendiaire.** C'est un choix coûteux (5 tirs sur 32, soit 15,6 % de batterie), réversible, et parfaitement lisible. Et la fiche va jusqu'au bout : synchroniser la frappe avec la *fin* de la surchauffe permet d'enchaîner brûlure puis tir critique **×1,75 sur ennemi brûlé** — l'arme s'auto-alimente son propre bonus.

**Ce ×1,75 mérite d'être vu comme la troisième entrée de la chaîne du Feu.** Le Focus Rifle Élite critique aussi à ×1,75 sur ennemi brûlé ; le Fusil à Faisceau fait de même, mais **il allume lui-même le feu**. Là où la chaîne Élite demandait trois armes et trois porteurs (Canon → Pistolet → Focus), le Faisceau la referme **à lui seul** : estoc surchauffé pour allumer, tir pour encaisser le ×1,75. Une arme, deux boutons, DPS majoré de 75 %. C'est plus fort que la chaîne Élite en autonomie, moins fort en portée — l'estoc oblige au contact, ce qui est absurde pour un sniper. **La tension est saine** : l'arme est meilleure quand son porteur prend le risque de mal se placer.

✅ **Le cumul des brûlures est clos, et la fiche est désormais alignée.** Une cible ne porte **jamais qu'un seul foyer** : allumer sur une cible déjà en feu **remplace** le précédent. Le pire cas n'est donc plus une addition mais **la plus forte des brûlures seule** — **0,18 ART/s en Incendier**, 0,16/s en Plasma Instable *(flaque de Ravageur comme estoc)*. Contre Yumiko à 2,50, il faut **13,9 s de feu pur** pour tuer : c'est une pression, pas une exécution.

**L'estoc surchauffé devient la voie de contournement des seuils d'accumulation, et c'est ce qui fait sa valeur.** Toutes les autres sources de Plasma Instable exigent un décompte — 16 tirs consécutifs au Fusil à Plasma Brute, 4 tirs au but sur 2 salves au Ravageur. **Le Fusil à Faisceau y arrive en un coup de mêlée**, au prix de 5 tirs de batterie et de 10 s passés en surchauffe volontaire. Le sniper qui veut allumer doit venir au contact et renoncer à tirer : le coût est payé en portée, ce qui est exactement le bon prix pour une arme à 150 m.

En contrepartie, la suppression de la dégressivité *(R3)* fait qu'un feu **entretenu ne faiblit jamais** : tant qu'un tireur le ravive, les 0,18 ART/s courent à pleine valeur. **Le paramètre critique n'est plus la puissance, c'est la cadence de réallumage** — c'est-à-dire le nombre de porteurs Brutes présents. Un seul suffit à maintenir le feu ; c'est donc au level design et à la composition d'escouade de doser, plus à la courbe.

**La perforation allégée est bien nommée.** Report des dégâts restants — conforme à §0.4 — mais sans la garantie de kill du SRS99. Le Faisceau frappe plus vite et plus souvent que le sniper humain ; il ne pouvait pas garder le PERFORATEUR complet. **La hiérarchie est propre** : SRS99 = un coup, une certitude ; Faisceau = trois coups, une probabilité.

---

### 3.8 — Déchiqueteur

| Champ | Valeur |
|---|---|
| **Classe** | Soutien |
| **Puissance — tir principal** | **1,25 ART** |
| **Puissance — shot antigrav** | **1,00 ART** |
| **Cadence** | **0,20 s** |
| **Chargeur / Recharges** | **2** / 10 · réserve **20** · **+ batterie** |
| **Portée efficace** | **0–12 m** |
| **Perforation** | **Oui** — bien que ce ne soit pas un sniper |
| **CAC** | **0,35 ART** — coup de crosse, **pas de pattern** · consomme la batterie |
| **Mise en joue** | Comme le M90 — réduit le spread, repousse le fall-off |

**Modes de tir**

Bascule **single / dual** en appuyant sur *Recharger* alors que les **deux cartouches sont chambrées**. En dual, les deux cartouches partent d'un coup : **2,50 ART**.

**Batterie du marteau intégré**

| Source | Taux |
|---|---|
| Capacité | **3 frappes** |
| Recharge passive | **1,5 % / s** — **interrompue hors combat** |
| Charge cinétique | **1 % / dash** *(si l'unité en dispose)* |

**Shot antigrav** — ✅ **point 28 tranché : c'est un coup de marteau antigrav, projeté**

| Point | Règle |
|---|---|
| Principe | **Par analogie stricte avec le Marteau Antigravité** *(§3.5)* — même nature d'onde, portée à distance |
| Puissance | **1,00 ART** |
| Déclenchement | **Bouton de tir**, marteau sorti — comme l'entrée « tir » du §3.5 |
| Coût | **Une frappe de batterie** *(1 sur 3)* — il consomme bien la batterie du marteau |
| Effet | **Projette** la cible · souffle cinétique à l'impact |
| Souffle | **Éteint tout feu**, au sol comme sur la cible, d'un seul coup *(§5.4)* |
| Portée | Dans les **0–12 m** de l'arme |

**Souffle** — même effet que le Marteau Antigravité contre les flammes.

> **Rappel (§0.9)** — l'explosion de cette arme **éteint un feu d'un seul coup**, au sol comme sur un ennemi.

**Notes**

**2,50 ART en un seul déclenchement : le tir dual du Déchiqueteur tue Yumiko exactement, à zéro près.** C'est la quatrième mort exacte relevée sur sa solidité totale, après le Railgun du Focus Rifle, la double Super-Combine du Needler et — de peu — le Grenadier chargé collé. Quatre coïncidences au centième sur trente fiches, ce n'est plus un hasard : **la sandbox converge naturellement vers « 2,50 = un engagement réussi »**, et cela confirme ce que je disais sur le bouclier à 100 % comme paramètre le plus sensible du projet.

Ici, cependant, la contrainte est bien meilleure que sur les trois autres. Le Railgun tue à portée infinie ; le Needler tue en 2 s à distance moyenne. Le Déchiqueteur tue **à 12 m maximum, avec les deux cartouches, sans marge d'erreur et sans possibilité de rater**. Après quoi il doit recharger. **Le coût du kill est le placement**, et c'est le seul type de contrainte que la mobilité HORNET peut réellement contester : Yumiko peut sortir de 12 m, elle ne peut pas sortir d'une ligne de vue à 150.

**La perforation sur un fusil à pompe est une décision inhabituelle et je pense qu'elle est bonne.** La fiche s'en amuse elle-même. Concrètement, le Déchiqueteur applique les dégâts restants après une protection — il ne « gaspille » donc jamais sa cartouche sur un bouclier presque vide. Contre Yumiko : la première cartouche vide le bouclier (1,00) et reporte **0,25 sur la chair** ; la seconde en enlève 1,25. Il reste 0,00. **L'arme tue en deux temps ce que le mode dual tue en un**, ce qui donne au joueur exactement une fenêtre — le temps de cadence de 0,20 s — pour être ailleurs. C'est court, mais c'est du jeu.

✅ **Le shot antigrav est tranché par analogie : c'est un coup de marteau antigrav, projeté à distance.** Il se déclenche au bouton de tir marteau sorti, consomme **une frappe sur les trois**, projette la cible et souffle les flammes comme n'importe quelle onde du §5.4. À 1,00 ART contre 2,25 pour le vrai marteau, **la dégradation est du même ordre que sur le reste de l'arme** : le Déchiqueteur porte un marteau de secours, pas un marteau.

**Ce que ça en fait, c'est l'outil de désengagement du porteur** — et c'est le bon rôle pour une arme de 0–12 m qui doit rester au contact pour être utile. Le Brute au corps à corps projette Yumiko, gagne sa distance de rechargement, et **éteint au passage le feu qu'elle vient de lui poser**. Trois usages pour une frappe de batterie : c'est cher payé quand la recharge passive tourne à 1,5 %/s, donc à **66,7 s le plein**. L'IA doit le traiter comme une ressource d'urgence, pas comme une entrée de combo.

⚠️ **Une conséquence à surveiller : la projection sur un joueur en l'air.** Yumiko projetée pendant un boost HORNET perd le contrôle de son vecteur au moment où elle en a le plus besoin. C'est le même risque que l'uppercut du Fusil à Faisceau, mais **sur une arme de troupier et non de gradé**. Si le shot antigrav envoie en l'air plutôt que de repousser au sol, il faudra le réserver aux gradés ; s'il **repousse horizontalement**, il n'y a pas de problème et c'est la lecture que je retiens par défaut — le nom dit *antigrav*, pas *uppercut*.

**Le marteau intégré est correctement dégradé par rapport au Marteau Antigravité.** Pas de pattern, coup de crosse à 0,35 (base standard, aucun bonus), 3 frappes de batterie, recharge à 1,5 %/s soit **66,7 s pour un plein**. C'est un marteau de secours, pas une arme de mêlée. **Bonne hiérarchie** : le Chieftain a l'arme, le troupier a l'accessoire. Mais il conserve **le souffle anti-flammes**, ce qui est le bon choix — c'est un effet de contre-jeu, pas de puissance, et le rendre exclusif au Chieftain le rendrait trop rare pour que le joueur l'apprenne.

**Le Déchiqueteur en classe Soutien face au Mauler en classe Légère est la comparaison à surveiller.** Les deux sont des shotguns Brutes. Le Déchiqueteur fait 2,50 ART à 12 m et taxe la mobilité ; le Mauler fait 1,00 ART à 5 m, ou **2,00 en dual**, et ne la taxe pas. Le risque « deux shotguns Brutes » signalé au registre éditorial est **résolu par la classe** plutôt que par les chiffres, et ça me semble le bon axe — mais c'est le duo qu'il faudra tester ensemble en premier.

---

### 3.9 — Grenade Incendiaire

| Champ | Valeur |
|---|---|
| **Classe** | Lancer |
| **Puissance** | **0,035 ART** par tick · **0,70 ART/s** |
| **Cadence** | 0,05 s · **20 ticks/s** |
| **Chargeur / Recharges** | Voir système *(`arcade-yumiko`)* |
| **Portée efficace** | **Rayon 3 m** |
| **Critique boucliers** | **×1,50** → 0,0525 par tick · **1,05 ART/s** |
| **Surface au sol** | Brûle **4,5 s** *(3,15 ART cumulés · **4,725** sur bouclier)* |
| **Rémanence** | Un ennemi touché brûle jusqu'à **1 s après avoir quitté la surface** |
| **Collage** | **Enflamme la cible** · **+1,00 ART** à l'impact — **annulé si la cible a un bouclier** |
| **Malus armures** | **×0,50** |
| **Malus blindages** | **×0,50** |
| **Flamme résiduelle sur cible** | **0,16 ART/s** pendant **2,5 s** *(0,40 ART)* |
| **Mise en joue** | Lancer direct, moins de cloche · garde la grenade en main *(risque)* · **délai : aucun** — la grenade la moins risquée |

**Entretien** — permet d'entretenir **n'importe quel type de flamme**. Peut être entretenue par un tir de **Canon à Combustible** ou de **Ravageur**, plus rarement par un **Grenadier**. Le **Fusil à Plasma Brute** l'entretient, notamment la flamme résiduelle sur cible.
**Flamme stable** — permet de mettre le feu aux **Flash**.

**Notes**

**C'est la réponse au déficit de contrôle de zone du CSNU que je signalais après les fiches Élites, et elle vient d'une faction ennemie — donc elle est ramassable.** Point important : le joueur qui ne dispose que d'armes humaines n'avait aucun moyen de contester le terrain face à sept sources de zone Covenant. La Grenade Incendiaire lui en donne une, et c'est une grenade, donc elle n'occupe pas d'emplacement d'arme. **Ce seul détail règle le problème de composition le plus sérieux relevé jusqu'ici.**

**Les chiffres sont plus violents qu'ils n'en ont l'air.** 0,70 ART/s pendant 4,5 s, c'est **3,15 ART** — davantage que Yumiko entière. Contre un bouclier, le critique ×1,50 monte à **1,05 ART/s**, soit **4,725 ART** sur la durée pleine. Évidemment personne ne reste 4,5 s dans une flaque de 3 m, mais l'ordre de grandeur dit ce qu'il faut comprendre : **la surface n'est pas un dégât, c'est une interdiction.** Deux secondes dedans coûtent 1,40 ART, soit plus que le bouclier de Yumiko. Le joueur ne traverse pas, il contourne — et sur un socle sans sprint, contourner coûte du temps d'exposition. C'est exactement le levier que le CSNU n'avait pas.

**Le collage à +1,00 ART annulé par le bouclier est une clause à double tranchant, et elle est bien pensée.** Contre une cible nue, la grenade fait 1,00 d'impact **plus** 0,40 de résiduelle **plus** la surface : c'est une exécution. Contre une cible protégée, elle ne fait que brûler. **La grenade récompense donc le second temps de l'engagement** — on tombe le bouclier, *puis* on colle. C'est le geste inverse de la Grenade Plasma Élite, qui colle à travers tout pour 2,25. Deux grenades adhésives, deux moments d'usage opposés : très bonne différenciation, et elle apprend au joueur à choisir son ordre d'actions.

**Le ×0,50 sur armures et blindages est la limite propre de l'arme.** Elle est excellente contre la chair et les boucliers, médiocre contre le métal. Combinée à un rayon de 3 m — le plus petit du jeu — elle reste une grenade anti-infanterie légère, jamais une réponse universelle. **C'est ce qui l'empêche de rendre les autres grenades obsolètes**, et c'est nécessaire, parce que le reste de la fiche est très généreux.

**La note sur les Flash est probablement l'information la plus importante de la fiche, et elle tient en une ligne.** « Flamme stable permettant de mettre le feu aux Flash. » Si les Flash sont bien ce que le nom suggère — une unité ou un consommable lumineux — alors la Grenade Incendiaire et la Tourelle Spiker sont les deux seules armes citées comme pouvant les allumer. **C'est une interaction nommée entre deux fiches distantes, donc voulue.** Il faudra la documenter ailleurs qu'en note de bas de fiche.

**Le délai de mise en joue à zéro fait de cette grenade la moins risquée du jeu**, ce qui est un contrepoint remarquable à la Grenade Plasma Élite (*cook* à 5,5 s, mise en joue inutilisable) et à la Grenade Dynamo (3 s). Trois grenades, trois profils de risque : **incendiaire = sûre et zonale · dynamo = moyenne et anti-bouclier · plasma = risquée et létale**. La grille est complète et lisible.

---

### 3.10 — Grenade Dynamo

| Champ | Valeur |
|---|---|
| **Classe** | Lancer |
| **Puissance** | **0,35 ART** |
| **Chargeur / Recharges** | Voir système *(`arcade-yumiko`)* |
| **Portée efficace** | **Rayon 2,50 m** |
| **Déclenchement** | **Explose dès l'impact au sol** — aucun délai |
| **Critique boucliers** | **×3** → **1,05 ART** |
| **IEM** | **Immobilise un véhicule** à la manière d'une charge à plasma |
| **Onde de choc** | **Souffle de 0,35 ART traité comme une attaque de mêlée** sur les cibles dans le rayon — donc **soumis à l'économie du saignement** *(§5.6)* |
| **Mise en joue** | Lancer direct, moins de cloche · garde la grenade en main *(risque)* · **délai : 3 s** |

**Allumage** — l'onde de choc peut **allumer des zones de plasma instable** *(plasma Brute)*.

> **Souffle (§0.9)** — l'explosion de cette arme **éteint un feu d'un seul coup**, au sol comme sur un ennemi.

**Notes**

**C'est le quatrième porteur anti-bouclier nommé par D9, et le plus simple des quatre.** Pas de charge, pas de chaîne, pas de fenêtre : elle explose au contact du sol et retire **1,05 ART** de bouclier dans un rayon de 2,50 m. Contre un groupe d'Élites Minor, c'est **tout le bouclier de chacun** en un jet. Contre Yumiko, c'est son bouclier entier plus 0,05 de perdu.

**L'explosion à l'impact sans délai est la caractéristique qui définit l'arme**, et elle est plus conséquente que le chiffre de dégâts. Aucune grenade de la sandbox ne fait ça : la Grenade Frag roule, la Plasma colle et attend, l'Incendiaire dépose une surface. La Dynamo est **instantanée et donc impossible à esquiver après le lancer** — le seul contre-jeu est de ne pas être là au moment du jet, ce qui, sur un socle sans sprint, veut dire anticiper le geste du lanceur. **C'est une grenade de punition de position statique**, exactement complémentaire de l'Incendiaire qui, elle, punit le *maintien* de position.

**Le ×3 contre les boucliers pour 0,35 de base est un très bon rapport, et il est bien borné.** L'onde de choc fait 0,35 sur tout le reste — la valeur d'un coup de mêlée standard, littéralement rien contre une unité en chair. La grenade est donc **inutilisable comme finisseur** : elle décape et ne tue pas. Ça la range clairement comme outil d'ouverture d'escouade, à jeter *avant* l'engagement, ce qui est cohérent avec un ennemi Brute qui charge derrière.

**L'interaction avec le Fusil Électrique survit au rework, et elle a changé de sens.** La V1 relançait l'onde Dynamo quand une protection tombait sous les coups consécutifs. La V2 fait l'inverse : c'est le **4ᵉ tir de Charge Dynamo sur une cible SANS protection** qui déclenche une explosion de grenade complète — onde **0,35** plus **IEM 1,05** sur les boucliers voisins *(§3.4)*. Et la Grenade Dynamo entre à son tour dans la boucle : elle **réactive l'explosion sur les ennemis marqués**. Les deux objets s'appellent désormais dans les deux sens. Deux armes, deux fiches séparées, une combinaison qui n'est écrite nulle part comme un combo. C'est précisément le genre de chose qu'il faut donner à l'IA d'escouade — un Brute qui jette, un Brute qui acharne — et je recommande d'en faire un archétype nommé au même titre que la chaîne du Feu Élite.

**L'allumage des zones de plasma instable referme la boucle avec la faction.** La Dynamo n'allume pas de feu par elle-même ; elle **détone** le plasma Brute déjà présent au sol — flaque du Fusil à Plasma Brute, mare du Ravageur. Une grenade qui ne fait rien seule mais qui transforme le travail des autres : c'est de la coopération d'escouade transformée en mécanique, comme la relance de flamme du Pistolet à Plasma côté Élite. **Chaque faction a maintenant son geste d'entraide chiffré.**

**Le délai de mise en joue de 3 s la place au milieu de la grille de risque** — plus sûre que la Grenade Plasma (5,5 s), plus risquée que l'Incendiaire (aucun délai). Cohérent avec une grenade qui explose de toute façon à l'impact : la garder en main n'apporte qu'un meilleur angle, jamais un meilleur timing.

---

### 3.11 — Tourelle Spiker

| Champ | Valeur |
|---|---|
| **Classe** | **Lourd FIXE** |
| **Puissance** | **0,105 ART** · **0,945 ART/s** |
| **Cadence** | 0,111 s · **9 tirs/s** |
| **Chargeur / Recharges** | **180** · recharge **au râtelier** *(20 s de tir continu)* |
| **Portée efficace** | **Variable** |
| **Vitesse de projectile** | **30 m/s** — projectiles **linéaires mais lents** |
| **Mise en joue** | **Aucune** |
| **CAC** | **0,80 ART** *(**§5.6** fait foi)* · saignement **×1,50 à travers l'armure** → **0,075 ART/s** · **lancer de tourelle 1,05 ART** *(3,50 s)* |

**Saignement**

| Point | Valeur |
|---|---|
| Déclencheur | Coup de mêlée de la Tourelle Spiker |
| Cible | **Dégâts directs sur la barre de vie** — ni bouclier, ni armure |
| Durée | **2,50 s** *(durée générique, **§5.6**)* |
| Puissance | **0,075 ART/s** — générique 0,05 **×1,50** *(0,188 ART au total)* |
| Lancer de tourelle | **1,05 ART** · saignement **0,05 ART/s × 3,50 s** *(0,175 ART)* |

**Incinération**

| Point | Valeur |
|---|---|
| Déclencheur | **5 piques** de spiker lourd sur une cible |
| Effet | **Met le feu** — **2,5 s** · **0,15 ART/s** *(0,375 ART)* |
| Compatibilité | Entretient les **feux Forerunner** et les **feux Brutes** |
| Flash | Peut **mettre le feu aux Flash lumineux** |

**Portage** — pour les Grognards à arme lourde *(artilleurs, diacres, ultras)*, peut remplacer la **Tourelle Plasma** comme arme de « l'artilleur » **en cas de commandement Brute**.

**Notes**

**Le Saignement est la seule source de dégâts directs sur la barre de vie du roster Brute, et il arrive par la mêlée d'une arme fixe.** 0,075 ART/s sur 2,50 s = **0,188 ART** qui ignorent bouclier et armure. Rapporté au coup lui-même — **base 0,80**, la plus haute mêlée d'arme du roster Brute — la frappe complète vaut **0,988 ART** contre une cible protégée, dont **19 %** passent à travers tout. La part qui traverse est plus faible qu'on ne le croyait, mais **le coup de base est bien plus lourd** : à 0,80 ART, la mêlée de Tourelle Spiker vaut à elle seule plus du tiers de Yumiko, infligée de face par un troupier qui tient une arme fixe.

Deux conséquences. D'abord, **la Tourelle Spiker cesse d'être une arme de zone pure** : arrachée, elle a une réponse au corps à corps, ce que la Tourelle Plasma n'a pas *(son Estoc à 1,333 est plus fort mais coûte 35 tirs de batterie ; le Saignement est gratuit)*. Ensuite, ça donne aux **Grognards artilleurs sous commandement Brute** une raison de ne pas fuir quand Yumiko arrive au contact — ils ont un coup qui compte. C'est exactement le genre de détail qui rend une escouade lisible comme une escouade et pas comme un décor.

✅ **Le cumul est tranché : pas d'addition, une ré-application** *(règle générale, §5.6)*. Une cible ne porte **qu'une seule plaie active** ; une seconde frappe **remet la plaie à sa durée pleine** au lieu d'empiler. Trois frappes de Tourelle Spiker valent donc **0,188 ART**, pas 0,564. **Le gain n'est pas dans les dégâts, il est dans la fenêtre** : chaque frappe relance les **12,50 s** de vulnérabilité tranchant → cinétique, et maintient la cible dans l'état où le coup dorsal devient létal.

**La Tourelle Spiker est le pendant Brute de la Tourelle Plasma Élite, et la comparaison montre deux doctrines entièrement différentes.**

| | Tourelle Plasma *(Élite)* | **Tourelle Spiker** *(Brute)* |
|---|---|---|
| ART/tir | 0,109 | 0,105 |
| Cadence | — | **9 tirs/s** |
| ART/s | 1,199 | **0,945** |
| Anti-bouclier | **×1,25** → 1,499 ART/s | **Aucun** |
| Malus chair | **×0,50** | **Aucun** |
| Effet | — | **Incinération** |
| Réserve | 250 | **180** |

**Les deux tourelles frappent presque exactement au même dégât par tir** (0,109 vs 0,105) et divergent complètement sur tout le reste. L'Élite est une arme de **décapage** : le meilleur DPS anti-bouclier du jeu, mais deux fois moins efficace sur la chair. La Brute est une arme **régulière** : aucun bonus, aucun malus, 0,945 ART/s sur tout ce qui passe, plus une brûlure. **Contre un Spartan bouclier plein, l'Élite gagne largement ; contre une escouade de Marines non protégés, la Brute fait plus du double.** C'est une différenciation exemplaire, obtenue sans toucher aux dégâts de base.

**Le time travel de 30 m/s est le vrai paramètre d'équilibrage, et il est sévère.** À 30 mètres de distance, le projectile met **une seconde entière** à arriver. Contre Yumiko en mouvement — dash, wallrun, boost Hornet — la tourelle est presque incapable de toucher à moyenne portée. **La lenteur des projectiles est ce qui rend cette arme jouable contre la mobilité HORNET**, et c'est pour la même raison qu'elle sera redoutable contre un joueur immobilisé, en train de recharger ou coincé dans une flaque. **Elle punit l'arrêt, pas le déplacement** — ce qui est le rôle exact qu'on veut d'une arme fixe.

**L'incinération à 5 piques arrive vite : 0,556 s de tir soutenu.** Ce n'est pas un seuil, c'est une formalité. Toute cible touchée sérieusement brûle. Les 0,375 ART cumulés sont modestes, mais **l'incinération sert surtout de porte d'entrée dans les chaînes de feu** : elle entretient les feux Brutes **et Forerunner**, ce qui en fait le premier lien mentionné entre ces deux factions. La Tourelle Spiker devient donc l'**allumeur générique** de la sandbox — l'arme qui met en route ce que les autres exploitent.

**La réserve de 180 et la recharge au râtelier posent une contrainte spatiale plutôt que temporelle** : 20 secondes de tir continu, puis il faut retourner au râtelier. Sur une arme Lourd FIXE, cela veut dire que **le point de tir a une durée de vie**, et que le level design peut décider combien de temps une position tient en plaçant — ou non — un râtelier à côté. C'est un levier de conception de niveau plus fin qu'un simple compteur de munitions.

---

## 4. Forerunner / Sentinelles

> 5 entrées. Les valeurs proviennent de la fiche d'équilibrage de l'auteur.
> Les lignes marquées ⚠️ signalent un **écart arithmétique** relevé à la transcription — voir `## 6. Matrice consolidée`.

---

### 4.1 — Sentinel Beam

| Champ | Valeur |
|---|---|
| **Classe** | Principale |
| **Puissance** | **0,022 ART** par tir · **0,66 ART/s** |
| **Cadence** | 0,033 s · **30 tirs/s** |
| **Chargeur / Recharges** | **100** · batterie |
| **Portée efficace** | **20 m** — *le rayon se dissipe au-delà* |
| **Consommation** | **0,25 % par tir** → **7,50 %/s** *(30 t/s)* — **fixé** |
| **Critique — armures et blindages destructibles** | **×1,35** → **0,89 ART/s** |
| **Boucliers de type lumière** | **RECHARGE** au lieu de détruire |
| **Mise en joue** | Vise précisément les points faibles — *un bon joueur peut s'en passer* |

**Incendie** — *fixé*

| Point | Règle |
|---|---|
| Déclencheur | **12,50 % de batterie** dépensés sur la cible — soit **50 tirs**, **1,67 s** de rayon continu |
| Effet | **Brûlure de type LUMIÈRE** — **0,11 ART/s × 5,00 s = 0,550 ART** *(§5.1)* |
| Coût | **Un huitième de batterie par allumage** → **8 allumages** sur une batterie pleine |
| Flash | Met le feu à **tous les ennemis** en faisant exploser les **Flash lumineux** |

**Notes**

**Le Sentinel Beam est le rayon continu que la sandbox n'avait pas, et sa singularité n'est pas dans ses dégâts — elle est dans le fait qu'il soigne.**

« RECHARGE au lieu de détruire » — sur les **boucliers énergétiques non conventionnels** de certains ennemis de fin de jeu — est la ligne la plus lourde de conséquences de toute la faction. **Aucune arme des quarante précédentes n'a d'effet inverse selon la cible.** Concrètement : le joueur qui ramasse un Sentinel Beam et tire sur une Sentinelle à bouclier de lumière **la répare**. Ce n'est pas une résistance, ni une immunité, c'est un retournement complet du sens de l'arme. Trois conséquences :

1. **Le Sentinel Beam est la seule arme du jeu que le joueur peut utiliser contre lui-même**, au sens tactique. C'est un excellent piège pédagogique — le joueur l'apprend en une fois et ne l'oublie jamais.
2. **La faction Forerunner a un contre-jeu intégré à sa propre arme signature.** Contre une escouade de Sentinelles, le Beam ramassé est inutile ; contre les Brutes ou le Covenant, il est excellent. **L'arme change de valeur selon l'ennemi, pas selon la situation** — c'est un axe d'équilibrage neuf dans ce projet.
3. Cela implique qu'il existe des **boucliers énergétiques non conventionnels**, portés par **certains ennemis de fin de jeu**. **C'est voulu, et c'est hors périmètre pour le moment** — la matrice de solidité ne les portera qu'au moment où ces unités seront traitées. **Ne pas chercher à typer « lumière » les protections existantes.**

**Sur les chiffres bruts, l'arme est modeste et c'est correct.** 0,66 ART/s la place sous le Fusil à Plasma Brute (0,750) et loin du Répéteur (0,912). Le critique à ×1,35 ne s'applique **ni aux boucliers ni à la chair** — uniquement aux armures et blindages destructibles. C'est le profil inverse de tout ce qu'on a vu jusqu'ici : **la première arme anti-armure spécialisée de la sandbox**, là où les quarante autres étaient anti-bouclier ou généralistes. Contre un Grenadier ou un Chieftain blindé, 0,89 ART/s en continu et sans recul est très confortable.

**Le rayon continu à 30 tirs/s est un choix de feeling avant d'être un choix de chiffres.** Trente impacts par seconde, ce n'est pas une cadence, c'est un flux — et à 0,022 ART l'unité, chaque impact est négligeable. **L'arme ne récompense pas le timing, elle récompense la tenue de ligne.** Sur un socle sans sprint, où la couverture est la ressource du joueur, une arme qui exige de rester exposé plusieurs secondes d'affilée est une arme risquée. Elle est donc bien payée. Et elle contraste proprement avec la doctrine Brute des pics courts : **les Forerunner demandent la durée là où les Brutes demandent la fenêtre.**

**L'incendie à travers les blindages est la deuxième singularité.** 2,5 s de tir soutenu sur une cible nue, puis 0,10 ART sur 4 s. Le dégât est dérisoire — c'est le plus faible feu de la sandbox, loin derrière la Grenade Incendiaire (0,70 ART/s) ou la mare du Ravageur (0,16 ART/s). **Sa valeur n'est pas dans le chiffre, elle est dans le mot « à travers ».** C'est le seul dégât sur la durée qui ignore le blindage, ce qui en fait un outil de finition contre les cibles lourdes plutôt qu'un outil de dégât.

**✅ Consommation et incendie fixés — l'arme tient debout.** À 0,25 %/tir, la batterie donne **13,33 s de rayon continu**, soit **400 tirs** et **8,80 ART délivrables**. C'est le bon ordre de grandeur pour une Principale d'attrition : deux fois ce que l'hypothèse haute écartée aurait laissé, et assez pour tenir une ligne sans que l'arme devienne une réserve infinie.

**Le passage au type LUMIÈRE règle l'ambiguïté et améliore l'arme.** L'ancienne formulation « 0,10 ART / 4 s » pouvait se lire 0,025 ART/s — sept fois sous le plus faible feu du jeu. La brûlure Lumière vaut **0,550 ART**, ce qui la place **au-dessus de tous les autres résiduels** de la matrice *(Incendier 0,540 · Zone Plasma 0,455 · Plasma Instable 0,400 · Combustible 0,350)*. Le feu le plus faible en intensité est donc le plus rentable en total, parce qu'il est le plus long — et c'est cohérent avec une arme qui demande de la tenue de ligne plutôt que du timing.

**Le vrai prix de l'allumage est en batterie, et il est bien dosé.** 12,50 % par incendie, c'est **huit allumages maximum** par batterie pleine — mais chaque allumage consomme aussi **1,10 ART de tir direct** *(50 tirs à 0,022)* pour rendre **0,550 ART** de brûlure. **Le feu du Beam n'est jamais rentable en dégâts bruts** : il ne se justifie que contre une cible qu'on ne peut pas achever au rayon, ou pour déclencher les Flash. C'est exactement le bon calibrage pour un effet secondaire.

---

### 4.2 — Heatwave

| Champ | Valeur |
|---|---|
| **Classe** | Principale |
| **Puissance** | **0,88 ART** par tir *(8 unités × **0,11**)* · **1,76 ART/s** |
| **Cadence** | 0,50 s · **2 tirs/s** |
| **Chargeur / Recharges** | 8 / 4 · réserve **32** |
| **Portée efficace** | **Variable selon le mode** — **Vertical 5 à 25 m** *(viser devient difficile au-delà)* · **Horizontal 3 à 10 m** *(au-delà, la ligne de 8 unités s'étale et les dégâts deviennent risibles)* |
| **Munition** | 8 unités de **lumière solide / brûlante** |
| **Critique — headshot** *(horizontal)* | **×2,5** → **0,275** par unité |
| **Véhicules** | **15 dégâts** par unité *(120 par tir plein)* |
| **Changement de mode** | **Bouton Mêlée 2** |
| **Mise en joue** | Resserre le tir — unités moins espacées, dégâts concentrés · **grossissement ×3** |

**Modes de tir**

| Mode | Répartition | Usage |
|---|---|---|
| **Horizontal** | 8 unités sur **une ligne** | Balayage · **critique headshot ×2,5** |
| **Vertical** | 8 unités en **rectangle concentré** | Tir à distance *(anticipation ou burst précis)* · **forte cinétique / concussion** |

**Vertical — détonation** : si les 8 tirs touchent le même ennemi, **détonation infligeant des dégâts de zone** — propage les **0,88 ART** aux ennemis proches.

**Incendie**

| Point | Règle |
|---|---|
| Déclencheur | **3 tirs cumulés** sur une cible — *moyenne de 16 unités sur 3 salves consécutives* |
| Effet | **0,21 ART/s** pendant **3,5 s** *(0,735 ART)* |
| Entretien | Entretient **n'importe quel feu** plasma ou classique · peut **être entretenu** par des tirs de plasma *(reset du cooldown de 3,5 s)* |
| Flash | Peut mettre le feu aux **Flash** |

**Notes**

**Le Heatwave est le shotgun le plus intelligent de la sandbox, et le seul dont le joueur choisit la forme du tir.** Deux modes accessibles par un bouton déjà présent (Mêlée 2), sans menu, sans temps de bascule annoncé : **c'est de la profondeur gratuite en termes d'interface.**

**Le rapport entre les deux modes est bien construit parce qu'ils ne partagent pas le même barème.** L'horizontal est le mode de précision : critique ×2,5 au headshot, 0,275 par unité. Le vertical est le mode de puissance : pas de critique mentionné, mais une **détonation de zone à 0,88 ART** si les huit unités touchent. Le joueur ne choisit pas entre « fort » et « faible », il choisit entre **viser la tête d'un** et **arroser un groupe**. C'est exactement la bonne forme de choix — celle qui dépend de la situation, pas de la maîtrise.

**Le chiffre à connaître : huit unités toutes en critique font 2,20 ART.** C'est 88 % de Yumiko en une pression de gâchette, à 0,50 s de cadence. Ce n'est pas atteignable en pratique — huit unités réparties sur une ligne ne peuvent pas toutes toucher une tête — mais l'ordre de grandeur dit que **le mode horizontal à bout portant est très proche d'un one-shot.** Avec la mise en joue qui resserre le tir, la proportion d'unités au but monte. **À tester en priorité** : le Heatwave en joue à courte distance est probablement l'arme la plus forte du roster Forerunner.

**Le seuil d'incendie est le détail que je trouve le mieux calibré de la fiche.** 16 unités sur 3 tirs, alors que 3 tirs en délivrent 24 : **le seuil est à 66,7 % de précision.** Ce n'est pas un compteur de tirs, c'est un **compteur de justesse**. Un joueur qui arrose n'allume pas ; un joueur qui place ses gerbes allume. Sur une arme à dispersion, c'est la façon la plus élégante de récompenser la précision sans imposer de headshot. Je n'ai vu ce mécanisme nulle part ailleurs dans les quarante fiches précédentes, et je recommande de le garder tel quel.

**L'incendie du Heatwave est aussi le meilleur pont entre factions.** Il entretient « n'importe quel feu plasma ou classique » **et** peut être entretenu par des tirs de plasma. Traduction : une escouade mixte Brute + Forerunner maintient un feu indéfiniment, chacune rechargeant le cooldown de l'autre. **La ressource-feu identifiée chez les Brutes devient inter-factions**, ce qui donne une raison mécanique — et pas seulement narrative — de faire combattre les deux ensemble. C'est un bon argument de composition d'escouade.

**La réserve est le vrai frein, et il est sévère.** 8 dans le chargeur, 32 en réserve, soit **40 tirs au total** pour 35,2 ART délivrables. C'est confortable dans l'absolu, mais l'arme consomme **3 tirs par incendie** et 8 unités par tir : un joueur qui joue le Heatwave pour ses effets vide sa réserve très vite. **Le budget de munitions est ici le levier d'équilibrage**, exactement comme sur les cinq armes CSNU les plus fortes. Cohérence appréciable entre factions.

**✅ Portée fixée, et c'est le mode qui la porte — le seul cas du roster.** Aucune autre arme des 44 n'a **deux portées efficaces selon la forme de son tir**. Le changement de mode au bouton Mêlée 2 ne choisit donc pas seulement une répartition de gerbe : **il déplace l'arme sur l'axe des distances**, ce qui double la valeur d'un bouton déjà présent.

| Mode | Portée | Place dans la sandbox |
|---|---|---|
| **Horizontal** | **3 – 10 m** | Entre le **Mauler** *(2–5 m)* et le **Déchiqueteur** *(12 m)* — le vrai fusil à pompe |
| **Vertical** | **5 – 25 m** | Chevauche le **M90** et mord sur la portée moyenne — un **fusil de désignation** |

**La justification de la borne horizontale est mécanique, pas arbitraire, et c'est ce qui la rend juste.** Les 8 unités s'écartent avec la distance : au-delà de 10 m, la ligne est si étalée qu'une cible n'en reçoit plus qu'une ou deux, soit **0,11 à 0,22 ART**. L'arme ne devient pas « moins bonne », elle devient **inutile** — la décroissance n'est pas une pénalité posée à la main, elle sort de la géométrie de la gerbe.

**Le mode vertical à 25 m est la portée qui compte pour l'équilibrage, et elle est généreuse.** À 1,76 ART/s avec une détonation de zone à 0,88, une arme qui tient 25 m concurrence directement les armes de portée moyenne. **Ce qui la borne n'est pas le dégât, c'est la visée** — « il devient difficile de viser au-delà », donc le plafond est une contrainte de joueur, pas un mur de dégâts. C'est la bonne façon de limiter une arme sans la casser : elle reste théoriquement dangereuse à 30 m, mais plus personne ne touche.

**Conséquence sur le point ouvert n° 35 : il est clos, et la comparaison avec le Mauler tombe.** Les deux armes ne se disputent que la bande **3–5 m**. Au-delà, le Mauler n'existe plus et le Heatwave a encore 20 m devant lui. **Aucun doublon de case** — le Mauler reste le pic de dégât au contact *(1,00 ART, ×1,35 armures)*, le Heatwave couvre tout le reste.

---

### 4.3 — Cindershot / Crémator

| Champ | Valeur |
|---|---|
| **Classe** | Soutien |
| **Puissance — impact** | **0,50 ART** · 0,66 ART/s ⚠️ *(0,6665)* |
| **Puissance — cluster** | **3 × 0,167 ART** *(0,501)* · 0,223 ART/s par point |
| **Puissance — total** | **1,001 ART** par tir · **1,334 ART/s** |
| **Cadence** | 0,75 s · **1,33 tir/s** |
| **Chargeur / Recharges** | 5 / 4 · réserve **20** |
| **Portée efficace** | **8–20 m** |
| **Véhicules** | **80** *(+ 3 × 15)* = **125** |
| **Mise en joue** | **Existe mais n'améliore rien** — présente pour l'immersion, la forme de l'arme la rendant plausible |

**Explosion en deux temps**

| Temps | Effet |
|---|---|
| **1 — Impact** | **Incendiaire** — inflige **Brûlure** : **0,15 ART/s pendant 2,50 s** *(0,375 ART)* · **pas de lumière solide en soi**, mais **allume quand même la Flash** |
| **2 — Cluster** | **3 petits points explosifs** avec **guidage** |

**Technique** : tirer **à côté** du couvert ennemi pour que le cluster fasse effet **directement derrière**.

**Notes**

**Le Cindershot est la deuxième arme du jeu qui contourne les angles, après le Ravageur, et les deux le font différemment.** Le Ravageur demande au tireur de piloter ses projectiles au bon moment — c'est une compétence active, coûteuse en attention. Le Cindershot demande seulement de **tirer à côté** : les trois points du cluster se guident seuls derrière le couvert. **L'un récompense l'habileté, l'autre récompense la lecture du terrain.**

Sur un socle Halo CE sans sprint, où la couverture est la ressource principale du joueur, **avoir deux armes ennemies qui l'invalident est une décision de design lourde.** Je ne pense pas que ce soit un problème — c'est même sans doute nécessaire, sinon le joueur se plante derrière un mur et le combat s'arrête. Mais il faut que ce soit **visible et lisible** : le Cindershot doit avoir un son et une traînée qui annoncent le contournement, sinon le joueur mourra derrière sa couverture sans comprendre. C'est un point de retour visuel, pas d'équilibrage.

**Le découpage impact / cluster est bien pensé, et l'impact est désormais un vrai allumeur.** *(Paragraphe révisé : la fiche portait initialement « incendiaire sans dégât ».)* L'impact inflige **0,15 ART/s pendant 2,50 s**, soit **0,375 ART** de brûlure, et il **allume la Flash sans être une munition de lumière solide** — ce qui en fait le cas d'école de la règle R7 : *c'est la fiche qui autorise le déclenchement, pas la nature du projectile*.

Ce que ça change au bilan de l'arme : **1,001 ART de tir + 0,375 de brûlure = 1,376 ART par projectile**, +37 % sur ma lecture précédente. Le Cindershot passe devant le M319 (1,25) au coup par coup, avec cinq coups au chargeur contre un. **Un chargeur plein vaut donc 6,88 ART**, soit près de trois Yumiko. La réserve de 20 tirs reste le seul frein, et je considère qu'elle est maintenant le paramètre à surveiller en priorité sur cette fiche.

Contrepartie de design : la faction Forerunner passe à **quatre armes sur quatre capables d'agir sur le feu**, et le Cindershot devient le partenaire naturel du Flash — un joueur ou une Sentinelle pose la grenade, le Crémator la détonne à distance de sécurité. C'est une combinaison à deux boutons que je recommande d'enseigner explicitement dans un niveau, parce qu'elle est la meilleure démonstration de R7.

**Le vrai profil de l'arme est celui d'un M319 Forerunner, et la comparaison est éclairante :**

| | M319 *(CSNU)* | **Cindershot** |
|---|---|---|
| Par tir | **1,25 ART** | **1,001 ART** |
| Chargeur | **1** | **5** |
| Contournement | — *(rebond manuel)* | **Guidage automatique** |
| Modes | IEM, adhésif | — |

Le M319 est une arme de décision : un coup, une conséquence. Le Cindershot est une arme de **pression continue** : cinq coups presque aussi forts, à 1,33 tir/s, soit **5,005 ART par chargeur**. C'est le double de Yumiko. **Un chargeur entier de Cindershot bien placé tue deux Spartans.** La contrainte est la réserve — 20 tirs seulement, soit 20 ART au total — et la portée minimale de 8 m qui interdit la défense rapprochée.

**La mise en joue qui n'améliore rien est un détail que je veux souligner comme un bon choix.** La fiche l'assume : elle existe « pour le côté immersif car vu sa forme c'est possible ». **Toutes les armes n'ont pas besoin d'avoir un intérêt mécanique sur tous leurs boutons.** Un joueur qui monte l'arme à l'épaule par réflexe ne doit pas être puni, mais il n'a pas non plus à être récompensé. C'est de la cohérence de fiction, et c'est gratuit.

⚠️ 0,50 × 1,333 = **0,6665** et non 0,66. Arrondi sans conséquence. À noter que la cadence exacte de 1,33 tir/s correspond à 0,7519 s et non 0,75 — l'écart est de 2 millisecondes, ignorable.

---

### 4.4 — Flash

| Champ | Valeur |
|---|---|
| **Classe** | Grenades |
| **Puissance** | **0,00 ART** — *la grenade elle-même ne blesse pas* |
| **Cadence** | Arme de lancer |
| **Chargeur / Recharges** | Voir système de grenades |
| **Portée efficace** | Selon la physique de lancer |
| **Aveuglement** | Ennemis, **alliés et lanceur** — champ d'action étendu · **s'éloigner de l'épicentre réduit l'effet** |

**Détonation par tir de lumière solide**

| Point | Valeur |
|---|---|
| Déclencheur | **Tirer une munition de lumière solide** dans le Flash — *ou toute arme dont la fiche le mentionne* |
| Explosion | **0,45 ART** — met le feu à la zone |
| Brûlure | **Type LUMIÈRE** — **0,11 ART/s × 5,00 s = 0,550 ART** *(§5.1)* |
| Cible | **Directement sur les PV**, même protégée — **sauf bouclier** |
| Critique boucliers *(explosion)* | **×3** → **1,35 ART** — **fixé** |

> **D'autres armes peuvent allumer l'explosion Flash — voir les fiches individuelles qui le précisent.**
> Le déclenchement n'est donc **pas réservé aux munitions de lumière solide** ni à la faction
> Forerunner : une arme non-Forerunner l'allume dès lors que **sa propre fiche le mentionne**
> *(ex. Grenade Incendiaire, Tourelle Spiker, **Crémator**)*.

**Notes**

**Le Flash est la première arme de la sandbox à faire zéro dégât, et c'est la fiche la plus importante de la faction — parce qu'elle explique enfin les huit références semées dans les quarante précédentes.**

Depuis les fiches Brutes, quatre armes étaient créditées de « peut mettre le feu aux Flash » sans qu'on sache ce qu'était un Flash : Grenade Incendiaire, Tourelle Spiker, Sentinel Beam, Heatwave. **La réponse est qu'il s'agit d'une grenade aveuglante qui devient une bombe incendiaire si on lui tire dessus.** C'est une mécanique en deux temps répartie sur **deux armes différentes et potentiellement deux porteurs différents.**

**C'est la plus belle idée de coopération d'escouade du projet, et elle dépasse tout ce que font les autres factions.** Le Covenant avait sa chaîne du Feu (trois armes, trois porteurs) ; les Brutes ont le duo Dynamo + Fusil Électrique. Ici, **un Forerunner jette, un autre tire, et la zone brûle.** La différence est que l'objet intermédiaire — le Flash — est **visible, statique et neutre** : le joueur le voit, comprend qu'il peut le déclencher, et peut le faire **lui-même**. C'est de la mécanique émergente lisible, ce qui est rare.

**Et le retournement est complet : le joueur peut faire exploser les Flash ennemis.** Cinq armes le permettent, dont trois non-Forerunner. Un Flash lancé par une Sentinelle devient une bombe pour son propre camp si Yumiko tire dessus avec une Grenade Incendiaire Brute ou une Tourelle Spiker. **C'est le premier objet du jeu qui appartient à celui qui réagit le plus vite**, et je considère que c'est le meilleur candidat pour un moment de gameplay signature.

**L'aveuglement qui affecte le lanceur et ses alliés est la clause qui rend l'arme honnête.** Aucune des armes précédentes ne se retourne contre son porteur ; le Flash en fait sa règle centrale. **Cela veut dire que l'IA doit savoir ne pas jeter de Flash dans le dos de ses propres alliés**, ou au contraire l'accepter comme un coût. C'est une belle occasion pour la couche de conscience collective : un Grognard qui panique jette son Flash n'importe où et aveugle son escouade ; un gradé le place. **Le même objet raconte deux niveaux de compétence ennemie.**

**Sur les chiffres, la clause « directement sur les PV même protégée, sauf bouclier » est très forte et bien bornée.** La brûlure Lumière à 0,11 ART/s ignore armures et blindages mais **pas** les boucliers. C'est le profil inverse du feu du Sentinel Beam, qui **entretient et allume sans cette restriction**. **Deux feux Forerunner, deux tables de pénétration** — et elles sont documentées au même endroit, en **§5.7**.

**Le total contre une cible nue est de 1,00 ART pile** *(0,45 d'explosion + 0,550 de brûlure Lumière)*, soit **40 % de Yumiko** pour une grenade qui ne coûte qu'un tir à déclencher. Contre un bouclier, l'explosion critique à ×3 fait l'essentiel du travail et la résiduelle ne s'applique pas. **La grenade est donc un outil de décapage collectif, pas un finisseur** — même logique que la Grenade Dynamo Brute, avec l'aveuglement en plus et le dégât direct en moins.

**✅ Critique fixé à 1,35 ART**, ce qui garde le **×3 exact** et aligne le Flash sur la Grenade Dynamo *(0,35 × 3 = 1,05)*. Plus aucun multiplicateur bâtard dans la faction.

**Le passage de la résiduelle au type LUMIÈRE change le poids de l'arme, et dans le bon sens.** L'ancienne flamme propre à la fiche valait 0,40 ART ; la brûlure Lumière en vaut **0,550**. Le total contre une cible nue passe donc de 0,85 à **1,00 ART pile** *(0,45 + 0,550)* — **40 % de Yumiko pour une grenade qui ne coûte qu'un tir à déclencher**, et qui aveugle en plus.

**Contre un bouclier, la lecture est inverse et c'est ce qui rend l'objet honnête.** L'explosion critique à 1,35 fait tout le travail, mais la brûlure **ne s'applique pas** — la clause « sauf bouclier » tient. Le Flash décape donc très fort et n'achève jamais : **1,35 sur les 2,50 de Yumiko**, soit un peu plus de la moitié, sans un point de PV entamé. C'est un outil d'ouverture collective, pas un finisseur, exactement comme la Dynamo.

**✅ La condition de déclenchement est fixée, et elle n'est pas une liste fermée.** Le Flash s'allume aux **armes Forerunner en général**, **et à certaines armes de type incendiaire**. Le critère faisant autorité est **la matrice des effets** *(§5.2, ligne LUMIÈRE)* — pas la nature de la munition, ce qui règle le cas des armes non-Forerunner comme la Grenade Incendiaire ou la Tourelle Spiker.

---

## 5. Matrice des effets et contrôles

> **Statut : transcription de la matrice V2 de l'auteur.** Cette section est la **source de vérité unique**
> pour tous les états, brûlures, zones et effets de contrôle. Les fiches d'armes des §1 à §4 s'y réfèrent
> et ne redéfinissent plus ces valeurs. **En cas de contradiction entre une fiche et cette matrice, la
> matrice prime** — les fiches V2 annoncées lèveront les résidus, relevés au **§5.9**.
>
> **Numérotation préservée.** Le nouveau type d'effet **Plasma Véloce** est inséré en **§5.3 bis** et non
> en §5.4, afin de ne casser aucun des renvois existants vers §5.4 *(souffle cinétique)*, §5.6
> *(saignement)* et §5.7 *(synthèse)*.

### 5.0 — Notion d'entretien

**Entretenir = remettre à zéro le compte à rebours** d'une flaque *(au sol)* et/ou d'une brûlure
*(sur l'ennemi)*, le cas échéant. Ce n'est ni un cumul de dégâts, ni une extension : **c'est un reset**.

| Terme | Définition |
|---|---|
| **Allumer** | Créer l'état sur une cible ou un sol qui ne l'a pas |
| **Entretenir** | **Reset du cooldown** de la flaque et/ou de la brûlure en cours |
| **Raviver / rallumer** | Rétablir un état **éteint**, dans la fenêtre de grâce propre à la source |
| **Permuter** | Entretenir en **changeant le type** de feu *(Crémator, Heatwave, Ravageur)* |

> ### ⚖️ Règle de non-cumul *(arbitrage auteur, reconduit)*
>
> **Une flamme en remplace toujours une autre — tous types confondus.** Rallumer, entretenir ou permuter
> **écrase** l'état en cours ; les brûlures ne courent **jamais en parallèle**. Une cible ne porte
> **qu'une seule brûlure à la fois**, un sol **qu'une seule flaque**.
>
> Conséquence : **le DPS de brûlure est plafonné par construction** au plus violent des cinq types —
> désormais **0,12 ART/s** *(Incendier et Combustible, à égalité)*. Aucune combinaison, aucune
> coopération, aucun empilement ne peut le dépasser.

---

### 5.1 — Les cinq types de flamme : table de référence

| Type | ART/s | **Crit. flaque** | Durée flaque | Durée brûlure | Total flaque | Total brûlure |
|---|---|---|---|---|---|---|
| **Incendier** | **0,12** | **×2,50** | **5,00 s** | **3,50 s** | 0,600 | 0,420 |
| **Zone Plasma** | **0,09** | **×1,50** | **7,00 s** | **4,50 s** | 0,630 | 0,405 |
| **Plasma Instable** | **0,11** | **×1,50** | **4,50 s** | **3,00 s** | 0,495 | 0,330 |
| **Combustible** | **0,12** | **×1,75** | **10,00 s** | **2,00 s** | **1,200** | 0,240 |
| **Lumière** | **0,10** | — | **Aucune** | **5,00 s** | — | 0,500 |

**Retardateur Plasma Instable : 2,00 s** *(voir §5.2)*.

**Lecture — la V2 resserre tout, et c'est le changement le plus important de la matrice.**

| | V1 | V2 | Écart |
|---|---|---|---|
| **Plafond de DPS de brûlure** | 0,18 | **0,12** | **−33 %** |
| Incendier | 0,18 | 0,12 | −33 % |
| Zone Plasma | 0,13 | 0,09 | −31 % |
| Plasma Instable | 0,16 | 0,11 | −31 % |
| Combustible | 0,175 | 0,12 | −31 % |
| Lumière | 0,11 | 0,10 | −9 % |

**Les cinq types ont été divisés par le même facteur, à un cheveu près — sauf Lumière.** C'est une
**recalibration d'ensemble**, pas un rééquilibrage relatif : la hiérarchie entre les feux est conservée
presque à l'identique, seule l'échelle descend d'un tiers. Le feu **cesse d'être une source de dégâts**
pour devenir franchement **un outil de pression et de contrôle de terrain**. Je pense que c'est le bon
sens de marche pour un socle sans sprint, où le joueur ne peut pas fuir vite : un feu qui tue lentement
est un feu qu'on peut jouer.

**Lumière est la seule à ne pas suivre, et elle devient le meilleur type anti-personnel.**

| En % de Yumiko *(2,50 ART)* | Flaque seule | Brûlure seule |
|---|---|---|
| Incendier | 24,0 % | 16,8 % |
| Zone Plasma | 25,2 % | 16,2 % |
| Plasma Instable | 19,8 % | 13,2 % |
| **Combustible** | **48,0 %** | 9,6 % |
| **Lumière** | — | **20,0 %** |

Avec **0,500 ART**, Lumière porte désormais **la brûlure la plus lourde du jeu sur cible**, devant
Incendier *(0,420)*. En V1 elle était déjà en tête, mais de peu ; l'écart se creuse. Cohérent avec la
faction : **les Sentinelles ne salissent pas le terrain, elles marquent des cibles** — et elles le font
mieux que tout le monde.

**La nouvelle colonne « Crit. flaque » est l'ajout structurant de la V2.**

| Type | ART/s nominal | **Sur protection** | Gain |
|---|---|---|---|
| **Incendier** | 0,12 | **0,300** | **+150 %** |
| Combustible | 0,12 | **0,210** | +75 % |
| Plasma Instable | 0,11 | **0,165** | +50 % |
| Zone Plasma | 0,09 | **0,135** | +50 % |

**Le feu devient une arme anti-protection, alors qu'il était une arme anti-chair.** C'est un renversement
complet, et il rachète largement la baisse de 33 % : contre une cible protégée, une flaque d'Incendier
frappe **0,300 ART/s**, soit **plus fort que le plafond de la V1**. Le nouveau maximum de la matrice n'est
plus contre la chair, il est **contre le bouclier**.

⚠️ **Ce renversement heurte de plein fouet la doctrine de la brûlure.** La règle en vigueur dit que
**le feu ne passe pas les boucliers** *(exception unique : Plasma Instable)*. Or un « critique de flaque »
n'a de sens que s'il **frappe quelque chose** sur une cible protégée. Deux lectures possibles, **je ne
tranche pas** :

| Lecture | Conséquence |
|---|---|
| **A — le crit vise les armures uniquement** | Cohérent avec la doctrine : le bouclier arrête toujours, le crit ne joue que sur les protections **physiques**. C'est ce que dit la fiche §2.8 du Canon à Combustible *(« toutes protections destructibles, **sauf blindage** »)* |
| **B — le crit vise aussi les boucliers** | Le feu redevient anti-bouclier, et la liste fermée à trois de **D9** *(Pistolet chargé, Fusil Électrique, Grenade Dynamo)* n'est plus fermée |

**La lecture A est la seule compatible avec les décisions déjà rendues**, mais la matrice ne le dit pas.

> ### ⚖️ Le feu ne passe pas les boucliers — sauf le Plasma Instable *(reconduit)*
>
> | Type | Passe le bouclier ? |
> |---|---|
> | Incendier · Zone Plasma · Combustible · Lumière | **Non** |
> | **Plasma Instable** | **OUI — directement sur les PV** |
>
> **La condition d'allumage reste propre à l'arme** et ne se déduit pas de cette règle. **Allumer et
> pénétrer sont deux questions distinctes.** Carve-out nommé : l'**enflammement spontané** *(§5.2)* est du
> Plasma Instable et **ne marche pas sur les boucliers**.

> ### ⚖️ Le contre-jeu des flaques, c'est de sortir *(reconduit)*
>
> **Aucun plafond d'entretien.** Une flaque peut durer indéfiniment : c'est à Yumiko de quitter la zone.
>
> | Temps dans une flaque de Combustible | Coût *(nominal)* |
> |---|---|
> | 1,00 s | 0,120 ART — 4,8 % |
> | 3,00 s | 0,360 ART — 14,4 % |
> | 5,00 s | 0,600 ART — 24,0 % |
> | 10,00 s *(durée pleine)* | **1,200 ART — 48,0 %** |
>
> La flaque de Combustible passe de **70 % à 48 %** du total de Yumiko. Elle reste **de loin la plus
> lourde du jeu**, mais elle ne fait plus les deux tiers d'une mort à elle seule.

---

### 5.2 — Qui allume, qui entretient, qui éteint

**INCENDIER** — *0,12 ART/s · crit flaque ×2,50 · flaque 5,00 s · brûlure 3,50 s*

| Source | Allume | Entretient | Détail |
|---|---|---|---|
| **Grenade incendiaire** *(CSNU / Brute)* | ✅ sol **et** ennemi | ✅ **automatique** | Flaque **4 m** de diamètre |
| **Lance-Grenades FL101** | ✅ sol **et** ennemi | ✅ **automatique** | Idem grenade |
| **Lance-Flammes** | ✅ **12 tirs** dans la même zone | ✅ **12 flammèches** à ré-infliger | ⚠️ **Flaque et brûlure résiduelle uniquement** — le **jet direct garde son propre barème** *(§1.13)* |
| **Laser Spartan** | ✅ cible **non protégée** survivant au tir | ✅ **+3,00 s** *(additif)* | Allumage scalé **×0,667** ⚠️ *(voir conflit §5.9)* · **à l'entretien, plus aucun scaling** |
| **Lance Spartane** *(projectile)* | — | ✅ **rallume** une cible brûlée | Incendier **ou** Lumière · **pas** les flaques · rallumage au laser **×0,667** |
| **Tourelle Spiker Lourde** | ✅ **12 coups** encaissés | ✅ tous les **3 tirs** sur cible brûlée | Combustion par accumulation |
| **Crémator** | ✅ **3 tirs** sur ennemi · **3 tirs au même endroit** = flaque | ⚠️ **PERMUTANT** | Entretenir un feu Incendier **le transforme en Lumière** · entretient aussi un feu Lumière |

> ### ⚖️ Périmètre du Lance-Flammes : le jet direct n'entre pas dans la matrice *(reconduit)*
>
> | Régime | Régi par | Valeurs |
> |---|---|---|
> | **Jet de flammes direct** *(burst)* | **La fiche §1.13, inchangée** | 0,125 ART/flamme · **1,25 ART/s** de base · **1,50 ART/s** au cumul 12 · escalade 0,1375 / 0,15 · malus armure **×0,35** |
> | **Flaque au sol** et **brûlure résiduelle** | **Cette matrice** — type **Incendier** | **0,12 ART/s** · flaque **5,00 s** · brûlure **3,50 s** |
>
> Le burst est un **dégât d'arme**, le résiduel est un **état**. Seul le second obéit au non-cumul du
> §5.0, se fait souffler par les 5 armes du §5.4 et permuter par le Crémator ou le Heatwave.
> **Le jet direct, lui, ne s'éteint pas — il s'interrompt.**
>
> ⚠️ **L'écart entre les deux régimes explose en V2** : le jet direct vaut **1,25 ART/s**, le résiduel
> **0,12**. Un facteur **10,4**, contre 6,9 en V1. Le Lance-Flammes est plus que jamais une arme de burst
> dont la traînée n'est qu'un marqueur.

**ZONE PLASMA** — *0,09 ART/s · crit flaque ×1,50 · flaque 7,00 s · brûlure 4,50 s*

| Source | Rôle | Détail |
|---|---|---|
| **Grenade à Plasma** | **Pose** la zone | **5,50 m** · plasma volatile · **ne colle pas** aux ennemis · s'allume **dans les 4,50 s** tant que la zone est chaude |
| **Fusil à Plasma** *(Estoc)* | **Allume** | Énergie plasma · zone **prête à être allumée** |
| **Tourelle Plasma** *(Estoc)* | **Allume** | Énergie plasma · zone **prête à être allumée** |
| **Grenadier à Plasma** — tir principal | **Allume** | Explosion à énergie plasma |
| **Grenadier à Plasma** — tir chargé | **Pose** | Petite grenade **collante** · zone volatile **4,50 m** · **3,50 s** pour l'allumer |
| **Fusil à Focus** *(Railgun)* | **Allume** | Décharge d'énergie plasma · **allumage violent : +1,50 m de diamètre** |
| **Épée à Énergie** | **Allume** uniquement | **Ne peut pas entretenir** |
| **Fusil à Faisceau** *(mêlée en surchauffe)* | **Allume** | Inflige une **brûlure de type plasma, 2,50 s** ⚠️ *(voir conflit §5.9)* · allume une zone plasma prête, **ou** du **plasma instable hors accumulation suffisante** |
| **Toute explosion volatile** dans un feu engagé | **Entretient** | — |

> **Délai d'allumage — règle absolue : 1,25 s.** Entre l'allumage d'une Zone Plasma et la propagation du
> feu, il s'écoule **toujours** 1,25 s. La flaque **siffle** et produit de **petites étincelles bleues**.
> Ce délai ne se réduit ni ne s'annule, quelle que soit la source.

> **Le Fusil à Faisceau gagne une seconde clé.** Sa mêlée en surchauffe est désormais **la seule source du
> jeu à pouvoir allumer du plasma instable sans accumulation préalable**. C'est un raccourci offert à une
> arme de sniper, et il oblige son porteur au contact — la même tension saine que le §3.7 relevait déjà.

**PLASMA INSTABLE** — *0,11 ART/s · crit flaque ×1,50 · flaque 4,50 s · brûlure 3,00 s · **retardateur 2,00 s***

| Point | Règle |
|---|---|
| **Enflammement spontané** | **L'arrêt du tir** déclenche, **à retardement de 2,00 s**, l'auto-inflammation de la cible touchée **directement ou via armure / blindage** — **jamais sur bouclier** |
| **Valeur du spontané** | **0,05 ART/s pendant 1,50 s** → **0,075 ART** |
| **Accumulation** | Le retardateur **maintient l'accumulation en cours** : c'est le **cooldown avant reset** de la tentative de brûlure |
| **Fin du cooldown** | **L'enflammement spontané signale la fin du cooldown** — l'accumulation est perdue |
| **⭐ Pénétration** | **La brûlure — accumulation *ou* flaque — frappe DIRECTEMENT les PV** et **n'attaque pas la protection** |

| Source | Détail |
|---|---|
| **Fusil à Plasma Brute** | **16 tirs consécutifs** pour infliger la brûlure · **chaque salve de 6 tirs** entretient · **aucune action sur zone** |
| **Pistolet à Plasma Instable** | **Aucune brûlure par accumulation au tir normal** · la **charge** inflige brûlure **et** flaque directe, **sur les PV y compris à travers un bouclier** si elle heurte directement · la charge **allume ou entretient n'importe quelle zone plasma**, **avec permutation** vers Plasma Instable |
| **Ravageur** | **4 tirs consécutifs sur deux salves** *(66 % de réussite)* → brûlure **et** flaque aux pieds, **cible protégée ou non** · **1 seul tir** allume ou entretient une zone plasma **en la permutant** en Plasma Instable |

> **Le retardateur de 2,00 s est le vrai régulateur du type, et il est bien écrit.** Il fait trois choses à
> la fois : il **maintient l'accumulation** entre deux salves, il **punit l'arrêt du tir** par 0,075 ART, et
> il **annonce au joueur** que sa fenêtre est perdue. Un seul paramètre, trois fonctions, aucune ambiguïté.

**COMBUSTIBLE** — *0,12 ART/s · crit flaque ×1,75 · flaque 10,00 s · brûlure 2,00 s*

| Source | Rôle |
|---|---|
| **Canon à Combustible** | Répand du combustible **à chaque tir** · cumul **jusqu'à 3 tirs** sur une même flaque : **4 m → 6,50 m** · tir direct = brûlure sur cible **hors bouclier** · **chaque tir entretient** |
| **Pistolet à Plasma** *(tir chargé)* | **Souffle IEM Plasma** — entretient flaque **ou** brûlure, **y compris après extinction**, tant que le rallumage est possible |

> **Fenêtre de rallumage Combustible : 4,50 s** après l'arrêt de la brûlure.

**LUMIÈRE** — *0,10 ART/s · aucune flaque · brûlure 5,00 s*

| Source | Détail |
|---|---|
| **Sentinel Beam** | Entretient une brûlure **Lumière ou Incendier**, sur n'importe quel ennemi · **allumage : 2,50 s de tir cumulé** sur une même cible *(**5,00 s** sans la toucher = perte de la charge)* → brûlure **de durée ×0,333** ⚠️ *(changement V2 — voir §5.9)* |
| **Heatwave** | **20 unités de tir** *(2,5 tirs)* pour allumer · **4 unités** pour entretenir ou raviver · ⚠️ **PERMUTANT** : un ennemi brûlé en **Incendier** puis ravivé au Heatwave voit sa brûlure **passer en Lumière** |
| **Flash** | Déclenché quand **une arme de type Lumière tire à travers la zone d'aveuglement** — explosion Lumière **7,50 m** · **inflige la brûlure même derrière les boucliers** · rallumable par **certaines armes incendiaires**, signalées individuellement dans leur fiche |
| **Laser Spartan** | Entretient un feu Lumière — bonus **+4,50 s** *(additif : 5,00 + 4,50 = **9,50 s**)* |
| **Lance Spartane** | Entretient un feu Lumière |
| **Tourelle Spiker** | Entretient un feu Lumière *(**3 tirs** sur cible brûlée)* · **allume la Flash** |
| **Crémator** | Sert à l'entretien d'un feu Lumière · **la seconde partie de l'explosion allume la Flash** |

> **Sept sources pour un seul type : Lumière est le feu le plus collectif de la matrice.** Deux armes
> l'allument *(Beam, Heatwave)*, cinq l'entretiennent, et deux d'entre elles ne sont même pas Forerunner
> *(Laser et Lance Spartane, plus la Tourelle Spiker côté Brute)*. **C'est le seul feu que trois factions
> peuvent nourrir**, ce qui en fait le candidat naturel aux combos inter-factions dans une arène mixte.

---

### 5.3 — Dynamo

| Champ | Valeur |
|---|---|
| **Dégâts normaux** | **0,35 ART** |
| **Durée IEM normale** | **5,00 s** |
| **Critique boucliers** | **×3,00** |

| Source | Détail |
|---|---|
| **Grenade Dynamo** | Explosion **cinétique** : concussion + 0,35 ART *(comme un coup de mêlée dans un diamètre fini)* · **IEM sur les véhicules** · **×3 sur les boucliers** |
| **Fusil Électrique** | Déclenche une **explosion Dynamo** sur cible **non protégée par un bouclier** après **5 tirs consécutifs** ⚠️ *(changement V2 — voir §5.9)* |
| **Pistolet à Plasma Véloce** *(charge)* | **FRAPPE Dynamo sans souffle** — dégâts **et** effet **cantonnés au seul ennemi touché**, **aucune zone** · **0,35 ART** + **stun**, même sur cible protégée · **aucun multiplicateur** · tag **CINÉTIQUE** au sens **mêlée/impact** *(§5.6)*, **pas** au sens souffle *(§5.4)* · **contre Yumiko : repousse (SUBI) + Wall Splat**, sans coupure de contrôle |

> ### ⚖️ La frappe sans souffle ne trie rien *(reconduit)*
>
> La charge Véloce ne touche qu'un corps. Elle **n'entretient ni n'éteint aucun des cinq feux**, et
> **n'entre pas dans la liste fermée à cinq du §5.4**. **La Véloce et l'Instable ne se contrarient pas.**
> Le tag cinétique n'a qu'une fonction : ouvrir le **+0,20 ART additif du §5.6**.

> ### ⚖️ Aucun aléa dans cette sandbox *(reconduit)*
>
> **Les 43 armes sont entièrement déterministes.** Tout déclenchement est un seuil de tirs, de temps ou de
> chauffe — quelque chose que le joueur peut tenir ou rater par sa propre faute.

**Le Souffle Dynamo trie les feux — la mécanique la plus fine de la matrice.**

| Le souffle Dynamo… | Types concernés |
|---|---|
| **Entretient / rallume** *(max **4,50 s** après extinction)* | **Combustible** · **Plasma Instable** |
| **Éteint** | **Zone Plasma** · **Incendier** · **Lumière** |

**Le même souffle nourrit deux feux et en éteint trois.** Un joueur qui balance une Dynamo dans un brasier
ne fait pas « une chose », il fait **l'une ou l'autre selon ce qui brûle**. Ça transforme une grenade
utilitaire en **décision de lecture du terrain**.

---

### 5.3 bis — Plasma Véloce *(nouveau type d'effet, V2)*

| Champ | Valeur |
|---|---|
| **Dégâts normaux** | **Selon le tir de l'arme** — le type ne porte pas de dégât propre |
| **Durée de l'effet critique** | **2,50 s** |
| **Critique des plasmas Véloces** | **×1,35** |

| Source | Déclenche ? | En profite ? | Détail |
|---|---|---|---|
| **Pistolet à Plasma Véloce** | ✅ **9 tirs** sur cible **non protégée** · **la charge** l'applique **même sur cible protégée** | ❌ **NON** | Poseur pur |
| **Fusil à Faisceau** | ✅ **Mêlée 2** met en état critique · **un tir sur point faible** déclenche **même sur cible protégée** *(la précision applique l'effet malgré la protection)* | *(non précisé)* | Double voie : contact **ou** précision |
| **Répéteur à Plasma** | ❌ **Aucun déclenchement** | ✅ **oui, et l'entretient à chaque tir** | **1–12 tirs** : ×1,35 / 2,50 s · **13 tirs et +** : **×1,65** / **3,50 s** |

> ### ⭐ C'est un état de vulnérabilité d'escouade, pas un buff d'arme
>
> **La ligne la plus forte de la V2 est celle-ci : le Pistolet Véloce ne profite pas de l'effet qu'il
> pose.** L'arme qui ouvre la fenêtre est explicitement exclue de la récompense. Il n'existe, à ma
> connaissance, **aucun autre exemple de ce schéma dans les 43 armes** — partout ailleurs, celui qui
> déclenche encaisse au moins une partie du gain.
>
> **Conséquence directe : le Plasma Véloce n'a de valeur que s'il y a un second porteur.** Un Élite seul
> avec un Pistolet Véloce pose un état que personne n'exploite. Deux Élites — un Véloce, un Répéteur — et
> la fenêtre devient réelle. **C'est le premier effet de la sandbox qui exige une composition d'escouade
> pour exister**, ce qui en fait un excellent levier de dotation.

**Le Répéteur à Plasma change de rôle, et c'est le vrai bénéficiaire de la V2.**

| Régime du Répéteur | Multiplicateur | Durée | Lecture |
|---|---|---|---|
| **1 à 12 tirs** | ×1,35 | 2,50 s | Régime nominal |
| **13 tirs et +** | **×1,65** | **3,50 s** | **+22 % de dégâts, +40 % de fenêtre** |

**La rafale longue est récompensée deux fois — en puissance et en durée — ce qui est très inhabituel et
très bien vu.** Le Répéteur était jusqu'ici l'arme d'assaut générique du Covenant, le pendant du MA5B. Il
devient **l'arme qui capitalise sur le travail des autres** : elle ne pose rien, mais elle est la seule à
faire monter le multiplicateur au-delà du barème. Un Répéteur qui tient sa rafale au-delà du 13ᵉ tir
**auto-entretient sa propre fenêtre** — chaque tir reset les 3,50 s, donc le critique ne retombe jamais
tant que le doigt reste sur la détente.

⚠️ **C'est aussi le point de rupture à surveiller.** Une chauffe suffisamment permissive rend le régime
×1,65 **permanent** contre une cible marquée. Le seuil de 13 tirs et la courbe de surchauffe du Répéteur
*(§2.4)* deviennent le vrai garde-fou du type — **pas le multiplicateur**.

**Le Fusil à Faisceau accumule les casquettes, et il faudra le regarder.** Il est déjà : sniper de la
faction Brute, allumeur de Zone Plasma, **seule** source d'allumage du Plasma Instable sans accumulation,
et maintenant déclencheur de Plasma Véloce **à travers les protections** sur un tir de précision. Quatre
rôles sur une arme portée par une unité d'élite. **Je le signale, je ne propose rien** — mais c'est la
fiche la plus chargée du roster.

---

### 5.4 — Souffle cinétique (concussion)

| Champ | Valeur |
|---|---|
| **Dégâts** | **Variables** — précisés par fiche |
| **Rayon** | **Variable** — précisé par fiche |
| **Effet** | **Souffle tout type de flamme** |

**Armes concernées** *(5)* :

| Arme | Faction | Note |
|---|---|---|
| **Grenade à Fragmentation** | CSNU | — |
| **Lance-Grenades M319 IGL** | CSNU | — |
| **Lance-Roquettes M41 SSR MAV/AW** | CSNU | Impact **et** souffle cinétiques |
| **Marteau Antigravité** | Brutes | **Toutes formes** — frappe, onde de choc, variantes |
| **Sabre Grenade** | Brutes | Impact + souffle **toujours cumulés** |

> **Le Déchiqueteur et la Grenade Dynamo ne sont pas des armes cinétiques.** Le premier sort de la liste
> *(ses lames ne soufflent pas)* ; la seconde a **son propre tri** en §5.3.
>
> **La charge du Pistolet à Plasma Véloce n'y entre pas non plus.** Son tag **CINÉTIQUE** vaut au sens
> **mêlée/impact** — il ouvre le **+0,20 ART du §5.6** — et **non au sens souffle**. **La liste reste
> fermée à cinq.**

| Règle | Portée |
|---|---|
| **Absence de mention impact / souffle** | Même en tir direct, **seul le souffle touche l'ennemi** |
| **Aiguilles** | Le souffle **détruit les aiguilles plantées** sur un ennemi |
| **Marteau Antigravité** | **Toutes ses formes** soufflent — aucune n'échappe à la règle |
| **Lance-Flammes** | Le souffle éteint **la flaque et la brûlure résiduelle**, mais **pas le jet direct** *(§5.2)* |

---

### 5.5 — Super-Combines et aiguilles

| Champ | Valeur |
|---|---|
| **Dégâts / rayon** | **Variables** |
| **Principe** | **Enlève toute forme de brûlure ou de flaque** |

| Source | Mécanique |
|---|---|
| **Needler / Fusil à Aiguille** | **Arc Cristal, relai IEM** — un ennemi porteur de pics **reconduit l'électricité et l'IEM** aux ennemis derrière lui, dans un **angle de 45°** dans l'axe du tir. Frappes multiples **derrière une unité tank** |
| **Grêleur** | Explosion réagissant au plasma instable : **allume / rallume** une brûlure Plasma Instable **et Incendier** · **propagation 4 m** · applique aussi **l'Arc Cristal, le relai IEM et la propagation de brûlure Combustible** |

**Deux émergences explicitement écrites par l'auteur :**

| # | Condition | Effet |
|---|---|---|
| **1** | Ennemi **avec des pics** **+** brûlé au **Combustible**, frappé par une **charge plasma** ou un **effet Dynamo** *(Grenade Dynamo, explosion Dynamo)* | La **brûlure se propage** en même temps que l'électricité |
| **2** | Ennemi brûlé par une **Zone Plasma** frappé par une **Super-Combine** | La brûlure se propage aux ennemis dans **3 m** |

**C'est le cœur systémique de la sandbox.** Rassemblées, ces lignes disent une chose simple : **les pics
sont un réseau**, et tout ce qui les traverse — électricité, IEM, feu — se distribue à l'escouade entière.

---

### 5.6 — Saignement

> **Sixième type d'effet, et le seul qui ne soit pas une flamme.** Porté par les **attaques de mêlée
> tranchantes**, par opposition à la mêlée cinétique standard. Il n'obéit pas au souffle du §5.4 mais à une
> extinction propre : **la cautérisation**.

**Statistiques génériques**

| Champ | Valeur |
|---|---|
| **Mêlée de base** | **0,35 ART** — *inchangée* |
| **Durée** | **2,50 s** |
| **Dégâts** | **0,05 ART/s** |
| **Total** | **0,125 ART** *(5,0 % de Yumiko)* |
| **Armes concernées** | Celles dont l'attaque de mêlée est de type **tranchant** et non **cinétique** |

**Condition d'application — la plus stricte de la matrice**

| Règle | Portée |
|---|---|
| **Report de DPS** | **Oui**, comme toute attaque de mêlée et toute attaque en général *(report **GÉNÉRAL**)* |
| **⚠️ Application du saignement** | **Non reportable.** L'attaque doit toucher **intégralement** une cible **dépourvue de bouclier et de protection**. Un coup partiellement absorbé inflige ses dégâts, **mais pas la plaie** |

**Cumul — RÉ-APPLICATION** *(reconduit)*

| Règle | Portée |
|---|---|
| **Cumul** | **AUCUN.** Une cible = **une seule plaie active** |
| **Nouvelle plaie sur cible qui saigne déjà** | **Ré-application** — la plaie repart à sa **durée pleine** |
| **Plaie de puissance différente** | La **nouvelle** plaie s'applique, avec **ses** valeurs et **sa** durée pleine |

> **Ce qui compte n'est pas le total, c'est la fenêtre.** Frapper une deuxième fois ne sert pas à infliger
> plus de dégâts : c'est **relancer les 12,50 s de vulnérabilité** et garder la cible dans l'état qui rend
> le coup dorsal létal. Le saignement est un **marqueur entretenu**, pas une source d'attrition.

**Effet critique — la vulnérabilité tranchant → cinétique**

| Champ | Valeur |
|---|---|
| **Déclencheur** | Une cible **qui saigne** *(ou **a saigné**)* |
| **Durée** | **12,50 s** |
| **Effet** | **+0,20 ART** sur la base de mêlée **cinétique** *(bonus **additif**)* |
| **Portée** | La mêlée cinétique, l'« **estoc plasma** », **le souffle de la Grenade Dynamo** *(§3.10 — traité comme une mêlée)* **et la charge du Pistolet à Plasma Véloce** *(§2.2 — frappe Dynamo, tag cinétique)* |

> ⚠️ **Le bonus est additif, pas un remplacement.** Il ne fixe pas la base à 0,55 : il **ajoute 0,20 à la
> base existante**, quelle qu'elle soit.
>
> ⭐ **ORDRE DES OPÉRATIONS — règle générale *(arbitrage auteur)*.** « Additif » signifie que le **+0,20
> s'ajoute à la base de dégât originelle**, **avant** tout multiplicateur. La formule est donc
> **`(base + 0,20) × multiplicateurs`**, jamais `(base × multiplicateurs) + 0,20`. **Cette règle vaut pour
> toute source portant le bonus**, qu'un multiplicateur soit présent ou non.

| Attaque | Base | Avec saignement | Gain |
|---|---|---|---|
| Mêlée cinétique | 0,35 | **0,55** | +57 % |
| **Souffle Grenade Dynamo** *(§3.10)* | 0,35 | **0,55** | +57 % |
| **Charge Pistolet Véloce** *(§2.2 — à distance)* | 0,35 | **0,55** | +57 % |
| **Estoc Fusil à Plasma** *(traverse le bouclier)* | 0,65 | **0,85** | +31 % |
| **Estoc Tourelle Plasma** *(traverse le bouclier)* | **1,333** | **1,533** | +15 % |

**Le choix de l'additif s'auto-régule** : +57 % sur la mêlée nue, +15 % seulement sur l'estoc le plus
lourd. La vulnérabilité profite surtout à celui qui n'a que ses poings — bon sens de lecture pour un
système dont l'entrée est une lame.

**Émergence — la cautérisation**

> **N'importe quelle brûlure infligée applique la cautérisation** : fin des saignements **et** de l'effet
> critique. **Deux exceptions nommées** : le **Ravageur** *(4,00 s non cautérisable)* et la **Mêlée 1 du
> Marteau Antigravité** *(non cautérisable)*.

**Armes à saignement — barème par arme**

| Arme | Base mêlée | Critique | Saignement | À travers l'armure |
|---|---|---|---|---|
| **Fusil à Plasma Brute** | 0,35 *(générique)* | **×1,50** armures → **0,525** | Générique | **Non** |
| **Mauler** | 0,35 *(générique)* | — | Générique *(la **pointe**)* | **OUI** |
| **Sabre Grenade** | **0,65** | **Mêlée 2** : ×1,35 armures → **0,8775** *(plus lent, recovery longue)* · **Parade** mêlée 1+2 | **×1,35 → 0,0675/s** pendant **3,50 s** | **Non** |
| **Ravageur** | **0,50** | — | **4,00 s** · ⚠️ **NON cautérisable** | — |
| **Marteau Antigravité** *(Mêlée 1)* | **0,50** | **×1,35** protections solides → **0,675** | ⚠️ **NON cautérisable** | **OUI** |
| **Tourelle Spiker** | **0,80** | — | **×1,50 → 0,0750/s** | **OUI** |
| **Tourelle Spiker** *(lancer de la tourelle fixe)* | **1,05** | — | **3,50 s** | — |

---

### 5.7 — Table de synthèse : quoi fait quoi à quoi

| Effet appliqué → | Incendier | Zone Plasma | Plasma Instable | Combustible | Lumière | **Saignement** | **Plasma Véloce** |
|---|---|---|---|---|---|---|---|
| **Souffle cinétique** | Éteint | Éteint | Éteint | Éteint | Éteint | **Sans effet** | — |
| **Souffle Dynamo** | **Éteint** | **Éteint** | **Entretient** | **Entretient** | **Éteint** | **Sans effet** | — |
| **Frappe Dynamo sans souffle** *(charge Véloce)* | — | — | — | — | — | **+0,20 ART** / 12,50 s | **Applique** *(même sur cible protégée)* |
| **Super-Combine** | Enlève | **Enlève + propage 3 m** | Enlève | Enlève | Enlève | — | — |
| **Grêleur** | **Allume / rallume** | — | **Allume / rallume** | **Propage** | — | — | — |
| **Crémator** | **Permute → Lumière** | — | — | — | Entretient | **Cautérise** | — |
| **Laser Spartan** | Allume ×0,667 · **+3 s** | — | — | — | **+4,50 s** | **Cautérise** | — |
| **Sentinel Beam** *(2,50 s cumulés)* | Entretient | — | — | — | **Allume ×0,333** | **Cautérise** | — |
| **Flash** *(détoné)* | — | — | — | — | **Allume — même derrière les boucliers** | **Cautérise** | — |
| **Fusil à Faisceau** *(mêlée surchauffe)* | — | **Allume** | **Allume** *(hors accumulation)* | — | — | — | **Applique** *(Mêlée 2)* |
| **Fusil à Faisceau** *(tir point faible)* | — | — | — | — | — | — | **Applique** *(même protégée)* |
| **Répéteur à Plasma** | — | — | — | — | — | — | **Entretient** *(×1,65 / 3,50 s à 13+ tirs)* |
| **N'importe quelle brûlure** | — | — | — | — | — | **CAUTÉRISE** *(sauf Ravageur et Marteau M1)* | — |
| **Mêlée tranchante** | — | — | — | — | — | **Applique** *(cible sans protection)* | — |
| **Mêlée cinétique** | — | — | — | — | — | **+0,20 ART** / 12,50 s | — |
| **Estoc plasma** *(Fusil, Tourelle)* | Allume | **Allume** | — | — | — | **+0,20 ART** / 12,50 s | — |
| **Passe le bouclier ?** *(§5.1)* | **Non** | **Non** | **OUI — PV directs** | **Non** | **Non** *(sauf Flash)* | — | **Applicable malgré la protection** |

> **Le Saignement reste la seule colonne que le souffle ne touche pas** : son unique extinction est la
> brûlure. **Le Plasma Véloce est la seule colonne que rien n'éteint** — ni souffle, ni brûlure, ni
> Super-Combine. Il expire seul, au bout de ses 2,50 s *(ou 3,50 s sous Répéteur)*.
>
> ⚠️ **C'est le premier état du jeu sans contre-jeu écrit.** Tous les autres ont une sortie : sortir de la
> flaque, souffler le feu, cautériser la plaie. Le Plasma Véloce, une fois posé, **court jusqu'à son
> terme**. Sur une durée de 2,50 s c'est acceptable ; sur les **3,50 s auto-entretenues** du Répéteur, ça
> devient un état permanent tant que la rafale tient. **Signalé, pas comblé.**

---

### 5.8 — Lecture d'équilibrage V2

**La V2 fait trois choses, et elles vont dans le même sens.**

| # | Mouvement | Effet sur la sandbox |
|---|---|---|
| **1** | **−33 % sur tous les DPS de brûlure** | Le feu cesse d'être une source de dégâts |
| **2** | **Ajout du critique de flaque** *(jusqu'à ×2,50)* | Le feu devient une arme **anti-protection** |
| **3** | **Ajout du type Plasma Véloce** | Premier état **d'escouade** : celui qui le pose n'en profite pas |

**Le fil conducteur, c'est le déplacement du feu vers la phase 1 du combat.** En V1, le feu achevait : il
grignotait la chair une fois le bouclier tombé. En V2, il **décape** : ×2,50 sur une flaque d'Incendier,
c'est **0,300 ART/s contre les protections** — et derrière, seulement 0,12 contre la chair. **Le feu et
les armes anti-bouclier travaillent désormais dans la même fenêtre**, ce qui recentre toute la sandbox
Covenant sur la première moitié de l'échange.

**Ce que ça coûte : le feu seul ne tue plus personne.** Il faut **20,8 s** de brûlure Incendier pure pour
abattre Yumiko *(contre 13,9 s en V1)*. Une brûlure Lumière complète, la plus lourde du jeu, retire
**0,500 ART sur 2,50** — un cinquième. **Aucun feu n'est plus une menace de mort en soi**, ce qui est un
choix net et que je trouve juste : le feu est redevenu un **assaisonnement de pression**, et la létalité
est rendue aux armes.

**Ce qu'il faut surveiller** : le régime **×1,65 / 3,50 s** du Répéteur, qui est la seule valeur de la V2
capable de s'auto-entretenir sans plafond écrit.

---

### 5.9 — Relevé de dette et conflits V2

> **Liste de contrôle à confronter aux fiches V2 à réception.** Chaque ligne est **la valeur en vigueur**.
> **La matrice prime sur les fiches** : une fiche V2 qui contredit une ligne ci-dessous est en tort.

**⚠️ Conflits ouverts par la V2 — relevés, non comblés *(§0.7)***

| # | Point | Le conflit |
|---|---|---|
| **54** | **Laser Spartan — scaling ×0,667** | La matrice écrit « ×0,667 → **0,12 ART/s** ». Or **0,12 est désormais la base d'Incendier** : 0,18 × 0,667 = 0,12 était l'**arithmétique de la V1**. Avec la base V2, ×0,667 donne **0,080**. Soit le scaling disparaît *(0,12 = plein tarif)*, soit le résultat est 0,080. **Non tranché** |
| **55** | **Crit. de flaque vs doctrine du bouclier** | Un critique de flaque n'a de sens que s'il frappe une cible protégée, alors que **le feu ne passe pas les boucliers**. Lecture A *(armures seules, conforme à la fiche §2.8)* ou lecture B *(boucliers inclus, qui rouvrirait **D9**)*. **Non tranché** |
| **56** | **Combustible — crit de flaque** | La matrice dit **×1,75**. La fiche §2.8 dit **×2,50 sur toutes protections destructibles, sauf blindage**. **La matrice prime ⇒ ×1,75**, mais l'écart est de 30 % |
| **57** | **Flash — puissance** | La matrice V2 réécrit **0,50 ART** ; la fiche §4.4 porte **0,45**, valeur retenue au tour précédent. **Le conflit est reconduit à l'identique** |
| **58** | **Fusil Électrique — seuil Dynamo** | La matrice V2 dit **5 tirs consécutifs** ; la fiche §3.4 et le §5.3 V1 disaient **4ᵉ tir de Charge**. La V2 **ne mentionne plus l'IEM de 1,05** sur les boucliers voisins ⇒ par §0.7, **la clause tombe**. ⚠️ Ceci **déplace les temps de mise à mort** calculés en §3.4 |
| **59** | **Sentinel Beam — allumage** | V1 : **12,50 % de batterie** *(50 tirs, 1,67 s)*, **durée pleine**. V2 : **2,50 s de tir cumulé**, **durée ×0,333** → **1,665 s**, soit **0,167 ART**. Le coût n'est plus en batterie mais en temps, et la brûlure est **trois fois plus courte**. La perte de charge est fixée à **5,00 s** sans contact |
| **60** | **Fusil à Faisceau — durée de la brûlure** | Sa mêlée en surchauffe est classée **Zone Plasma** *(brûlure 4,50 s)* mais l'énoncé impose **2,50 s**. Override propre à l'arme, ou reliquat du barème Plasma Instable V1 ? **Non tranché** |

**⚠️ Mention d'une arme supprimée**

> La matrice V2 cite la **« carabine plasma »** parmi les sources d'effet Dynamo de l'émergence n° 1
> *(§5.5)*. **Cette arme a été supprimée** — la suppression étant **totale**, elle n'est pas reprise. Les
> sources Dynamo retenues pour cette émergence sont : **charge plasma**, **Grenade Dynamo**, **explosion
> Dynamo du Fusil Électrique**. *(Le Lance-Grenades M319 apparaît par ailleurs **deux fois** dans la liste
> du souffle cinétique — doublon de saisie, la liste reste **fermée à cinq**.)*

**Ce que la V2 des fiches doit porter**

| Emplacement | La V2 doit porter |
|---|---|
| **Tous les DPS de brûlure** | **Nouveau barème §5.1** — Incendier **0,12** · Zone Plasma **0,09** · Plasma Instable **0,11** · Combustible **0,12** · Lumière **0,10**. ⚠️ Les fiches §2.6, §3.6, §3.7 et le §1.13 citent encore les valeurs V1 *(0,16 / 0,18)* |
| **Toutes durées de brûlure** | Incendier **3,50 s** · Zone Plasma **4,50 s** · Plasma Instable **3,00 s** *(valeurs relevées)* |
| **Souffle cinétique** | **§5.4** — liste fermée à **5** : Frag · M319 · M41 · Marteau · Sabre Grenade. **Renvoi unique**, aucun encart recopié |
| **§1.13 Lance-Flammes** | **Jet direct inchangé** *(0,125/flamme, 1,25 → 1,50 ART/s, escalade 0,1375 / 0,15, malus ×0,35)*. Flaque et résiduel en **Incendier** *(0,12 / 5,00 s / 3,50 s)* · **12 tirs** pour allumer, **12 flammèches** pour entretenir |
| **§2.7 Fusil à Focus** | Critique brûlés **×1,50** **+ traversée de blindage ×1,00 sur cible brûlée** · **allumage violent : +1,50 m** |
| **§2.8 Canon à Combustible** | **Combustible** *(0,12 / 10,00 s / 2,00 s)* · **crit flaque ×1,75** *(cf. conflit 56)* · cumul **3 tirs → 6,50 m** · rallumage **4,50 s** |
| **§2.9 Grenade Plasma** | **5,50 m** · fenêtre **4,50 s** · délai **1,25 s** |
| **§2.4 Répéteur à Plasma** | ⭐ **Nouveau rôle §5.3 bis** — profite et entretient le Plasma Véloce · **13 tirs et + : ×1,65 / 3,50 s**. La **courbe de surchauffe devient le garde-fou du type** |
| **§3.1 Fusil à Plasma Brute** | **§5.6** — critique armures **×1,50** *(0,525)* · saignement générique, **pas à travers l'armure** · **16 tirs** pour la brûlure, **6** pour entretenir, **aucune action sur zone** |
| **§3.2 Mauler** | **§5.6** — saignement **à travers l'armure** *(la pointe)* |
| **§3.3 Sabre Grenade** | **§5.6** — base **0,65** · Mêlée 2 crit armures **×1,35 → 0,8775** · saignement **×1,35 → 0,0675/s sur 3,50 s** · **Parade** mêlée 1+2 |
| **§3.4 Fusil Électrique** | ⚠️ **5 tirs consécutifs** *(cf. conflit 58)* · cible **non protégée par un bouclier** |
| **§3.5 Marteau Antigravité** | **§5.6** — base **0,50** · critique **×1,35** *(0,675)* · saignement **non cautérisable, à travers l'armure** |
| **§3.6 Ravageur** | **§5.6** — base **0,50** · saignement **4,00 s non cautérisable** · **4 tirs / 2 salves** pour brûlure + flaque · **1 tir** permute une zone |
| **§3.7 Fusil à Faisceau** | ⭐ **Trois rôles nouveaux** — allume Zone Plasma **et** Plasma Instable hors accumulation *(mêlée surchauffe, **2,50 s**)* · applique **Plasma Véloce** en Mêlée 2 **et** au tir sur point faible, **même à travers une protection** |
| **§3.11 Tourelle Spiker** | **§5.6** — base **0,80**, saignement **×1,50 à travers l'armure** *(0,0750/s)*, lancer **1,05 / 3,50 s** · combustion **12 coups**, entretien tous les **3 tirs**, feu **Lumière**, **allume la Flash** |
| **§4.1 Sentinel Beam** | ⚠️ **2,50 s de tir cumulé** · perte de charge à **5,00 s** sans contact · brûlure **Lumière ×0,333** *(cf. conflit 59)* |
| **§4.4 Flash** | Déclenché par **une arme Lumière tirant à travers la zone d'aveuglement** · **7,50 m** · **brûlure même derrière les boucliers** · rallumable par certaines armes incendiaires |
| **Crémator** | ⭐ **Entrée Incendier ajoutée** — **3 tirs** sur ennemi = brûlure · **3 tirs au même endroit** = flaque · **entretien PERMUTANT → Lumière** · seconde partie de l'explosion **allume la Flash** |
| **Heatwave** | Entretien **permutant** : Incendier ravivé → **Lumière** · **20 unités** pour allumer, **4** pour entretenir |
| **Laser Spartan** | Entretien **additif** : **+3,00 s** *(Incendier)* / **+4,50 s** *(Lumière)* ⚠️ *scaling d'allumage : cf. conflit 54* |

---

## 6. Matrice consolidée

### 6.1 — CSNU : vue d'ensemble

| # | Arme | Classe | ART/tir | ART/s | Chargeur | Réserve | Anti-bcl | Critique |
|---|---|---|---|---|---|---|---|---|
| 1 | MA37 | Principale | **0,071** | **0,568** | 32 | 384 | ×0,80 | ×1,25 armures · pts faibles · **×1,40 casques** |
| 2 | MA5B | Hybr. Princ./Sout. | 0,059→0,092 | 0,885→1,372 | 60 | 300 | ×0,80 | ×1,20→×1,35 *(sec 3–4)* |
| 3 | M6D | Légère | 0,225 | 0,563 | 12 | 60 | — | **×5,00** |
| 4 | M6C | Légère | 0,15 | variable · **dual 1,80 max** | 15 | 150 · **dual 240** | — | perfo. Grognards |
| 5 | M7 / M7-S | Légère | 0,045 | 0,540 | 48 | 384 | — | **×1,35** pts faibles *(M7-S seul)* |
| 6 | W0-LF M4 | Principale | 0,65 | 0,975 | 8 | **24** | — | ×2,00 · ×1,50 armures |
| 7 | BR75 | Principale | 0,36/salve | 0,536 | 36 | 144 | — | **×5,00** *(1,80/salve)* · **×1,35 casques** |
| 8 | M90 CAWS | Soutien | **1,375** | 0,825 | 6 | 24 | — | ×1,50 < 4 m |
| 9 | SRS99C S2 | Hybr. Sout./Lourd | **1,50** | 3,00 | 4 | 20 | ×0,75 | **PERFORATEUR** |
| 10 | M41 Roquettes | Lourd | **3,50** | — | 2 | **6** | ×0,66 *(souffle)* | — |
| 11 | Laser M6 | Lourd | **3,50** | — | **5** | batterie · **recharge mêlée** | **aucun** | PERFO. + véhicule |
| 12 | M319 IGL | Hybr. Princ./Lourd | 1,25 | 0,550 | **1** | 24 | ×0,60 | adhésif ×1,40 |
| 14 | Lance-Flammes | Hybr. Lourd/Sout. | 0,125 **+ 0,125 rés.** | 1,25→**1,50** | 100 | 300 | — | ×0,35 armures |
| 15 | Lance Spartane | **SPÉCIALE** | 0,35/unité | — | batterie | cinétique | — | 6,01–7,50 m |
| 16 | Grenade Frag | Lancer | **1,25** | — | 8 | — | — | ×1,50 armures |
| 17 | M739 LMG/SAW | **Lourd FIXE – Lourd** | 0,085 | 1,105 | 200 / 72 | 360 | ×0,75 | **×1,50 casques + armures** |

---

### 6.2 — Écarts arithmétiques : tous tranchés ✅

Les neuf écarts A–I sont **clos**. Valeurs qui font foi :

| # | Arme | Résolution |
|---|---|---|
| **A** | **MA37** | **0,071 ART** · 0,568 ART/s — le chargeur de 32 tue un Minor pile |
| **B** | **BR75** | **La fiche avait raison** : « 5 salves + 2 tirs » = 2,04 sur un bouclier de 2,00. Le 3ᵉ tir de la 6ᵉ salve part dans les PV. Bouclier du Major **inchangé à 2,00** |
| **C** | **BR75** | **×5,00 → 1,80/salve**. Le 1,50 venait d'une version à 0,10 ART/tir, périmée |
| **D** | **W0-LF** | **0,975** en critique armure *(×1,50)* |
| **E** | **SRS99 SSR** | Base **1,00 ART**, **0,75 contre bouclier** — c'était le malus ×0,75 standard, pas une pénalité |
| **F** | **M7 / M7-S** | **0,0833 s** entre deux tirs |
| **G** | **M7** | Réserve **384** |
| **H** | **Lance-Flammes** | **Rework complet** — 0,125 instantané + 0,125 résiduel par flamme, burst max 1,50 au cumul 12. Voir §1.13 |
| **I** | **Laser M6** | **5 tirs à 20 %** + **recharge cinétique à la mêlée** *(0,35 %/0,01 ART, ×1,50 → 0,525 % avec Lance Spartane)* |

**Arrondis** — corrigés dans toutes les fiches, valeurs retenues : MA5B **0,885** / **0,708** · M6D crit **1,125** · W0-LF **0,975** ART/s · BR75 **1,488 salve/s** et **0,536** ART/s · M90 **0,825** · M41 souffle **1,125** et **1,650** · SAW **0,0553**, **0,718**, **1,658**.

---

### 6.3 — Points ouverts CSNU : soldés ✅

Les onze points sont tranchés. Décisions structurantes conservées ici pour mémoire :

| # | Arme | Décision |
|---|---|---|
| 1 | **Lance Spartane** | Le palier suit le **momentum réel**, pas la vitesse nominale. Marche à 1,10 = palier 1 = **10 tirs** · retour à **20 %** sous 1,10 *(accélération, slide, sortie de BRS, dérive)* |
| 2 | **Lance Spartane** | Le recovery **n'entrave pas le déplacement** — Yumiko bouge pendant, Hornet compris. Utile pour les ennemis et les armes à combos |
| 3 | **M41** | **Impact et souffle cinétiques** · pénalité anti-bouclier sur le **souffle seul** — un contact direct place 1,00 ART pleins |
| 4 | **Laser M6** | Pas de recharge au sol · **recharge cinétique à la mêlée** |
| 6 | **SAW décrochée** | **Lourd FIXE – Lourd** · **tir au jugé supprimé** |
| 8 | **M6C** | Pas de ligne anti-bouclier en fiche ⇒ **il n'y en a pas**. *(Règle générale — voir encadré ci-dessous)* |
| 9 | **M319** | Mentions anti-véhicule **retirées** · grille ANB traitée en temps voulu |
| 10 | **M7-S** | Balle critique de fin de rafale **supprimée** · critique points faibles **×1,65 → ×1,35** *(0,061 · 0,732 ART/s)* |
| 11 | **M6C dual** | Cadence bornée à **6 c/s par arme** *(1,80 ART/s)* · portée **6–20 m** · spread **seulement** en rafale à vitesse maximale, aucun sous **8 c/s combinés** |

> **Règle de lecture générale, issue du point 8 :** *ce que la fiche ne mentionne pas n'existe pas.*
> Vaut particulièrement pour les notes qui **modifieraient une valeur de base** déjà inscrite —
> un malus, un scaling, un multiplicateur non écrit ne doit jamais être supposé par analogie
> avec une autre arme. Cette règle complète §0.7 *(aucun placeholder inventé)*.

---

### 6.4 — Lectures transversales CSNU

**Le CSNU n'a toujours aucune clé anti-bouclier généraliste.** Sept armes sur dix-sept subissent un malus contre les boucliers énergétiques (MA37, MA5B ×0,80 · SRS99 et son SSR, SAW ×0,75 · M41 sur le souffle ×0,66 · IGL ×0,60), et **aucune** ne porte de bonus. Les deux seules réponses restent **l'IEM du M319** (1,25 anti-bouclier, ×0,40 sur la chair) et son **adhésif** (traverse le bouclier) — une arme, deux modes, un chargeur de 1. Les arbitrages ne changent rien à ce constat, ils le **durcissent** : le M41 confirme que seul son souffle est pénalisé, et le laser reste la seule exception franche. Le contrepoids viendra des factions Covenant.

**Le CSNU s'est en revanche doté d'une clé anti-protection dure, et c'est le vrai apport de ce lot.** Trois armes portent désormais un critique casque, propagé aux armures par §0.8 :

| Arme | Mult. | Classe | Portée | Malus bouclier | Rôle |
|---|---|---|---|---|---|
| **SAW** | **×1,50** | Lourd | 12–25 m | ×0,75 | Marteler, poste tenu |
| **MA37** | **×1,40** | Principale | 15–25 m | ×0,80 | Décaper, ramassable partout |
| **BR75** | **×1,35** | Principale | 10–75 m | aucun | Cueillir à distance |

La courbe est inverse de l'accessibilité : **plus l'arme est contraignante, plus le multiplicateur est haut.** C'est proprement calibré. Et ça donne au CSNU une identité que la lecture précédente ne voyait pas — il n'ouvre pas les boucliers, mais il **détruit tout ce qui est solide derrière**. Face aux Élites il subit ; face aux Brutes, faction de l'armure, il est chez lui. **Le MA37 est explicitement redéployé sur ce terrain** : c'est l'arme d'ouverture des niveaux Jiralhanae, pas des niveaux Covenant.

**Le Laser M6 est la seule arme du roster sans aucune pénalité de bouclier.** Il est aussi la seule arme à 3,50 ART pleins. Cette exception mérite d'être protégée : c'est elle qui justifie les 2,50 s de charge.

**Le budget de munitions reste le vrai levier d'équilibrage du CSNU**, et la courbe tient après arbitrage : W0-LF **24**, M90 **24**, IGL **24**, SRS99 **20**, M41 **6** en bas ; MA37 **384**, M7 **384**, SAW **360**, Flammes **300**, MA5B **300** en haut. La puissance se paie en rareté, pas en malus.

**Mais une seconde monnaie vient d'apparaître à côté des munitions : la mêlée.** Le rework du Laser M6 fait de la batterie une ressource qui ne se ramasse pas — elle se **gagne au contact**, à 0,35 % par 0,01 ART infligé, 0,525 % avec une Lance Spartane — soit **0,571 ART de mêlée pour un tir**, près de deux coups de base. Additionné à la recharge cinétique de la lance (+5 % par accélération, +20 % par parade), ça installe une **deuxième économie parallèle** dans le roster :

| Économie | Armes | Se reconstitue par |
|---|---|---|
| **Munitions** | 15 armes sur 17 | Ramassage au sol |
| **Énergie cinétique** | **Laser M6, Lance Spartane** | **Mêlée, mobilité, parade** |

Les deux armes concernées sont aux extrémités absolues du roster — la plus lourde et la plus courte portée — et elles partagent le même carburant. Le ×1,50 accordé au laser quand une Lance Spartane est portée n'est donc pas un détail : c'est une **incitation explicite à les chaîner**. Un joueur qui va au contact finance son arme de siège. C'est la traduction la plus littérale de D15 qu'on ait dans la sandbox : ici, **ne pas jouer le sommet Mêlée coûte littéralement des munitions**.

**Le verrou « pas d'armes spéciales » dessine toujours un axe de chargement** — SRS99, M319 et Lance-Flammes interdisent le port, le MA5B taxe la mobilité en duo ambidextre *(**D16**, deux verrous distincts · liste complète en §3.6 et dans `base-de-travail.md`)*. Mais l'arbitrage sur le laser **ouvre une brèche volontaire dans cet axe** : le Laser M6 est une arme Lourde qui, elle, **gagne à être portée avec la Lance Spartane**. Le roster ne dit donc plus seulement « choisis un camp » ; il dit *« choisis un camp, sauf ici, où le mariage est récompensé »*. Une exception nommée vaut mieux qu'une règle sans relief — mais elle doit être **lisible dans l'interface de chargement**, sinon elle restera invisible.

**L'articulation casque / perforation est la meilleure trouvaille du roster.** Le SRS99 ignore les casques mais bute sur le Dévot ; la SAW ne les ignore pas mais les casse à ×1,50, Dévot compris. Deux armes, deux philosophies, et une unité qui ne cède qu'à l'une des deux. À exploiter en level design.

**Le Triangle est correctement alimenté, et le sommet Mêlée n'est plus tenu par une seule arme.** Sommet Tir : tout le roster. Sommet Mobilité : Légère et Principale le préservent, Soutien et Lourd le taxent — mais **le taxent sans le fermer** : le Lourd est un **plafond de vitesse (1,10) et de saut**, pas une interdiction, et même la classe Fixe conserve une charge linéaire à 1,05. Ce que ces classes retirent vraiment, c'est **la verticalité et la liberté de trajectoire**, pas le déplacement. Sommet Mêlée : la **Lance Spartane** évidemment, mais désormais aussi le **Laser M6**, qui ne se recharge qu'au contact, et le **W0-LF** qui fige les cibles pour le combo dorsal. Trois armes alimentent le sommet au lieu d'une, par trois voies différentes — dégâts, ressource, contrôle.

---

---

### 6.5 — Covenant / Élites : vue d'ensemble

> **Lot arbitré et clos.** Les treize fiches sont à jour des décisions de l'auteur : rework du Focus
> Rifle et de l'Épée à Énergie, Pistolet à 9 t/s, Grenade à Plasma à 4,50 s, arrondis corrigés.

| # | Arme | Classe | ART/tir | ART/s | Chargeur | Anti-bcl | Malus |
|---|---|---|---|---|---|---|---|
| 1 | Fusil à Plasma | Hybr. Princ./Lég. | 0,125 | 0,4375→0,625 | 250 | — | **×0,80 non protégé** |
| 2 | Pistolet à Plasma | Légère | 0,12 | max **1,08** | 400 | **×1,35** → 1,458 · charge **×5,00** | ×0,75 non protégé |
| 3 | Needler | Légère | 0,12 | 0,96 | 24 | **SC directe aux PV** | — |
| 4 | Répéteur à Plasma | Hybr. Sout./Princ. | 0,076 | 0,684→**0,912** | 380 | — | — |
| 5 | Fusil à Aiguille | Principale | 0,167 | 0,417 | 21 | — | rebond bouclier · **aucun suivi** |
| 6 | Grenadier à Plasma | Soutien | 0,40 | 0,664 | 8 | collage | ×0,66 armures → **1,056** |
| 7 | Focus Rifle | Soutien | 0,088 | 0,88 | 100 % *(2,75 %/s)* | — | **×0,50 protections** |
| 8 | Canon à Combustible | Lourd | 0,95 | **2,09** | 5 | flaque **×2,50** | — |
| 10 | Épée à Énergie | **SPÉCIALE / Princ.** | **1,50 → 2,25** | — | **chauffe 15 / 9,90 / 0** | — | **plus de perforation** |
| 11 | Grenade à Plasma | Lancer | **2,25** | — | 8 | **collage traverse** | — |
| 12 | Tourelle Plasma | Lourd FIXE | 0,109 | **1,199** | 250 | **×1,25** → 1,499 | **×0,50 non protégé** |
| 13 | Grêleur | Lourd FIXE / Lourd | 3×0,13 | 0,682 | 165 / 33 | **SC traverse** | n'explose pas sur bcl |

---

### 6.6 — Écarts arithmétiques — Élites : tous tranchés ✅

| # | Arme | Point | Décision |
|---|---|---|---|
| ~~**J**~~ | **Pistolet à Plasma** | 1,08 vs 0,96 | ✅ **Résolu par le haut** — cadence portée à **9 t/s** *(1,08 ART/s)*, critique bouclier abaissé de ×1,50 à **×1,35** *(0,162/tir)*, surchauffe à **27 tirs** |
| ~~**K**~~ | **Épée à Énergie** | « Illimitée » + 4 taux | ✅ **REWORK** — la batterie devient une **jauge de chauffe** : **+15 % sur la chair**, **+9,90 % sur un bouclier** *(×0,66)*, **0 % sur une armure**. Surchauffe à 100 % ⇒ **10 s de poing américain à 0,50 ART** |
| ~~**L**~~ | **Fusil à Plasma** | Estoc + grille mêlée | ✅ **CLOS (R5)** — le plafond 1,00 ne vaut que sur la base 0,35 ; base modifiée ⇒ **×3,00 sans plafond**. Crit dorsal à l'estoc = **1,95 ART** |
| ~~**M**~~ | **Grenadier** | Malus armure chargé | ✅ **×0,66 → 1,056 ART** |

**Arrondis — corrigés dans les fiches :**

| Arme | Retenu |
|---|---|
| Fusil à Plasma | **0,4375 ART/s** · surchauffe **6,25 s** |
| Canon à Combustible | **2,09 ART/s** |
| Épée à Énergie | **×0,66 conservé** — la lisibilité de « deux tiers » prime sur les 0,01 ART *(1,485 en dual sur la base 2,25 ; 1,00 sur la base 1,50)* |
| Grêleur | **0,5714 s par tir** *(1,75 t/s)* |

---

### 6.7 — Points ouverts Élites

| # | Arme | Décision |
|---|---|---|
| ~~12~~ | **Fusil à Plasma** | ✅ Le plafond ne concerne que la base 0,35. L'estoc part d'une base **0,65** et prend le **×3,00 sans plafond** |
| ~~13~~ | **Fusil à Aiguille** | ✅ **Aucun suivi.** L'arme tient déjà le créneau du DMR de Reach ; suivi **+** Super-Combine l'aurait mise hors barème |
| ~~14~~ | **Grenadier** | ✅ **Tranché par la règle générale §0.11** — l'IA n'utilise **pas** les sous-systèmes, **sauf mention explicite** sur sa fiche d'ennemi |
| ~~15~~ | **Focus Rifle** | ✅ **Portée > 50 m, infinie**, comme le sniper humain — bornée par la seule précision à la lunette |
| ~~16~~ | **Focus Rifle** | ✅ **REWORK complet** — les 12 seuils deviennent **3 zones et un seul bouton** *(X)* |
| ~~18~~ | **Épée à Énergie** | ✅ Movelist renvoyée à une **fiche d'arcade dédiée aux armes de corps à corps** |
| ~~19~~ | **Grenade à Plasma** | ✅ **4,50 s** — détonation **3,50 s**, **1,00 s de marche** |
| ~~20~~ | **Tourelle Plasma** | ✅ **Aucune limite de crit dorsal.** Règle standard : **×3,00 → 4,00 ART**. *« Mais va le placer. »* |
| ~~21~~ | **Zone Plasma** | ✅ Une seule brûlure active, la plus récente remplace *(R3 · §0.3)* |
| ~~22~~ | **Général** | ✅ **La question ne se pose pas** pour les Super-Combines : leurs dégâts **naissent à l'intérieur** de la protection, il n'y a rien à reporter |

⚠️ **La fiche §2.2 et ses deux variantes ont ouvert huit points, 46 à 53. Sept sont clos.**

| # | Sujet | Statut |
|---|---|---|
| ~~46~~ | **Nom de la variante** | ✅ **CLOS — « Véloce »**, pour éviter la collision avec le grade **Élite Ultra** |
| ~~47~~ | **Cadence** | ✅ **CLOS — erratum : 1,08 ART/s.** Le 0,96 était une coquille · cadence **9 t/s** confirmée, l'arbitrage antérieur n'est pas rouvert |
| **48** | **Critique de charge de la base** | Le **0,18** dont dérive le 0,45 vaut **0,12 × 1,50**, soit l'**ancien** multiplicateur. **0,45 retenu comme constante, plus comme calcul.** Ne concerne **que la base** |
| ~~49~~ | **Véloce — champs absents** | ✅ **CLOS par la règle « aucune précision = aucun changement »** — surchauffe **identique à la base** *(27 tirs)* · charge au **même nombre de tirs** *(50)*, soit **11,76 %** sur 425 |
| ~~50~~ | **Brûlure Instable vs bouclier** | ✅ **CLOS dans le sens de la matrice** — la brûlure **traverse les protections**, PV directs |
| ~~51~~ | **« Cinétique » de la Véloce** | ✅ **CLOS — frappe Dynamo sans souffle**, mono-cible. Hors liste fermée du §5.4, **n'éteint rien** ; le tag ne sert qu'au **+0,20 ART du §5.6** |
| ~~52~~ | **Stun contre Yumiko** | ✅ **CLOS — repousse *(état SUBI)* + Wall Splat**, **sans coupure de contrôle**. Punit le Dive, facilite le repli |
| ~~53~~ | **Ordre des opérations §5.6** | ✅ **SANS OBJET** — la charge Véloce n'a **plus aucun multiplicateur**, il n'y a plus deux opérations à ordonner |

---

### 6.8 — Lectures transversales Élites

**Le Covenant a exactement ce qui manque au CSNU, et la symétrie est trop propre pour être un hasard.**
Là où les humains n'ont qu'une arme anti-bouclier, les Élites en alignent **cinq voies distinctes** : le
Pistolet à Plasma *(×1,35 · charge ×5,00)*, la Tourelle *(×1,25)*, le Needler, le Grêleur, et le
**collage** de la Grenade Plasma et du Grenadier, qui ignore purement toute
protection. **Le déséquilibre est inversé** : c'est le joueur humain qui compose avec un déficit
structurel.

C'est le bon choix, à une condition : **que le CSNU garde l'avantage sur le deuxième temps.** C'est le
cas. Une fois les protections tombées, le CSNU frappe la chair sans pénalité pendant que le plasma la
frappe à ×0,50 *(Tourelle)*, ×0,75 *(Pistolet)* ou ×0,80 *(Fusil)*. **D9 est respectée sur les treize
fiches.**

**Le vrai système Covenant n'est pas dans les armes, il est entre elles.**

| Chaîne | Composition | Effet |
|---|---|---|
| **Feu** | Canon à Combustible → Pistolet à Plasma → Focus Rifle | Flaque 4 s → rallumée +6,5 s → critique **×1,75** = 1,54 ART/s |
| **Zone** | Grenade à Plasma → n'importe quel tir plasma | 0,35 ART/s, entretenu — **jamais cumulé** |
| **Pics** | Needler · Fusil à Aiguille · Grêleur | Trois vitesses, trois protections, **trois compétences** |

**La chaîne du Feu reste un système émergent, pas un archétype d'escouade.** Décision de l'auteur, et
elle est cohérente : le feu est un **outil de chaos**. Le figer dans une composition scriptée — un Canon,
un Pistolet, un Focus — reviendrait à l'enseigner comme une leçon, donc à le rendre prévisible. Il vaut
mieux qu'il surgisse des rencontres que le joueur ne comprendra qu'après coup. *(La recommandation
antérieure d'un archétype nommé est retirée.)*

**La famille des pics est complète, et le rework la clarifie encore** :

| | Needler | Fusil à Aiguille | Grêleur |
|---|---|---|---|
| Ce que l'arme facture | **Anticiper** | **Viser** | **Se placer** |
| Suivi | Partiel *(CE)* | **Aucun** | Guidage chaotique |
| SC | 1,25 **aux PV** | 1,25 *(×0,50 armure)* | **1,75 à travers** |
| Létalité de la SC | **Tue presque Yumiko** | — | **Tue jusqu'au Spec-Ops** |
| Fiabilité réelle | Bonne | **Excellente** | **Mauvaise hors des deux bonnes distances** |

**Trois armes, trois monnaies, aucun doublon.** C'est le meilleur travail d'archétype du lot.

**Les zones plasma vont sortir des fiches d'armes.** L'auteur prévoit de les extraire dans une **matrice
dédiée**, après les Brutes et les Forerunner. C'est la bonne décision et elle était inévitable : sept
armes du roster Élite décrivent chacune une zone dont les paramètres se recouvrent — 3,5 s ici, 6 s là,
0,16 de résiduelle d'un côté, 0,22 de l'autre. Ce n'est pas un attribut d'arme, **c'est un système**, et
il gagnera à être décrit une fois. Ce qu'il faudra y porter : durée, envergure, DPS, résiduelle,
générateurs, entretiens, extinctions — et la règle de remplacement de §0.3, qui en est désormais la
clause d'ouverture. **Le zoning est un outil de terrain, pas une source de dégâts** : c'est ce que le
plafond à 0,35 ART/s inscrit noir sur blanc.

**Les menaces mortelles sur Yumiko, révisées après arbitrage** *(solidité totale 2,50 ART)* :

| Menace | ART | Sur 2,50 | Tell |
|---|---|---|---|
| Needler — Super-Combine | **1,25 aux PV + bouclier** | **Tue presque en une fois** | Projectiles **lents et visibles** |
| Grenadier — chargé collé | 2,40 | 0,10 restant | Charge — **réservée aux porteurs nommés** *(§0.11)* |
| Grenade Plasma — collée | 2,25 | 0,25 restant | Trajectoire, 4,50 s |
| Grêleur — 1 Super-Combine | 1,75 | 0,75 restant | **9 pics, rarement réunis** |
| Épée — 2 coups | 1,50 puis 1,875 | **2 coups** *(1 dans le dos)* | Contact |
| **Focus Rifle — Railgun max** | **2,50** | **Mort exacte** | **Sifflement** · 2 s de charge · arme **rare** |

**Un seul changement par rapport à la lecture précédente, et il va vers le haut.**

**La Super-Combine du Needler monte.** Ses 1,25 ART tombent **directement sur les PV** et l'explosion mord
le bouclier en plus. Une seule ne laisse presque rien : la menace se déplace du **cumul** *(deux SC en
2 s)* vers **l'événement unique**, et son garde-fou n'est plus le temps mais la **visibilité du
projectile**.

**Le Railgun, lui, reste à 2,50 — mort exacte, portée infinie.** C'est la menace la plus dure du roster.
Côté arme, les deux verrous sont écrits et suffisent : **2 s de charge** et **sifflement audible**. Le
reste relève de la rencontre, donc pas de ce document.

**Les quatre morts exactes à 2,50 tiennent donc toujours** : Railgun, double Super-Combine, Déchiqueteur
en dual, Grenadier chargé collé à 0,10 près. Le bouclier de Yumiko à 100 % reste **le curseur n° 1 du playtest**.

**Trois morts s'y ajoutent depuis §5.6**, toutes au corps à corps et toutes en dorsal : **lancer de Tourelle Spiker** *(3,15 ART)*, **estoc de Tourelle Plasma sur cible saignée** *(4,60)* et **estoc de Fusil à Plasma sur cible saignée** *(2,55)* — elles **dépassent** 2,50 au lieu de le frôler, mais exigent toutes un dos exposé.

**Toutes les morts Élites sont désormais annoncées.** C'est le point qui compte le plus, et il ressort des
arbitrages plus que d'une intention explicite : chaque menace mortelle porte un **tell** — flare bleu de
la Lance, sifflement du Railgun, lenteur des aiguilles, charge visible du Grenadier. Sur un socle Halo CE
**sans sprint**, où le joueur ne peut pas se retirer d'un engagement par la vitesse pure, c'est la seule
façon honnête de faire mal : **la mort doit être lisible à l'avance, ou elle est arbitraire.** La faction
tient ce contrat sur ses sept menaces. C'est la meilleure nouvelle de ce lot.

**Le déficit CSNU en contrôle de zone reste chiffrable et ouvert.** Sept sources de zone persistante côté
Élites, deux côté CSNU. La compensation existe *(précision, budget de munitions, BR75 / SRS99 / M6D)*,
mais un joueur en chargement 100 % humain n'a toujours **aucun moyen de contester le terrain**. À
reprendre quand la matrice des zones sera écrite.

---

---

### 6.9 — Brutes : vue d'ensemble

| # | Arme | Classe | ART/tir | ART/s | Chargeur | Anti-bcl | Feu |
|---|---|---|---|---|---|---|---|
| 1 | Fusil à Plasma Brute | Hybr. Princ./Sout. | 0,125 | **0,750** | 200 *(27 tirs)* | — | brûlure + **flaque** |
| 2 | Mauler | Légère | **1,00** *(schrapnel)* | **1,33** | 5 | **×1,35** *(armures)* | — |
| 3 | Sabre Grenade | Principale | **0,45** | **0,90** | 6 | — | — |
| 4 | Fusil Électrique | **Principale** | 0,40 | **0,727** | 12 | **×1,50** + IEM | — |
| 5 | Marteau Antigravité | **SPÉCIALE / Sout.** | **2,25** *(3,00 au sol)* | — | 100 | — | **éteint** |
| 6 | Ravageur | Hybr. Sout./Lourd | 3 × 0,45 | **1,472** | 75 | — | brûlure + **mare** |
| 7 | Fusil à Faisceau | Hybr. Sout./Lourd | **1,00** | 3,33 | 32 tirs | — | **estoc + ×1,75** |
| 8 | Déchiqueteur | Soutien | 1,25 · **2,50 dual** | — | 2 | **PERFORATEUR** | **éteint** |
| 9 | Grenade Incendiaire | Lancer | 0,035/tick | **0,70** *(1,05 bcl)* | système | ×1,50 | **surface 4,5 s** |
| 10 | Grenade Dynamo | Lancer | **0,35** | — | système | **×3,00** → 1,05 | **allume** |
| 11 | Tourelle Spiker | **Lourd FIXE** | 0,105 | 0,945 | 180 | — | **incinération** + saignement |

---

### 6.10 — Écarts arithmétiques — Brutes

✅ **Les cinq écarts du lot Brute (O–S) sont clos.** *(U et V sont tombés avec le retrait de la fiche Fusil Électrique.)* Valeurs retenues, qui font foi :

| # | Arme | Point | Valeur arrêtée |
|---|---|---|---|
| **O** | Fusil à Plasma Brute | Malus chair | **×0,80 → 0,100 ART · 0,600 ART/s** — le multiplicateur fait foi, pas le 0,112 |
| **P** | Fusil à Plasma Brute | CAC | **0,55** — base commune ; les valeurs supérieures sont des exceptions par arme |
| **Q** | Mauler | Cadence | **0,75 s · 1,00 ART · 1,33 ART/s** · dual réserve **40** |
| **S bis** | Sabre Grenade | Puissance | **0,45 ART · 2,0 tirs/s → 0,90 ART/s** — le chargeur de 6 sur la même cible vaut **3,5325 ART** |
| **R** | Marteau | Coût des frappes | **7,50 %** *(Mêlée 2)* · **10 %** *(tir)* · Mêlée 1 **gratuite** |
| **S** | Ravageur | Cadence et DPS | cycle **0,917 s** → **1,09 salve/s** → **1,472 ART/s** |

**Méthode retenue pour tout le lot** — la cadence était écrite trois fois par fiche *(secondes, tirs/s, DPS)* et les trois se désynchronisaient. **Une seule valeur fait foi : celle en secondes.** Les deux autres en sont dérivées, jamais saisies à la main.

**Arrondis sans conséquence, laissés tels quels :**

| Arme | Point | Fiche | Calcul |
|---|---|---|---|
| Mauler | Critique « ×3 environ » | 1,00 | ×3 exact = **1,05** *(réel ×2,857)* |
| Fusil à Plasma Brute | Brûlure vs DPS chair | — | **8,3 %** *(0,05 / 0,600)* |

**Fiches sans aucun écart** : Fusil à Faisceau · Déchiqueteur · Grenade Incendiaire · Grenade Dynamo · Tourelle Spiker.

---

### 6.11 — Points ouverts Brutes

✅ **Le lot Brute est intégralement arbitré, et il ne reste rien.** Les décisions sont reportées dans les fiches §3.1–§3.11 ; les questions fermées ne sont pas conservées ici.

**Tranché en fin de passe :**

| # | Portée | Décision |
|---|---|---|
| **43** | Fusil Électrique *(§3.4)* | ✅ **Confirmé par la V2.** Le report est **intégral** — « pas de gaspillage de puissance pour un tir qui finit une protection » — puis le reste prend le **×0,25** de la chair. C'est **D17** appliquée à la lettre, sans exception |
| **44** | Général — saignement | ✅ **Pas de cumul : une RÉ-APPLICATION.** Une cible = une seule plaie active ; une seconde frappe **remet la plaie à sa durée pleine** au lieu d'empiler. Inscrit en **§5.6** comme règle générale |
| **45** | Fusil Électrique — **chiffres dus** *(§3.4)* | ✅ **CLOS.** Cadence, chargeur et réserve fournis et **vérifiés** *(0,40 × 1,82 = 0,727 ✅)*. **Aucune mise en joue, donc aucune lunette** : la question du zoom est **sans objet** |

> **Réserve de conception, sans blocage** — §3.8, la projection du **shot antigrav**. Si elle envoie **en l'air** plutôt qu'horizontalement, elle piège la mobilité HORNET sur une arme de troupier. **Lecture par défaut retenue : répulsion horizontale.**

**Rappel des arbitrages structurants du lot**, pour mémoire :

| Sujet | Décision |
|---|---|
| Ravageur — 4 tirs au but sur 2 salves | **Punition assumée.** Rien ne bride la séquence ; le contre-jeu est de l'empêcher d'aboutir · **allume même sur cible protégée** |
| Fusil à Faisceau — brûlure d'estoc | **Une seule brûlure active.** Plasma **2,50 s · 0,16 ART/s** ; le cumul est supprimé |
| Déchiqueteur — shot antigrav | **Coup de marteau antigrav projeté** · 1,00 ART · une frappe de batterie |
| Marteau Antigravité — classe | **HYBRIDE** — accorde le boost **1,10**, refuse le **dual** *(voir **D16**)* |

---

### 6.12 — Lectures transversales Brutes

**La faction Brute n'est ni un CSNU plus lourd ni un Covenant plus brutal : c'est la faction du feu et de l'inertie.** Sur douze armes, **sept produisent ou manipulent du feu** — Fusil à Plasma Brute (brûlure + flaque), Ravageur (brûlure + mare), Fusil à Faisceau (estoc incendiaire + ×1,75), Grenade Incendiaire (surface + résiduelle), Tourelle Spiker (incinération), Grenade Dynamo (allume le plasma instable), et deux qui **éteignent** (Marteau, Déchiqueteur). Là où les Élites rendaient le terrain *inhabitable* par la zone plasma, les Brutes le rendent inhabitable par **la combustion entretenue** — c'est la même intention, exprimée par un système différent.

**La différence est de nature, et elle est importante pour le level design.** Les zones plasma Élites sont statiques et brèves ; les feux Brutes **se transmettent et s'entretiennent entre armes** — sans jamais se cumuler *(§0.3, R4 : le dernier foyer remplace le précédent)*. Un feu allumé par une Tourelle Spiker peut être entretenu par un Fusil à Plasma Brute, nourri par un Ravageur, exploité au ×1,75 par un Fusil à Faisceau, rallumé par une Dynamo. **Le feu Brute est une ressource collective qui circule dans l'escouade**, pas un effet d'arme. C'est la version Brute de la conscience collective, et elle est mécaniquement plus intégrée que la chaîne du Feu Élite.

**Quatre armes de la faction éteignent le feu, et c'est délibéré** *(§0.9)*. Marteau Antigravité, marteau du Déchiqueteur, Sabre Grenade et Grenade Dynamo soufflent les flammes — au sol comme sur une cible, y compris celles de leurs propres alliés, y compris celles qui brûlent Yumiko. **La faction se contredit elle-même**, ce qui donne au joueur une lecture tactique gratuite : affronter le Chieftain *pendant* qu'on brûle est une bonne idée. Et un marteau ramassé devient un extincteur.

La règle n'est plus propre aux Brutes — **cinq armes sur deux factions** éteignent désormais — mais elle reste la plus signifiante ici, parce que les Brutes sont la seule faction à la fois **incendiaire et explosive**. Elles portent le poison et l'antidote.

---

**Le rapport à la mobilité est le second axe d'identité, et il est inversé par rapport au CSNU.**

| Faction | Rapport à la mobilité du joueur |
|---|---|
| **CSNU** | Le budget de **munitions** limite le joueur — la puissance se paie en rareté |
| **Élites** | La **zone** limite le joueur — la puissance se paie en placement |
| **Brutes** | La **fenêtre** limite le joueur — la puissance se paie en **temps** |

Presque toutes les armes Brutes ont une fenêtre courte suivie d'une pénalité longue : Fusil à Plasma Brute (4 s puis 5 s), Fusil à Faisceau (3 tirs puis 6,5 s **sans voie rapide**), Marteau (une frappe puis 10 s de recharge), Déchiqueteur (2 cartouches puis rechargement). **La faction Brute joue en pics.** Contre un joueur mobile, cela crée le bon rythme : encaisser le pic, puis exploiter le creux. C'est le profil ennemi le plus compatible avec HORNET des trois, parce qu'il **récompense explicitement le déplacement à contretemps** plutôt que le déplacement continu.

**L'exception est le Ravageur, et c'est ce qui en fait l'arme la plus dangereuse de la faction contre Yumiko.** Sa mare se forme aux pieds de la cible *même si elle a bougé*, dès lors que **4 projectiles sur 6 ont porté** — elle s'allume **même sur une cible encore protégée**, et le Plasma Instable **passe le bouclier** *(§5.1)*. **La mobilité ne protège pas de cette arme** — seule la précision du tireur compte. Sur une sandbox construite autour du mouvement, c'est la seule arme des quarante transcrites qui annule frontalement le système du joueur. À surveiller de très près : soit c'est le contre-jeu voulu à HORNET, soit c'est une faille.

---

**Le compte anti-bouclier est maintenant complet, et D9 tient sur quarante-trois fiches.**

| Porteur nommé D9 | Multiplicateur | Malus chair |
|---|---|---|
| Pistolet à Plasma chargé *(Élite)* | ×5,00 → 2,25 | ×0,75 |
| **Fusil Électrique** *(Brute)* | ×1,50 + IEM 0,35 | **×0,25** |
| **Grenade Dynamo** *(Brute)* | ×3,00 → 1,05 | 0,35 seulement |

**Deux des trois porteurs sont Brutes.** C'est cohérent avec une faction qui arrive en troisième position et doit rester menaçante face à un joueur déjà équipé. Et la règle « qui frappe le bouclier fort frappe la chair faible » est **respectée partout, sans exception**. Le malus ×0,75 du Pistolet ne paie pas son ×1,35 : il paie une **amplitude de ×3,60** que la fiche ne contrôle pas, puisque son DPS dépend de la vitesse de clic. **La règle taxe l'amplitude autant que le multiplicateur.**

**Le Fusil Électrique a été refondu en arme d'assaut** *(§3.4)* — le pendant Brute du **MA5B** et du **Répéteur à Plasma**. L'ancienne fiche empilait quatre systèmes dont deux invisibles ; la V2 n'a plus qu'**un compteur de 1 à 4** sur cible non protégée, et ses verrous sont **spatiaux et rythmiques** : bande utile de 12,50 à 25 m, **0,55 s entre deux tirs**, 12 coups au chargeur. **Les trois armes d'assaut du jeu ont le même DPS brut et des angles morts opposés** — MA5B puni sur les boucliers, Répéteur neutre, Électrique excellent sur les boucliers et cinq fois moins bon sur la chair nue. **Fiche complète et vérifiée.**

---

**Les menaces mortelles sur Yumiko, roster Brute** *(solidité 2,50 ART)* :

| Menace | ART | Sur 2,50 |
|---|---|---|
| **Sabre Grenade** — chargeur de 6 sur la même cible | **3,53** | **×1,41 — mort** |
| **Fusil à Faisceau** — 2 headshots *(0,30 s)* | **3,00** | **×1,2 — mort** |
| **Fusil à Faisceau** — 3 tirs au corps | **3,00** | **Mort** |
| **Marteau Antigravité** — frappe au sol *(Mêlée 2)* | **3,00** | **Mort** |
| **Mauler** — dual sur cible blindée *(×1,35)* | **2,70** | **Mort** |
| **Déchiqueteur** — tir dual | **2,50** | **Mort exacte** |
| Marteau Antigravité — frappe simple | 2,25 | 0,25 restant |
| Mauler — dual, cible non blindée | 2,00 | 0,50 restant |

**Six menaces mortelles chez les Brutes, contre trois chez les Élites.** La progression de difficulté entre factions est nette et voulue. Mais **la nature des menaces change**, et c'est là que le design est bon : les trois morts Élites venaient de la distance ou du projectile guidé *(Railgun à portée infinie, Needler en 2 s)*. **Cinq des six morts Brutes exigent le contact ou la quasi-portée** — le Mauler à 5 m, le Déchiqueteur à 12 m, le Marteau à 5 m, le Sabre à 20 m avec six coups au but. **Seul le Fusil à Faisceau tue de loin.**

**Le rework du lot a déplacé la tête du classement.** Le Sabre Grenade passe de 2,62 à **3,53** et devient la menace la plus lourde de la faction — mais c'est aussi la plus conditionnelle du roster entier : **six détonations au but, en 3,0 s, sur une cible que le tireur projette lui-même à chaque coup.** Le Mauler entre dans la table par une porte nouvelle, le bonus **×1,35 contre les armures** : deux tirs simultanés valent 2,70 sur Yumiko blindée, contre 2,00 sans protection. **La seule menace Brute qui monte quand le joueur s'équipe mieux.**

Conséquence : **la mobilité HORNET est une réponse valable au roster Brute**, alors qu'elle ne l'était pas contre les Élites. Sortir de 12 m est possible ; sortir de 150 ne l'est pas. C'est une bonne courbe — la faction la plus létale est aussi celle contre laquelle le système du joueur fonctionne le mieux, ce qui récompense la maîtrise acquise sur les deux premières factions.

**Le Déchiqueteur en tir dual est la quatrième mort exacte à 2,50 relevée sur quarante-trois fiches**, après le Railgun du Focus Rifle, la double Super-Combine du Needler et — à 0,10 près — le Grenadier chargé collé. **Quatre coïncidences au centième ne sont plus des coïncidences** : la sandbox converge d'elle-même vers « 2,50 = un engagement réussi ». Cela renforce ce que je disais après les fiches Élites — **le bouclier de Yumiko à 100 % est le paramètre le plus sensible du projet**, et le passer à 1,50 ferait basculer huit lignes sur les deux tableaux de menaces.

---

**Ce que la faction Brute apporte au joueur, et pas seulement contre lui.**

Trois armes Brutes règlent des problèmes signalés dans les lectures précédentes :

- **La Grenade Incendiaire** comble le déficit de contrôle de zone du CSNU. Le joueur exclusivement humain n'avait aucun moyen de contester le terrain face à sept sources de zone Covenant ; il en a maintenant une, sur un emplacement de grenade, donc sans coût d'arme. **C'est le problème de composition le plus sérieux relevé jusqu'ici, et il est résolu.**
- **Le Ravageur et son mode focus** donnent au joueur une arme qui contourne les angles — la première réponse au jeu de couverture ennemi.
- **Le Marteau** offre à Yumiko une auto-extinction, donc une réponse aux sept sources de feu de la faction qui le porte.

**La faction du feu fournit elle-même l'extincteur, la faction de la zone fournit l'arme anti-couverture.** Sur un jeu où le joueur ramasse en permanence l'armement ennemi, c'est la bonne façon de doser : chaque faction apporte sa propre contre-mesure, à condition d'accepter d'utiliser ses outils.

---

### 6.13 — Forerunner : vue d'ensemble

| # | Arme | Classe | ART/tir | ART/s | Portée efficace | Chargeur | Spécificité | Feu |
|---|---|---|---|---|---|---|---|---|
| 1 | Sentinel Beam | Principale | 0,022 | **0,66** *(0,89 armure)* | **20 m** | 100 batt. *(13,33 s)* | **×1,35 armures** · **recharge** les boucliers non conventionnels | **LUMIÈRE 0,550** — allumage **12,50 % batt.** |
| 2 | Heatwave | Principale | **0,88** *(8 × 0,11)* | **1,76** | **H 3–10 m · V 5–25 m** | 8 / 32 | **2 modes** · détonation de zone · crit **×2,5** | **0,21/s · 3,5 s** |
| 3 | Cindershot | Soutien | **1,376** *(0,50 + 3 × 0,167 + brûlure 0,375)* | **1,334** | **8–20 m** | 5 / 20 | **Cluster guidé** — contourne les couverts | **Brûlure 0,15/s · 2,5 s** · allume la Flash |
| 4 | Flash | Grenades | **0,45** *(crit bcl **1,35**)* | — | lancer | système | **Aveugle tout le monde** · détonable | **LUMIÈRE 0,550** — **PV même protégés, sauf bouclier** |

---

### 6.14 — Écarts arithmétiques — Forerunner

**✅ Les quatre écarts sont tranchés. Le lot est clos.**

| # | Arme | Point | Arbitrage rendu |
|---|---|---|---|
| **W** | **Sentinel Beam** | Consommation | **0,25 % par tir → 7,50 %/s.** Batterie = **13,33 s**, **400 tirs**, **8,80 ART** délivrables. L'hypothèse à 15 %/s est écartée |
| **X** | **Sentinel Beam** | Feu | **12,50 % de batterie *(50 tirs)* pour allumer**, brûlure de **type LUMIÈRE** — 0,11 ART/s × 5,00 s = **0,550 ART** *(§5.1)*. Plus de valeur propre à la fiche |
| **Z** | **Flash** | Critique bouclier | **1,35 ART** — le **×3 exact** est conservé, aligné sur la Grenade Dynamo |
| — | **Flash** | Munition solide | **0,45 à l'explosion**, puis **brûlure LUMIÈRE directement sur les PV même protégés — sauf bouclier** |

**Précision de l'auteur — l'arrondi au millième n'est pas requis.** La précision actuelle est suffisamment
lisible ; les écarts de troisième décimale *(type Cindershot 0,6665 vs 0,66)* **ne sont plus relevés**.

**Fiches sans aucun écart** : Heatwave.

---

### 6.15 — Points ouverts Forerunner

**✅ Lot Forerunner soldé — aucun point ouvert ne subsiste.**

| # | Arme | Arbitrage rendu |
|---|---|---|
| **35** | **Heatwave** | ✅ **CLOS — portée variable selon le mode.** **Vertical 5–25 m** *(viser devient difficile au-delà)* · **Horizontal 3–10 m** *(la ligne de 8 unités s'étale, les dégâts deviennent risibles)*. Seule arme du roster dont le mode déplace la portée. La comparaison avec le Mauler tombe : ils ne se disputent que **3–5 m**. |
| **38** | **Sentinel Beam** | ✅ **CLOS — hors périmètre.** Il ne s'agit pas d'un type « lumière » à généraliser : **certains ennemis de fin de jeu portent un bouclier énergétique non conventionnel, et c'est voulu**. Ces unités demandent encore beaucoup de travail en amont. **Ne plus s'occuper du type lumière pour le moment** — rien à verser dans `base-de-travail.md`. |
| **39** | **Général** | ✅ **CLOS — le tableau existe déjà.** C'est **§5.7 — « Table de synthèse : quoi fait quoi à quoi »**, livrée avec la matrice des effets, donc **antérieure** à ce point ouvert. La demande était déjà satisfaite au moment où elle a été posée. |
| **40** | **Flash** | ✅ **CLOS — pas de liste fermée.** Le déclenchement est ouvert aux **armes Forerunner en général**, **et à certaines armes de type incendiaire**. Le critère faisant autorité est **la matrice des effets** *(§5.2, ligne LUMIÈRE)*, pas une liste de munitions qualifiantes. |
| **42** | **Flash** | ✅ **CLOS — déjà écrit.** Le comportement est spécifié en **§5.2** *(ligne Flash)* et dans la fiche **§4.4**. Rien à ajouter côté armes. |

---

### 6.16 — Lectures transversales Forerunner

**La faction Forerunner est la faction de la lumière solide, et sa singularité mécanique n'est pas la puissance — c'est le fait qu'elle ne se comporte pas comme les trois autres face aux protections.**

Sur quatre armes, **une seule est anti-bouclier** *(le Flash, ×3 à l'explosion)*. Le Sentinel Beam est **anti-armure** — le premier de la sandbox, avec un ×1,35 qui ne s'applique ni au bouclier ni à la chair. Le Heatwave critique à la tête. Le Cindershot ne critique nulle part. **Après quarante fiches presque toutes construites autour du bouclier, les Forerunner déplacent la question sur l'armure**, ce qui rend la faction lisible immédiatement : contre eux, ce n'est pas le décapage qui compte.

**Le Sentinel Beam pose le seul cas d'arme du projet dont l'effet s'inverse selon la cible.** Il **recharge** les **boucliers énergétiques non conventionnels** de certains ennemis de fin de jeu, au lieu de les détruire. Aucune des quarante armes précédentes n'a d'effet inverse — il y avait des malus, des immunités partielles, jamais un renversement. Trois conséquences : le joueur qui ramasse un Beam et tire sur une Sentinelle **la répare** ; l'arme change de valeur **selon l'ennemi et non selon la situation**, ce qui est un axe d'équilibrage neuf ; et il existe des **boucliers énergétiques non conventionnels**, portés par certains **ennemis de fin de jeu** — c'est assumé, et **hors périmètre tant que ces unités ne sont pas traitées** *(point 38, clos)*.

---

**Le Flash est la fiche la plus importante de la faction, et elle résout rétroactivement huit références semées dans les lots précédents.**

Depuis les Brutes, quatre armes étaient créditées de « peut mettre le feu aux Flash » sans qu'on sache de quoi il s'agissait : Grenade Incendiaire, Tourelle Spiker, Sentinel Beam, Heatwave. **Un Flash est une grenade aveuglante qui devient une bombe incendiaire si on lui tire dessus.** Mécanique en deux temps, deux armes, potentiellement deux porteurs.

**C'est la meilleure coopération d'escouade du projet, et elle dépasse ce que font les trois autres factions**, pour une raison précise : l'objet intermédiaire est **visible, statique et neutre**. La chaîne du Feu Élite exigeait trois porteurs coordonnés dans le temps ; le duo Dynamo + Fusil Électrique exige une fenêtre de 2,50 s d'entretien. Le Flash, lui, **attend au sol que quelqu'un le déclenche** — n'importe qui, y compris le joueur, y compris avec une arme d'une autre faction. **C'est le premier objet du jeu qui appartient à celui qui réagit le plus vite.** Je le tiens pour le meilleur candidat à un moment de gameplay signature.

Et l'aveuglement frappe **le lanceur et ses alliés**, ce qui est la clause qui rend l'objet honnête. Aucune arme précédente ne se retournait contre son porteur. Cela donne un vecteur direct à la couche de conscience collective : un Grognard paniqué jette son Flash n'importe où et aveugle son escouade ; un gradé le place. **Le même objet mesure la compétence de l'unité qui l'utilise.**

---

**Le rapport à la couverture est le second apport de la faction, et il faut le regarder à l'échelle des quatre factions réunies.**

Le Cindershot est la **deuxième** arme du jeu qui contourne les angles, après le Ravageur, et les deux le font différemment : le Ravageur demande de piloter ses projectiles *(compétence active, coûteuse en attention)*, le Cindershot demande seulement de **tirer à côté** *(lecture du terrain)*. L'un récompense l'habileté, l'autre l'intelligence de placement.

Sur un socle Halo CE **sans sprint**, où la couverture est la ressource principale du joueur, **deux armes ennemies qui l'invalident est une décision lourde.** Je ne crois pas que ce soit un problème — sans elles, le joueur se plante derrière un mur et le combat s'arrête. Mais ces deux armes **doivent être télégraphiées** : un son, une traînée, une silhouette de projectile qui annonce le contournement. Sinon le joueur meurt derrière sa couverture sans comprendre ce qui l'a touché, et c'est le pire type de mort dans un jeu de tir.

---

**Le feu devient une ressource inter-factions, et c'est le Heatwave qui referme la boucle.**

Il entretient « n'importe quel feu plasma ou classique » **et** peut être entretenu par des tirs de plasma. Traduction : une escouade mixte Brute + Forerunner maintient un feu **indéfiniment**, chacune rechargeant le cooldown de l'autre. Ce que j'avais identifié chez les Brutes comme « une ressource collective qui circule dans l'escouade » **dépasse maintenant le cadre d'une faction.** C'est un argument mécanique — et pas seulement narratif — pour faire combattre les deux ensemble.

Le revers était un besoin de documentation : **cinq sources de feu réparties sur trois factions, avec des tables de pénétration différentes.** **Ce tableau existe : c'est §5.7**, livré avec la matrice des effets — donc **antérieur au point qui le réclamait** *(point 39, clos sans travail)*. Les deux feux Forerunner y figurent avec leurs comportements opposés : le Beam **entretient et allume en Lumière**, le Flash porte **directement sur les PV même protégés, sauf bouclier**.

Le seuil d'incendie du Heatwave mérite d'être isolé comme **la meilleure idée de calibrage des quatre fiches** : 16 unités sur 3 tirs, alors que 3 tirs en délivrent 24. **Le seuil est à 66,7 % de précision** — ce n'est pas un compteur de tirs, c'est un compteur de justesse. Un joueur qui arrose n'allume pas ; un joueur qui place ses gerbes allume. Sur une arme à dispersion, c'est la façon la plus élégante de récompenser la précision sans imposer de headshot, et je n'ai vu ce mécanisme nulle part dans les quarante fiches précédentes.

---

**Les menaces mortelles sur Yumiko, roster Forerunner** *(solidité 2,50 ART)* :

| Menace | ART | Sur 2,50 |
|---|---|---|
| **Cindershot** — chargeur de 5 | **5,005** | Mort ×2 |
| **Heatwave** — 8 unités toutes en crit *(théorique)* | 2,20 | 0,30 restant |
| Heatwave — 2 tirs pleins | 1,76 | 0,74 restant |
| **Flash détoné** — crit bouclier + brûlure *(cible nue)* | **1,00** *(0,45 + 0,550)* | 1,50 restant |
| Flash détoné — **sur bouclier** | **1,35** | 1,15 restant — *aucun PV touché* |

**Une seule menace mortelle, et elle est conditionnelle** — le Cindershot exige cinq tirs placés à 8–20 m sans être interrompu. **C'est le roster le moins létal des quatre**, ce qui est le bon choix pour une faction d'appoint : elle complique le combat sans le trancher.

Comparaison des quatre lots :

| Faction | Fiches | Menaces mortelles | Nature de la contrainte |
|---|---|---|---|
| CSNU | **16** | *(armes du joueur)* | **Munitions** — la puissance se paie en rareté |
| Élites | **12** | **3** | **Zone** — la puissance se paie en placement |
| Brutes | 12 | **6** | **Fenêtre** — la puissance se paie en temps |
| **Forerunner** | **4** | **1** | **Durée d'exposition** — la puissance se paie en tenue de ligne |

**La courbe est bonne.** Les Brutes sont le pic de létalité, les Forerunner redescendent — mais ils redescendent en apportant des mécaniques *(inversion d'effet, objet détonable, contournement automatique)* plutôt que des chiffres. **Une quatrième faction qui surenchérirait en dégâts n'aurait rien à dire ; celle-ci change les règles à la place.** C'est le bon rôle pour un appoint.

---


### 6.17 — Synthèse des quatre factions

**43 armes transcrites, contrôlées, consolidées et arbitrées.** Vingt-trois écarts arithmétiques **tous tranchés** *(T, U et V sont sans objet depuis le retrait de deux fiches)*, aucun chiffre inventé — les deux écarts que l'auteur n'a pas comblés sont **signalés en clair** dans les fiches concernées.

| Lot | Fiches | Écarts | Statut des écarts | Points ouverts |
|---|---|---|---|---|
| CSNU | **16** | **A–I** *(9)* | clos | — |
| Covenant / Élites | **12** | **J–N** *(5)* | clos | ⚠️ **1** *(48 — §2.2)* |
| Brutes | **11** | **O–S** *(5)* | **clos** | **—** |
| **Forerunner** | **4** | **W–Z** *(4)* | **clos** | **—** |
| **Total** | **43** | **23** | **tous clos** | ⚠️ **1** |

> **✅ Les vingt-trois écarts arithmétiques restent tranchés.** La fiche **§2.2** et ses deux variantes
> ont ouvert **huit points, 46 à 53** : **sept sont clos**. **Un seul subsiste sur tout le roster** — le
> **48**, le critique de charge de 0,18 dont dérive le 0,45, retenu comme **constante** faute d'être
> dérivable. Il est **relevé, pas comblé** — §0.7.
> Tout ce qui touchait aux **unités porteuses, aux comportements et au
> directeur d'IA** est sorti de ce document : ce n'est pas le sujet ici, et ce sera traité en temps voulu
> dans `comportement-de-l-ennemi.md`.

**Les quatre doctrines de faction sont distinctes et ne se recouvrent pas** :

- **CSNU** — la puissance se paie en **munitions**. Les cinq armes les plus fortes ont les cinq plus petites réserves.
- **Élites** — la puissance se paie en **placement**. Sept sources de zone rendent le terrain inhabitable.
- **Brutes** — la puissance se paie en **temps**. Fenêtres courtes, pénalités longues, jeu en pics.
- **Forerunner** — la puissance se paie en **exposition**. Rayons continus, seuils cumulatifs, objets à déclencher.

**Trois constats transversaux tiennent sur les quarante-trois fiches** :

**① D9 tient partout, et elle n'a plus une seule exception.** Chaque arme anti-bouclier paie sur la chair — Tourelle ×0,50, Pistolet ×0,75, Fusil Brute ×0,80, Fusil Électrique ×0,25. La seule fiche qui y échappait est **sortie du roster**. La doctrine est désormais sans trou : **qui frappe fort le bouclier frappe faible la chair**, sur les quarante-trois fiches.

**② La sandbox converge vers 2,50 ART.** Quatre morts exactes à la solidité totale de Yumiko : Railgun du Focus Rifle, double Super-Combine du Needler, Déchiqueteur en dual, et à 0,10 près le Grenadier chargé collé. **Quatre coïncidences au centième ne sont plus des coïncidences.** ⚠️ **Trois s'ajoutent depuis §5.6, toutes au corps à corps et toutes en dorsal** : **lancer de Tourelle Spiker** *(3,15 ART)*, **estoc de Tourelle Plasma sur cible saignée** *(4,60)* et **estoc de Fusil à Plasma sur cible saignée** *(2,55)*. Contrairement aux quatre autres, elles **dépassent** 2,50 au lieu de le frôler — mais elles exigent toutes un dos exposé. Le bouclier à 100 % reste le curseur n° 1 du playtest : le passer à 1,50 ferait basculer une dizaine de lignes sur les trois tableaux de menaces.

**③ Le feu est devenu un système à part entière, et personne ne l'a décidé.** Il a émergé fiche par fiche : brûlures Brutes, flaques, mares, incinération, feux Forerunner, Flash détonables. **Huit armes l'allument** *(le Crémator rejoint la liste)*, **cinq l'éteignent** *(§5.4)*, **quatre l'entretiennent, et les tables de pénétration diffèrent d'une source à l'autre.** C'est devenu la mécanique la plus transversale du projet et **la seule qui n'ait pas de document dédié.** Je recommande de lui en donner un.
