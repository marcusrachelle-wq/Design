#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
arcade-yumiko.py — Matrice de l'arcade complète de Yumiko

Socle de calcul du personnage jouable : ressources, paliers d'inertie, virage,
échelle de mêlée, économie du boost, catalogue des mouvements et des combos.

Source de vérité rédigée : arcade-yumiko.md
Doctrine et matrice des unités : base-de-travail.md
Chiffres d'armes : equilibrage-sandbox-armes.md
Comportements ennemis : comportement-de-l-ennemi.md

Unité : ART (puissance d'arrêt). Vitesse : 1.00 = marche Halo CE.
Hauteur : 1.00 unité = 1 hauteur de Spartan ≈ 2,25 m.

Usage :  python3 arcade-yumiko.py
         python3 arcade-yumiko.py --conflits
"""

from dataclasses import dataclass, field
from typing import Optional, List, Dict

# =============================================================================
# 0. CONSTANTES GLOBALES
# =============================================================================

ART_REFERENCE   = 1.00   # bouclier Spartan de référence
MELEE_REFERENCE = 0.35   # mêlée de base (D14)
CRIT_DORSAL_MUL = 3.00   # multiplicateur du critique dans le dos
CRIT_DORSAL_CAP  = 1.00  # plafond du critique dorsal — VALABLE UNIQUEMENT sur la base 0.35
CRIT_DORSAL_MULT = 3.00  # multiplicateur dorsal ; fixe et SANS plafond si la base != 0.35
MELEE_BASE       = 0.35  # seule base soumise au plafond (D14 révisée, arbitrage R5)

VITESSE_MARCHE  = 1.00   # référence Halo CE
HAUTEUR_SAUT    = 1.00   # 1 hauteur de Spartan
METRES_PAR_UNITE = 2.25  # conversion approximative

CRANS_AFFICHES  = 10
CRANS_REELS     = 15     # 2 crans cachés (n°5 et n°8), les rouges valent double


# =============================================================================
# 1. RESSOURCES
# =============================================================================

@dataclass(frozen=True)
class Difficulte:
    nom: str
    cran: float          # ART par cran effectif
    mult_bouclier: float # multiplicateur appliqué au bouclier
    regen_passive_palier: bool = False
    note: str = ""

    @property
    def pv(self) -> float:
        return round(self.cran * CRANS_REELS, 3)

    @property
    def bouclier(self) -> float:
        return round(ART_REFERENCE * self.mult_bouclier, 3)

    @property
    def total(self) -> float:
        return round(self.pv + self.bouclier, 3)


DIFFICULTES: Dict[str, Difficulte] = {
    "legendaire": Difficulte("Légendaire", 0.100, 1.00,
        note="Référence de l'équilibrage"),
    "heroique":   Difficulte("Héroïque", 0.100, 1.00,
        note="Chiffres identiques au Légendaire : l'écart vient de l'IA et des vagues"),
    "normal":     Difficulte("Normal", 0.135, 1.35),
    "facile":     Difficulte("Facile", 0.150, 1.50, regen_passive_palier=True,
        note="Régén passive par palier (rouge, jaune, bleu)"),
}

# --- Piste de vie : états affichés -> crans effectifs -------------------------
# Cran caché n°5 : les 5 restants passent de bleu à jaune
# Cran caché n°8 : les 3 jaunes restants passent au rouge
# Les crans rouges valent DOUBLE.
PISTE_DE_VIE = [
    ("10 crans bleus",  15),
    ("6 crans bleus",   11),
    ("6 crans jaunes",  10),
    ("3 crans jaunes",   7),
    ("3 crans rouges",   6),
    ("Mort",             0),
]

# --- Récupération des PV ------------------------------------------------------
RECUPERATION_PV = [
    ("Chip régen",         "Régénère le cran ENTAMÉ, celui-là seulement", "invisible"),
    ("Kit de soin partiel","Régénère le palier en cours (rouge, jaune OU bleu)", "explicite"),
    ("Pack de soin",       "Régénère tous les crans perdus, instantanément", "explicite"),
]

# --- Boosters -----------------------------------------------------------------
BOOST_MAX = 100.0                 # %
BOOST_COOLDOWN = 2.0              # s sans utilisation avant recharge

RECHARGE_BOOST = {
    "passif":            0.50,    # %/s, à l'arrêt
    "marche":            3.00,    # %/s, conversion cinétique à plein potentiel
    "post_bouclier":    10.00,    # %/s, après régénération du bouclier
}

# Consommation du booster maintenu en continu : courbe progressive par seconde
BOOST_CONTINU = [8.00, 10.50, 15.00]   # %/s aux secondes 1, 2, 3

# Conversion bouclier -> boost (provisoire, susceptible d'être retouché)
CONVERSION_BOUCLIER_PAR_BOOST = 10.0   # 10 % de bouclier pour 1 % de boost

# --- Armement, grenades, équipements -----------------------------------------
ARMES_PORTEES = 2          # une équipée, une rangée (Y pour changer)
GRENADES_MAX = 8           # 2 par type et par emplacement
GRENADES_TYPES_EQUIPES = 2 # emplacement gauche + emplacement droit
SOINS_MAX = 2

ORDRE_GRENADES = ["Fragmentation", "Plasma", "Incendiaire", "Dynamo", "Flash"]

EQUIPEMENTS = {
    "gauche": "Consommable  (Gauche + X)",
    "droite": "Équipement d'armure  (Droite + X)",
}

# --- Chute --------------------------------------------------------------------
CHUTE_SEUIL           = 3.00    # unités : premier dégât
CHUTE_PCT_BOUCLIER    = 0.015   # 1 % de bouclier par tranche de 0.015 unité
CHUTE_UNITE_PAR_CRAN  = 0.15    # 1 cran par 0.15 unité, sans bouclier


# =============================================================================
# 2. PALIERS D'INERTIE / CHARGE SPARTANE
# =============================================================================

@dataclass(frozen=True)
class Palier:
    niveau: int
    nom: str
    vitesse: float
    mult_bouclier: float      # cinétique : réduit les dégâts reçus
    cout_boost: float         # %/s
    duree_max: Optional[float]
    angle_oblique: Optional[float]   # ° par rapport à la ligne de course
    pivot_neutre: Optional[float]    # °/s
    pivot_interne: Optional[float]   # °/s (compense 2 pas de sous-virage sur 3)
    pivot_externe: Optional[float]   # °/s (se laisse déporter)

    def bouclier(self, diff: Difficulte) -> float:
        return round(diff.bouclier * self.mult_bouclier, 3)

    def total(self, diff: Difficulte, over_brs: bool = False) -> float:
        t = self.bouclier(diff) + diff.pv
        if over_brs:
            t += BRS["over_bouclier_pct"] / 100 * ART_REFERENCE
        return round(t, 3)


PALIERS: Dict[int, Palier] = {
    0: Palier(0, "Marche",          1.00, 1.00, 0.00, None, None, None,  None, None),
    1: Palier(1, "Charge",          1.10, 1.35, 0.00,  5.0, 35.0, 60.0,  47.5, 85.0),
    2: Palier(2, "Charge maximale", 1.25, 1.75, 1.50, None, 15.0, 47.5,  35.0, 65.0),
}

# ⚠ Conflit relevé : le coût du Palier 2 est donné à 2.00 %/s dans le tableau des
# paliers et à 1.50 %/s dans la section « maintien ». Valeur retenue : 1.50.
PALIER2_COUT_ALTERNATIF = 2.00

SUIVIRAGE_PAS = 3          # pas de compensation du sous-virage en virage
INERTIE_PAS   = 2          # pas d'accélération / décélération au sol

VITESSE_ENTREE_CHARGE = 0.75   # vitesse minimale pour entrer directement en Palier 1
VITESSE_MIN_WALLJUMP  = 0.85


# =============================================================================
# 3. VITESSES ET AÉRIEN
# =============================================================================

VITESSE_AERIENNE_MAX = 1.35    # ⚠ conflit : Palier 2 (1.25) + wall jump (+0.25) = 1.50
AERIEN_DECEL_DUREE   = 4.0     # s pour redescendre à 1.35, sans consommer de boost

WALLJUMP_BONUS_VITESSE = 0.25
WALLJUMP_BONUS_HAUTEUR = 0.25
WALLJUMP_ANGLE_MAX     = 35.0  # ° de réajustement sans perte de vitesse

IMPULSION_HAUTE_BONUS_HAUTEUR = 0.25
BRS_SAUT_HAUTEUR   = 1.25
BRS_SAUT_HORIZONTAL = 1.35     # Wall Breaker Stance : BRS + A depuis un mur

# Angles de débattement
ANGLE_VISEE_CHARGE   = 105.0   # ° périphériques de chaque côté, en charge + LT
ANGLE_REDIR_SLIDE    = 80.0    # ° de chaque côté, redirection depuis slide
ANGLE_CANCEL_SLIDE   = 105.0   # ° reprise de charge depuis cancel de slide
ANGLE_COMBO_IMPULSION = 75.0   # ° réajustement slide -> impulsion


# =============================================================================
# 4. ÉCHELLE DE MÊLÉE
# =============================================================================

@dataclass(frozen=True)
class Melee:
    nom: str
    art: float
    condition: str
    effet: str = ""
    cout_boost: float = 0.0

    def coups_pour(self, pv: float) -> int:
        import math
        return math.ceil(pv / self.art) if self.art > 0 else 0


ECHELLE_MELEE: List[Melee] = [
    Melee("Leg Breaker",            0.20, "slide + Mêlée",
          "stun dédié, n'interrompt pas le slide", cout_boost=4.5),
    Melee("Mêlée de base",          0.35, "toute posture", "référence D14"),
    Melee("Demi-tour frappe",       0.35, "tap stick arrière + Mêlée",
          "wall splat / stun arrière — hors Hunters, hors Dévots"),
    Melee("Emplafonnement",         0.50, "vitesse 1.01–1.10 (Palier 1)",
          "WALL SPLAT même sur cible protégée"),
    Melee("Bastonneur",             0.50, "direction 22.5°–67.5° + Mêlée",
          "stun si non protégé — Yumiko atterrit DOS à la cible"),
    Melee("Uppercut",               0.50, "(accroupi) se relever OU sauter + Mêlée",
          "wall splat ; drain 35 % de bouclier sur cible équipée"),
    Melee("Emplafonnement crit.",   0.65, "vitesse ≥ 1.11 (Palier 2)",
          "wall splat sur cible protégée"),
    Melee("Bastonneur crit.",       0.65, "vitesse ≥ 1.10",
          "stun — atterrit DOS à la cible"),
    Melee("Uppercut critique",      0.65, "se relever → sauter + Mêlée",
          "stun + wall splat + saut de hauteur normale"),
    Melee("Leg Breaker critique",   0.65, "slide + Mêlée, conditions critiques",
          "GRATUIT — ne consomme aucun boost", cout_boost=0.0),
    Melee("Break Upper critique",   0.65, "BRS + A + Mêlée 2", "donne l'over-boost"),
    Melee("Mêlée aérienne",         0.80, "en l'air, vitesse > 1.25",
          "au-delà du plafond du Palier 2"),
    Melee("Critique dorsal",        1.00, "frappe dans le dos (base 0.35)",
          "×3 plafonné à 1.00 sur la base 0.35 uniquement — "
          "toute autre base prend ×3.00 fixe SANS plafond ; "
          "TRAVERSE bouclier, armure et blindage"),
]

# Paliers de vitesse qui modifient silencieusement la puissance des coups
SEUILS_VITESSE_MELEE = [
    (1.01, 0.50, "Emplafonnement / Bastonneur passent à 0.50"),
    (1.10, 0.65, "Bastonneur devient critique"),
    (1.11, 0.65, "Emplafonnement devient critique"),
    (1.25, 0.80, "Mêlée aérienne au-delà du Palier 2"),
]

MELEE_CAC_MULT_LEGBREAKER = 1.35   # Leg Breaker armes de CAC : Mêlée 1 de l'arme × 1.35
UPPERCUT_DRAIN_BOUCLIER   = 35.0   # % drainés sur cible équipée


# =============================================================================
# 5. BREAK STANCE (BRS)
# =============================================================================

BRS = {
    "duree":               0.75,   # s
    "over_bouclier_pct":  35.0,    # passif 1, 1 fois par retour au neutre
    "over_boost_pct":     25.0,    # passif 2, sur BRS+B, BRS+A, BRS+Mêlée 1
    "cancel_gain_boost":   4.5,    # BRS + B
    "jump_cout_boost":     4.5,    # BRS + A
    "jump_hauteur":        1.25,
    "impulsion_cout_bouclier_pct": 35.0,
    "impulsion_rayon_m":   2.50,
}

FORCAGE = {
    "cout": "intégralité du bouclier, over-bouclier compris",
    "conversion": "1 % de boost pour 10 % de bouclier",
    "regen": 10.00,        # %/s, sans cooldown
    "invulnerabilite": 0.50,
    "effet": "repousse comme la grenade à impulsion, sans l'EMP critique",
}


# =============================================================================
# 6. CATALOGUE DES MOUVEMENTS
# =============================================================================

@dataclass(frozen=True)
class Mouvement:
    nom: str
    entree: str
    posture: str          # sol / charge / air / slide / brs / cac
    effet: str
    art: Optional[float] = None
    cout_boost: Optional[float] = None
    note: str = ""


MOUVEMENTS: List[Mouvement] = [
    # --- Sol -----------------------------------------------------------------
    Mouvement("Marche", "stick gauche", "sol",
              "vitesse 1.00, 2 pas d'accélération et de décélération"),
    Mouvement("Straff", "tap LB + stick latéral", "sol",
              "change de direction en 1 seul pas, straff à 1.00"),
    Mouvement("Accélération instantanée", "LB + avant, vitesse < 0.75", "sol",
              "1 seul pas vers la vitesse normale"),

    # --- Charge --------------------------------------------------------------
    Mouvement("Entrée Palier 1", "LB + avant, vitesse ≥ 0.75", "charge",
              "propulse la course à 1.10", cout_boost=0.0),
    Mouvement("Entrée Palier 2", "maintenir LB", "charge",
              "2 pas d'accélération supplémentaires -> 1.25", cout_boost=1.50),
    Mouvement("Course oblique", "palier + stick latéral", "charge",
              "P1 : 35° · P2 : 15° par rapport à la ligne de course"),
    Mouvement("Virage", "palier + stick droit latéral", "charge",
              "P1 : 60°/s · P2 : 47.5°/s — indépendant de la sensibilité"),
    Mouvement("Compensation interne", "virage + stick gauche intérieur", "charge",
              "compense 2 pas de sous-virage sur 3, réduit le pivot"),
    Mouvement("Compensation externe", "virage + stick gauche extérieur", "charge",
              "augmente le sous-virage, accélère fortement le pivot"),
    Mouvement("DRIFT", "interne -> externe", "charge",
              "posture basse, esquive les tirs hauts ; perd 1 palier après 120°",
              note="demi-tour rapide, virage en épingle"),
    Mouvement("IMPULSION de virage", "externe -> interne", "charge",
              "se projette à l'intérieur du virage, prend l'angle immédiatement"),
    Mouvement("Freinage", "palier + stick arrière", "charge",
              "retour à 1.00 ; tap = −2 paliers, redirection possible en straff"),
    Mouvement("Emplafonnement", "palier + Mêlée", "charge",
              "wall splat même sur cible protégée", art=0.50),
    Mouvement("Emplafonnement crit.", "vitesse ≥ 1.11 + Mêlée", "charge",
              "wall splat sur cible protégée", art=0.65),
    Mouvement("Bastonneur", "direction 22.5°–67.5° + Mêlée", "charge",
              "décalage latéral, atterrit DOS à la cible", art=0.50),
    Mouvement("Pas-chassé", "direction 35°–125° + B", "charge",
              "esquive les coups hauts, accélère le straff, casse le lock-on",
              note="recovery annulable ; Yumiko compte comme accroupie"),
    Mouvement("Visée en charge", "LT", "charge",
              f"cône périphérique de {ANGLE_VISEE_CHARGE}° de chaque côté"),

    # --- Air -----------------------------------------------------------------
    Mouvement("Saut", "A", "air", f"hauteur 1.00 (≈ {METRES_PAR_UNITE} m)"),
    Mouvement("Impulsion aérienne", "AIR + LB + direction", "air",
              "accélération aérienne ; plafond 1.35, décélération libre en 4 s"),
    Mouvement("Freinage aérien total", "saut à 1.25 + LB arrière frame 1", "air",
              "réduit la vitesse à 0 à la retombée"),
    Mouvement("Impulsion haute", "direction + LB + A", "air",
              "+0.25 de hauteur en conservant le momentum"),
    Mouvement("Wall Jump", "en l'air, mur + A", "air",
              "+0.25 vitesse, +0.25 hauteur ; min 0.85, réajustement 35°",
              note="effet « transmission »"),
    Mouvement("Wall Breaker Stance", "en l'air, mur + B", "air",
              f"BRS au mur ; BRS+A à l'horizontale, vitesse {BRS_SAUT_HORIZONTAL}"),
    Mouvement("Mêlée aérienne", "air > 1.25 + Mêlée", "air",
              "puissance portée à 0.80", art=0.80),

    # --- Slide ---------------------------------------------------------------
    Mouvement("Arrêt brutal", "charge (inertie ≥ 1) + B", "slide",
              "glisse au sol ; cancellable par le stick gauche"),
    Mouvement("Impulsion en course", "course + LB + X", "slide",
              "slide raccourci puis forçage booster ; plus long vers l'avant"),
    Mouvement("Sortie saut", "A depuis slide", "slide",
              "conserve le momentum d'inertie restant"),
    Mouvement("Sortie uppercut", "A + Mêlée", "slide", "uppercut", art=0.50),
    Mouvement("Redirection", "stick droit puis LB", "slide",
              f"{ANGLE_REDIR_SLIDE}° de chaque côté ; 1 s = retour à 1.10"),
    Mouvement("Mêlée basse", "Mêlée depuis slide", "slide",
              "pied glissant ; reprend la MARCHE, jamais la charge (sauf arrière)"),
    Mouvement("Leg Breaker", "slide + Mêlée", "slide",
              "stun dédié, n'interrompt pas le slide", art=0.20, cout_boost=4.5),
    Mouvement("Leg Breaker crit.", "slide + Mêlée, conditions critiques", "slide",
              "GRATUIT", art=0.65, cout_boost=0.0),
    Mouvement("Leg Breaker CAC", "slide + Mêlée 2, arme de CAC", "slide",
              f"dégâts Mêlée 1 de l'arme × {MELEE_CAC_MULT_LEGBREAKER}", cout_boost=0.0),
    Mouvement("Slide -> Impulsion", "slide + LB", "slide",
              f"ré-accélère, réajustement −{ANGLE_COMBO_IMPULSION}° à +{ANGLE_COMBO_IMPULSION}°"),
    Mouvement("Cancel accroupi", "ne rien faire", "slide",
              "fin de recovery accroupie — enchaîne sur uppercut"),

    # --- Forçage -------------------------------------------------------------
    Mouvement("Forçage-Boosters", "LB + X", "sol",
              "consomme tout le bouclier -> +10 % boost, régén 10 %/s sans cooldown",
              cout_boost=-10.0,
              note="0.50 s d'invulnérabilité + repoussée type grenade à impulsion"),
    Mouvement("Direct Break Stance", "LB + X puis B (dans les 0.50 s)", "brs",
              "consomme 100 % du bouclier mais PAS l'over-bouclier BRS",
              note="calibration du risque, high skill ceiling"),

    # --- BRS -----------------------------------------------------------------
    Mouvement("BREAK STANCE", "B (contextuel)", "brs",
              f"{BRS['duree']} s · over-bouclier +{BRS['over_bouclier_pct']} % · "
              f"over-boost +{BRS['over_boost_pct']} %"),
    Mouvement("BRS Cancel", "BRS + B", "brs",
              "retour au neutre, conserve l'over-bouclier", cout_boost=-4.5),
    Mouvement("BRS Demi-tour", "BRS + stick gauche arrière", "brs",
              "vise derrière, reste accroupie ; Mêlée pour le coup en demi-tour"),
    Mouvement("BRS Dash-Cancel", "BRS + stick + LB", "brs",
              "sortie par impulsion, reprise à 1.00 dès les premières frames"),
    Mouvement("BRS Jump Cancel", "BRS + A", "brs",
              f"saut à {BRS_SAUT_HAUTEUR} ; rend l'uppercut CRITIQUE", cout_boost=4.5),
    Mouvement("BRS Impulsion", "BRS + Mêlée 1", "brs",
              f"onde de choc {BRS['impulsion_rayon_m']} m, coût {BRS['impulsion_cout_bouclier_pct']} % "
              "de bouclier ; pas d'IEM critique", art=0.35),
    Mouvement("Break Uppercut", "BRS + Mêlée 2", "brs",
              "consomme l'over-bouclier au-delà de 100 %, régén boost instantanée",
              art=0.50),
    Mouvement("BRS Impulsion crit.", "BRS + A + Mêlée 1", "brs",
              "saute en infligeant l'impulsion, donne l'over-boost", art=0.35),
    Mouvement("Break Upper crit.", "BRS + A + Mêlée 2", "brs",
              "over-boost + puissance portée à 0.65", art=0.65),

    # --- CAC -----------------------------------------------------------------
    Mouvement("Parade", "Mêlée 1, 2 ou 1+2", "cac",
              "dévie l'attaque d'un ennemi armé au CAC, retour au neutre",
              note="1+2 : recovery avec frames d'avance = avantage à l'attaque"),
]


# =============================================================================
# 7. COMBOS
# =============================================================================

@dataclass(frozen=True)
class Combo:
    nom: str
    sequence: List[str]
    art_total: float
    cout_boost: float
    note: str = ""


COMBOS: List[Combo] = [
    Combo("Combo signature", ["Bastonneur crit. (0.65)", "Demi-tour frappe (0.35)"],
          1.00, 0.0,
          "Le Bastonneur laisse Yumiko DOS à la cible — 1.00 ART = chair d'un Elite Minor"),
    Combo("Pas-chassé -> Bastonneur", ["Pas-chassé", "Bastonneur crit. (0.65)"],
          0.65, 0.0,
          "Le pas-chassé rend le Bastonneur critique via impulsion latérale"),
    Combo("Slide -> Leg Breaker -> BRS", ["Leg Breaker (0.20)", "BRS", "BRS demi-tour"],
          0.20, 4.5,
          "Stun puis repositionnement arrière ; viser au stick droit depuis la BRS"),
    Combo("Boucle BRS neutre", ["BRS + B (+4.5 %)", "BRS + A (−4.5 %)"],
          0.0, 0.0,
          "Le cancel rend exactement ce que le jump cancel consomme"),
    Combo("Uppercut critique par BRS", ["BRS + A (jump cancel)", "Uppercut (0.65)"],
          0.65, 4.5,
          "Le jump cancel donne l'effet critique à l'uppercut"),
    Combo("Drift -> demi-tour", ["Drift interne-externe", "Demi-tour frappe (0.35)"],
          0.35, 0.0,
          "Épingle à 120°, perd 1 palier d'inertie ; wall splat arrière"),
    Combo("Forçage temporisateur", ["LB + X (0.5 s invuln.)", "B -> Direct BRS"],
          0.0, -10.0,
          "Invulnérabilité + repoussée, puis over-bouclier BRS conservé"),
    Combo("Enchaînement aérien", ["Wall Jump (+0.25)", "AIR + LB", "Mêlée aérienne (0.80)"],
          0.80, 0.0,
          "Nécessite de dépasser 1.25 — voir le conflit de plafond aérien"),
    Combo("Crit dorsal + Bastonneur", ["Critique dorsal (1.00)", "Bastonneur crit. (0.65)"],
          1.65, 0.0,
          "Tue en chair : Furtif, Minor, Apprenti Ultra, Major"),
]


# =============================================================================
# 8. MATRICE DES UNITÉS (rappel — source : base-de-travail.md)
# =============================================================================

UNITES = {
    # nom                 : (bouclier, chair, casque)
    "Elite Furtif":        (0.00, 1.50, 0.00),
    "Elite Minor":         (1.00, 1.00, 0.00),
    "Disciple Dévot":      (0.00, 2.25, 0.00),
    "Apprenti Ultra":      (1.25, 1.50, 0.00),
    "Elite Major":         (2.00, 1.25, 0.00),
    "Spec-Ops":            (2.00, 1.75, 0.00),
    "Ultra":               (2.75, 2.50, 0.75),
    "Dévot":               (3.50, 2.25, 0.75),   # casque ANTI-PERFORATION
    "Général":             (6.00, 2.50, 1.25),
}


def solidite(unite: str) -> float:
    """Solidité totale d'une unité, casque compris."""
    return round(sum(UNITES[unite]), 2)


# =============================================================================
# 9. CONFLITS DE VALEURS À TRANCHER
# =============================================================================

CONFLITS = [
    ("Coût du Palier 2",
     "1.50 %/s (section maintien) vs 2.00 %/s (tableau des paliers)",
     "1.50 retenu",
     "50 s vs 66.7 s de course sur barre pleine"),
    ("Plafond de vitesse aérienne",
     "1.35 annoncé, mais Palier 2 (1.25) + wall jump (+0.25) = 1.50",
     "à trancher — signalé par l'auteur comme à fixer",
     "1.35 est le seuil qui débloque la mêlée aérienne à 0.80"),
    ("Recharge nominale des boosters",
     "R3 donnait 2.50 %/s ; §5 donne 0.50 passif et 3.00 en marchant",
     "R3 probablement caduque",
     "40 s vs 200 s vs 33 s pour une barre pleine"),
    ("Cooldown avant régén du boost",
     "2.0 s (§5) vs 1.5 s (mention du Break Uppercut)",
     "à trancher",
     "écart de 0.5 s sur une fenêtre de combo"),
]


# =============================================================================
# 10. FONCTIONS D'INTERROGATION
# =============================================================================

def budget_survie(palier: int = 0, difficulte: str = "legendaire",
                  over_brs: bool = False) -> float:
    """Budget de survie total en ART."""
    return PALIERS[palier].total(DIFFICULTES[difficulte], over_brs)


def temps_pivot(palier: int, angle: float, compensation: str = "neutre") -> float:
    """Temps en secondes pour pivoter d'un angle donné."""
    p = PALIERS[palier]
    vit = {"neutre": p.pivot_neutre, "interne": p.pivot_interne,
           "externe": p.pivot_externe}[compensation]
    if not vit:
        return float("nan")
    return round(angle / vit, 3)


def cout_boost_continu(secondes: float) -> float:
    """Coût cumulé d'un maintien du booster, courbe progressive."""
    total, reste = 0.0, secondes
    for i, taux in enumerate(BOOST_CONTINU):
        if reste <= 0:
            break
        tranche = min(1.0, reste)
        total += taux * tranche
        reste -= tranche
    if reste > 0:                       # au-delà de 3 s : dernier taux maintenu
        total += BOOST_CONTINU[-1] * reste
    return round(total, 2)


def duree_charge_p2(boost: float = BOOST_MAX, cout: Optional[float] = None) -> float:
    """Durée de course en Palier 2 pour un stock de boost donné."""
    c = cout if cout is not None else PALIERS[2].cout_boost
    return round(boost / c, 1)


def temps_recharge(pct: float, mode: str = "marche") -> float:
    """Temps pour récupérer un pourcentage de boost."""
    return round(pct / RECHARGE_BOOST[mode], 1)


def boost_depuis_bouclier(pct_bouclier: float) -> float:
    """Conversion bouclier -> boost."""
    return round(pct_bouclier / CONVERSION_BOUCLIER_PAR_BOOST, 2)


def melee_a_vitesse(vitesse: float, coup: str = "bastonneur") -> float:
    """Puissance d'un coup selon la vitesse courante."""
    if coup == "bastonneur":
        return 0.65 if vitesse >= 1.10 else 0.50
    if coup == "emplafonnement":
        if vitesse >= 1.11:
            return 0.65
        return 0.50 if vitesse >= 1.01 else 0.0
    if coup == "aerienne":
        return 0.80 if vitesse > 1.25 else MELEE_REFERENCE
    return MELEE_REFERENCE


def coups_pour_tuer(unite: str, art_coup: float, ignore_bouclier: bool = False) -> int:
    """Nombre de coups de mêlée pour abattre une unité."""
    import math
    bcl, chair, casque = UNITES[unite]
    total = chair if ignore_bouclier else bcl + chair + casque
    return math.ceil(total / art_coup)


def degats_chute(hauteur: float, bouclier_plein: bool = True) -> Dict[str, float]:
    """Dégâts d'une chute, en % de bouclier et en crans de vie."""
    if hauteur <= CHUTE_SEUIL:
        return {"bouclier_pct": 0.0, "crans": 0, "metres": hauteur * METRES_PAR_UNITE}
    exces = hauteur - CHUTE_SEUIL
    if bouclier_plein:
        pct = min(100.0, exces / CHUTE_PCT_BOUCLIER)
        reste = max(0.0, hauteur - (CHUTE_SEUIL + 100 * CHUTE_PCT_BOUCLIER))
    else:
        pct, reste = 0.0, exces
    return {
        "bouclier_pct": round(pct, 1),
        "crans": int(reste / CHUTE_UNITE_PAR_CRAN),
        "metres": round(hauteur * METRES_PAR_UNITE, 2),
    }


def trouver(nom: str) -> List[Mouvement]:
    """Recherche un mouvement par sous-chaîne."""
    n = nom.lower()
    return [m for m in MOUVEMENTS
            if n in m.nom.lower() or n in m.entree.lower() or n in m.posture.lower()]


# =============================================================================
# 11. SORTIES
# =============================================================================

def _sep(titre: str) -> None:
    print(f"\n{'=' * 78}\n  {titre}\n{'=' * 78}")


def table_ressources() -> None:
    _sep("RESSOURCES — piste de vie et difficultés")
    print(f"{'État affiché':<18}{'Crans eff.':>11}{'ART':>8}{'Segment':>10}")
    print("-" * 78)
    prev = None
    for nom, eff in PISTE_DE_VIE:
        art = eff * DIFFICULTES["legendaire"].cran
        seg = "—" if prev is None else f"{(prev - eff) * 0.10:.2f}"
        print(f"{nom:<18}{eff:>11}{art:>8.2f}{seg:>10}")
        prev = eff
    print(f"\n  Le dernier segment (3 rouges -> mort) vaut 0.60 ART, "
          f"soit 40 % de la barre.")

    print(f"\n{'Difficulté':<14}{'Cran':>8}{'PV':>8}{'Bouclier':>10}{'Total':>9}   Note")
    print("-" * 78)
    for d in DIFFICULTES.values():
        note = d.note or ("+ régén passive" if d.regen_passive_palier else "")
        print(f"{d.nom:<14}{d.cran:>8.3f}{d.pv:>8.3f}{d.bouclier:>10.2f}"
              f"{d.total:>9.3f}   {note}")

    print(f"\n  Récupération des PV :")
    for nom, effet, vis in RECUPERATION_PV:
        print(f"    · {nom:<22} {effet}  [{vis}]")


def table_paliers() -> None:
    _sep("PALIERS D'INERTIE — Charge Spartane")
    d = DIFFICULTES["legendaire"]
    print(f"{'Palier':<18}{'Vit.':>7}{'Bcl':>8}{'Total':>8}{'vs P0':>8}"
          f"{'Boost':>9}{'Durée':>9}")
    print("-" * 78)
    base = PALIERS[0].total(d)
    for p in PALIERS.values():
        duree = "illimitée" if p.duree_max is None else f"{p.duree_max:.0f} s"
        if p.niveau == 0:
            duree = "—"
        print(f"{p.nom:<18}{p.vitesse:>7.2f}{p.bouclier(d):>8.2f}{p.total(d):>8.2f}"
              f"{p.total(d)/base:>7.2f}x{p.cout_boost:>8.2f}%{duree:>9}")

    print(f"\n  Avec over-bouclier BRS (+{BRS['over_bouclier_pct']:.0f} %) :")
    for p in PALIERS.values():
        print(f"    {p.nom:<18} {p.total(d, over_brs=True):.2f} ART")

    print(f"\n  Repères sur la matrice des unités :")
    for nom in UNITES:
        tot = solidite(nom)
        print(f"    {nom:<18}{tot:>6.2f}   vs P0 {tot/PALIERS[0].total(d):>5.2f}x"
              f"   vs P2 {tot/PALIERS[2].total(d):>5.2f}x")


def table_virage() -> None:
    _sep("VIRAGE — temps de pivot (s)")
    print(f"{'Configuration':<28}{'45°':>9}{'90°':>9}{'120°':>9}{'180°':>9}")
    print("-" * 78)
    for niv in (1, 2):
        for comp in ("interne", "neutre", "externe"):
            vals = [temps_pivot(niv, a, comp) for a in (45, 90, 120, 180)]
            vit = {"neutre": PALIERS[niv].pivot_neutre,
                   "interne": PALIERS[niv].pivot_interne,
                   "externe": PALIERS[niv].pivot_externe}[comp]
            lab = f"Palier {niv} — {comp} ({vit:g}°/s)"
            print(f"{lab:<28}" + "".join(f"{v:>8.2f}s" for v in vals))
    print(f"\n  Sous-virage compensé en {SUIVIRAGE_PAS} pas · "
          f"vitesse angulaire indépendante de la sensibilité.")
    print(f"  Obliques : Palier 1 = {PALIERS[1].angle_oblique:g}° · "
          f"Palier 2 = {PALIERS[2].angle_oblique:g}°")


def table_melee() -> None:
    _sep("ÉCHELLE DE MÊLÉE")
    print(f"{'ART':>6}  {'Coup':<24}{'Condition':<34}{'Boost':>7}")
    print("-" * 78)
    for m in sorted(ECHELLE_MELEE, key=lambda x: x.art):
        cb = f"{m.cout_boost:.1f}%" if m.cout_boost else "—"
        print(f"{m.art:>6.2f}  {m.nom:<24}{m.condition:<34}{cb:>7}")

    print(f"\n  Seuils de vitesse qui modifient la puissance :")
    for v, art, txt in SEUILS_VITESSE_MELEE:
        print(f"    ≥ {v:.2f}  ->  {art:.2f} ART   {txt}")

    print(f"\n  Coups pour tuer, EN CHAIR (bouclier déjà tombé) :")
    coups = [0.35, 0.50, 0.65, 0.80, 1.00]
    print(f"  {'Unité':<18}" + "".join(f"{c:>8.2f}" for c in coups))
    print("  " + "-" * 62)
    for nom in UNITES:
        ligne = "".join(f"{coups_pour_tuer(nom, c, True):>8}" for c in coups)
        print(f"  {nom:<18}{ligne}")


def table_boost() -> None:
    _sep("ÉCONOMIE DU BOOST")
    print("  Consommation du maintien (courbe progressive) :")
    cum = 0.0
    for i, t in enumerate(BOOST_CONTINU, 1):
        cum += t
        print(f"    seconde {i} : {t:>6.2f} %/s    cumul {cum:>6.2f} %")
    print(f"    -> 3 s de booster continu = {cum:.1f} % de la barre")
    print(f"    -> impulsion de 0.25 s    = {cout_boost_continu(0.25):.2f} %"
          f"  ({BOOST_MAX/cout_boost_continu(0.25):.0f} impulsions sur barre pleine)")

    print(f"\n  Recharge :")
    for mode, taux in RECHARGE_BOOST.items():
        print(f"    {mode:<16}{taux:>7.2f} %/s   barre pleine en "
              f"{BOOST_MAX/taux:>6.1f} s")
    print(f"    cooldown avant recharge : {BOOST_COOLDOWN} s")

    print(f"\n  Sources de boost :")
    print(f"    BRS + B (cancel)         +{BRS['cancel_gain_boost']:.1f} %   GÉNÈRE")
    print(f"    Over-boost BRS          +{BRS['over_boost_pct']:.1f} %   1 fois par neutre")
    print(f"    Forçage LB+X            +{boost_depuis_bouclier(100):.1f} %   "
          f"bouclier plein, + régén {FORCAGE['regen']:.0f} %/s sans cooldown")
    print(f"    BRS + A (jump cancel)    -{BRS['jump_cout_boost']:.1f} %")
    print(f"    Leg Breaker              -4.5 %   (critique : GRATUIT)")
    print(f"    -> boucle BRS+B / BRS+A = NEUTRE")
    print(f"    -> cumul théorique max  = "
          f"{boost_depuis_bouclier(100) + BRS['cancel_gain_boost'] + BRS['over_boost_pct']:.1f} %")

    print(f"\n  Charge Palier 2 :")
    print(f"    à {PALIERS[2].cout_boost:.2f} %/s  ->  {duree_charge_p2():.1f} s de course")
    print(f"    à {PALIER2_COUT_ALTERNATIF:.2f} %/s  ->  "
          f"{duree_charge_p2(cout=PALIER2_COUT_ALTERNATIF):.1f} s   (valeur alternative)")


def table_chute() -> None:
    _sep("CHUTE")
    print(f"{'Hauteur':>9}{'Mètres':>10}{'Bouclier':>11}{'Crans':>8}   Repère")
    print("-" * 78)
    reperes = {3.00: "premier dégât", 4.50: "bouclier vidé",
               5.25: "mort sans bouclier", 6.75: "mort avec bouclier plein"}
    for h in (1.00, 2.00, 3.00, 4.00, 4.50, 5.25, 6.00, 6.75):
        d = degats_chute(h)
        print(f"{h:>9.2f}{d['metres']:>10.2f}{d['bouclier_pct']:>10.1f}%"
              f"{d['crans']:>8}   {reperes.get(h, '')}")


def table_mouvements() -> None:
    _sep("CATALOGUE DES MOUVEMENTS")
    print("  Convention boost : valeur POSITIVE = consomme · NÉGATIVE = génère")
    for posture in ("sol", "charge", "air", "slide", "brs", "cac"):
        lot = [m for m in MOUVEMENTS if m.posture == posture]
        print(f"\n  --- {posture.upper()} ({len(lot)}) " + "-" * (60 - len(posture)))
        for m in lot:
            art = f"{m.art:.2f}" if m.art is not None else "—"
            cb = f"{m.cout_boost:+.1f}%" if m.cout_boost else "—"
            print(f"    {m.nom:<24}{m.entree:<34}{art:>6}{cb:>8}")
    print(f"\n  Total : {len(MOUVEMENTS)} mouvements répertoriés.")


def table_combos() -> None:
    _sep("COMBOS")
    for c in COMBOS:
        print(f"\n  {c.nom}   [{c.art_total:.2f} ART, boost {c.cout_boost:+.1f} %]")
        print(f"    {'  ->  '.join(c.sequence)}")
        if c.note:
            print(f"    {c.note}")


def table_conflits() -> None:
    _sep("CONFLITS DE VALEURS À TRANCHER")
    for i, (nom, desc, statut, impact) in enumerate(CONFLITS, 1):
        print(f"\n  {i}. {nom}")
        print(f"     {desc}")
        print(f"     statut : {statut}")
        print(f"     impact : {impact}")


def main() -> None:
    import sys
    print("ARCADE DE YUMIKO — matrice complète")
    print(f"Unité : ART · mêlée de référence {MELEE_REFERENCE:.2f} · "
          f"marche {VITESSE_MARCHE:.2f} · saut {HAUTEUR_SAUT:.2f} "
          f"(≈ {METRES_PAR_UNITE} m)")

    if "--conflits" in sys.argv:
        table_conflits()
        return

    table_ressources()
    table_paliers()
    table_virage()
    table_melee()
    table_boost()
    table_chute()
    table_mouvements()
    table_combos()
    table_conflits()


if __name__ == "__main__":
    main()
