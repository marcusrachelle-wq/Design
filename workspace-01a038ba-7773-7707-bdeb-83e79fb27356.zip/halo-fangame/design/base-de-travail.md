# Base de travail
**Projet :** Fangame Halo — Spartane **Yumiko**, système de mobilité *Hornet*
**Périmètre :** doctrine, conventions de lecture, unités de référence, notes de sandbox et d'IA
**Statut :** socle commun. Les chiffres d'armes vivent dans `equilibrage-sandbox-armes.md`,
le système du personnage dans `arcade-yumiko.md`.

---

## Doctrine générale de la sandbox

Principes déduits des arbitrages successifs. Ils servent de test pour toute décision future :
si un ajout les contredit, c'est qu'il faut soit le refuser, soit amender la doctrine — jamais l'ignorer.

| # | Principe | Origine | Statut |
|---|---|---|---|
| D1 | **Les protections sont des serrures, pas des barres de vie** — boucliers **et armures**, en règle générale | Structure clés/serrures de la matrice | ✅ Acté |
| D2 | **La fraction de chargeur est l'unité de rythme** — **uniquement pour les armes de précision légères** *(classe BR / Fusil à Aiguille)* | Standard 1/3 revendiqué | ✅ Acté |
| D3 | **Le DPS brut est toujours la voie la plus lente** | Ratios × 9,6 du bypass M319 | ✅ Acté |
| D4 | **Pas de régénération des PV** — seul le bouclier revient. Exception : **chip régen** du cran entamé, invisible à l'interface | Arbitrage du 19/08 | ✅ Acté |
| D5 | **L'inertie est une ressource défensive ET offensive** — elle rend Yumiko difficile à viser, donc permet de **continuer à infliger** DPS et effets en pleine bataille | Paliers d'inertie → bonus bouclier | ✅ Acté |
| D6 | **La difficulté passe par τ, jamais par les dégâts** | Table de survie du Spartan | ⏳ À valider en playtest |
| D7 | **Les armes Covenant sont combinatoires, les CSNU autonomes** — **tendance, pas absolu** : les armes Covenant restent utilisables seules | Zone plasma, ESTOC | ✅ Acté *(règle poreuse)* |
| D8 | **Pas de DMR principal coup par coup** | Arbitrage du 19/08 (anti-Reach) | ✅ Acté |
| D9 | **Le plasma n'est plus anti-bouclier** — il devient du DPS franc sur PV et armure | Arbitrage du 19/08 | ✅ Acté |
| D10 | **Pas de sprint** — la vitesse ne s'active pas, elle se pilote | Socle Halo CE | ✅ Acté |
| D11 | **Le triangle est Tir – Mobilité Hornet – Mêlée** | Arbitrage du 19/08 | ✅ Acté |
| D12 | **La grenade est une arme à équiper**, intégrée au sommet Tir — gestion poussée | Arbitrage du 19/08 | ✅ Acté |
| D13 | **Les PV se soignent par kits** — kit partiel (un palier) ou pack (tout) ; jamais passivement au-delà du cran entamé | Socle Halo CE + D4 | ✅ Acté |
| D14 | **La mêlée dans le dos est un critique** — ×3 **traversant les protections**. Le plafond **1,00 ART ne vaut que pour la mêlée de base (0,35)** ou une base assimilée ; **si la base diffère de 0,35, le multiplicateur devient ×3,00 fixe appliqué à cette nouvelle base, sans plafond** | Socle Halo CE · révisé R5 | ✅ Acté |
| D15 | **Aucun sommet du triangle n'est optionnel** — les ennemis sont tanky, la couverture est compromise | Arbitrage du 19/08 | ✅ Acté |
| D16 | **Deux verrous d'arme spéciale distincts** — interdiction de port *ou* pénalité de mobilité ; jamais déduire l'un de l'autre | Synthèse des 7 fiches concernées | ✅ Acté *(détail ci-dessous)* |
| D17 | **La part reportée est soumise au malus de ce qu'elle touche** — le report est intégral en quantité, puis **le régime normal de l'arme contre la nouvelle cible s'applique**. Sans malus, report strict | Arbitrage du 24/08 *(Fusil Électrique)* | ✅ Acté |
| D18 | **Les effets de durée ne cumulent jamais : ils se ré-appliquent** — feu, saignement, zones. Une cible = un effet actif ; une nouvelle source **remet la durée à plein** au lieu d'empiler | Arbitrage du 24/08 *(saignement)* + §5.0 | ✅ Acté |


### D9 — Le plasma cesse d'être la clé du bouclier

L'équation canonique « plasma = bouclier » est **supprimée**. Elle est remplacée par une répartition
explicite : l'anti-bouclier devient un rôle **attribué arme par arme**, indépendant du type d'énergie.

| Point | Règle |
|---|---|
| Tirs à plasma | **Plus d'effet anti-bouclier**, **pas de critique** sur bouclier |
| Contrepartie | Fonction de **DPS classique** applicable aux **PV** et à l'**armure** |
| Malus | **Aucun** — les armes à plasma ne sont pas pénalisées sur cet axe |

**Porteurs du rôle anti-bouclier :**

| Arme | Faction | Note |
|---|---|---|
| Pistolet à Plasma *(tir chargé)* | Covenant – Élites | Le tir chargé se comprend comme une **charge « Dynamo »** |
| Fusil Électrique | Brutes | ×1,50 bouclier · **×0,25** chair — V2 |
| Grenade Dynamo | Brutes | Boucliers + désactivation de véhicules |

> **Conséquence de lisibilité :** le joueur ne peut plus déduire la clé de la couleur du tir.
> Il doit l'identifier arme par arme. Le retour visuel du décapage de bouclier doit donc être
> **très net** — c'est le seul canal par lequel la règle se reconstruit à l'usage.

### D10–D15 — le socle Halo CE et le triangle

Le jeu reprend d'Halo CE : le **feeling lourd des armes**, l'**absence de sprint**, les **escouades
nettes**, l'alternance **fermeture ↔ ouverture** des niveaux (avec phases en véhicules), les **PV
limités soignés par kits**, les **coups de crosse sans auto-dash**, le **sang**, et les **sauts hauts
et flottants**.

Gabarit du personnage : **saut de 1,00 m**, pieds portés à **2,15 m**. C'est l'échelle verticale de
référence pour tout le level design.

**D14 — le critique de mêlée.** La mêlée dans le dos ne tue pas d'office : le multiplicateur est
**×3,00**. Le critique **traverse les protections** : bouclier, armure et blindage ne l'arrêtent pas.

**Le plafond de 1,00 ART ne vaut que sur la base de 0,35** (0,35 × 3 = 1,05 → **1,00**). Dès que la
base est modifiée par une arme, une posture ou un effet, le **×3,00 s'applique sans plafond**. Une
Mêlée 2 de Sabre Grenade à 0,8775 vaut donc **2,6325 dans le dos**, et non 1,00. Le plafond borne la
mêlée nue, pas les coups spéciaux.

**Le triangle d'or est réorganisé** en **Tir (gestion des grenades incluse) – Mobilité Hornet –
Mêlée (coups spéciaux incorporés)**, là où Bungie posait tir – grenades – mêlée. La grenade est
**une arme à équiper**, pas un consommable réflexe — voir `arcade-yumiko.md`.

**D15 — le triangle est obligatoire.** Les ennemis sont tanky comparés au joueur, leurs salves font
mal, et dès l'héroïque leurs formations laissent peu de répit. La couverture est souvent compromise ;
l'encaissement passe par la mobilité (esquive réelle **et** scaling des dégâts reçus) ; la mêlée sert
aux enchaînements et à la reprise de tir, pas seulement à achever.

> Conséquence directe sur l'équilibrage : **aucune arme ne doit se régler contre un joueur qui sprinte,
> qui campe, ou qui reste à couvert.** Elle se règle contre un joueur qui corrige son vecteur sous le feu.
> C'est le seul état par défaut.

### D16 — les deux verrous d'arme spéciale

Une arme lourde ou encombrante restreint le port d'une **arme SPÉCIALE** — en pratique, la **Lance
Spartane** et les armes de CAC signature. Il n'existe **pas une règle unique** : deux verrous distincts
coexistent, et **chaque fiche déclare lequel elle porte**. Ne jamais déduire l'un de l'autre.

| Verrou | Effet | Armes concernées |
|---|---|---|
| **Interdiction de port** | Maniabilité **non pénalisée**, mais **aucune arme spéciale** — donc pas d'ambidextrie avec une arme de CAC spéciale | **SRS99C S2** *(§1.9)* · **M319 IGL** *(§1.12)* · **Lance-Flammes** *(§1.13)* · **Ravageur** *(§3.6)* · **Fusil à Faisceau** *(§3.7)* |
| **Pénalité de mobilité** | L'arme spéciale **reste portable**, mais le **duo ambidextre** coûte de la mobilité | **MA5B** *(§1.2)* · **Répéteur à Plasma** *(§2.4)* |

**Deux exceptions nommées**, et elles sont volontaires :

- **Laser Spartan M6** — arme Lourde qui **gagne** à être portée avec la Lance Spartane : la recharge
  cinétique du laser se nourrit des mêlées. Le mariage est récompensé au lieu d'être interdit.
- **Marteau Antigravité** *(§3.5)* — classé **HYBRIDE** : il **accorde** le boost de marche à **1,10**
  comme une arme spéciale, tout en refusant le **dual**. C'est la seule arme du roster à donner le
  passif spécial sans donner l'ambidextrie.

> **Toute note antérieure rangeant le Marteau parmi les armes qui refusent le 1,10 est caduque.**
> Le rework du §3.5 renverse cette lecture ; c'est la seule contradiction qu'il introduit, et elle est
> actée ici comme dans la fiche.

Un joueur privé de Lance Spartane et un joueur ralenti en la portant ne font pas le même arbitrage :
le premier perd un sommet du triangle, le second le paie. **D15 interdit le premier cas par défaut** —
l'interdiction de port doit donc rester réservée aux armes qui répondent déjà à tout.

---

### D17 — la part reportée subit le régime de ce qu'elle touche

Quand une protection saute et qu'il reste de la puissance, le report est **intégral en quantité** : rien
n'est perdu. Mais le montant reporté **change de régime** — il est recalculé au multiplicateur applicable
à la nouvelle cible.

| Étape | Traitement |
|---|---|
| 1. Le tir frappe la protection | Au multiplicateur de la **protection** |
| 2. La protection saute, il reste de la puissance | Le reste est **intégralement** reporté |
| 3. Le reste touche la chair / l'armure | **Le régime normal de l'arme contre cette cible s'applique au montant reporté** |

**⚠️ Le mot « malusée » est une conséquence, pas la règle.** Le report n'est réduit **que si l'arme est
déjà faible contre ce qu'elle atteint**. Une arme sans malus chair reporte **strictement** ce qui reste,
sans perte : le report ne pénalise personne par lui-même.

| Cas | Ce qui arrive au report |
|---|---|
| L'arme a un **malus** contre la nouvelle cible | Le reste est **multiplié par ce malus** |
| L'arme est **neutre** contre la nouvelle cible | **Report strict**, intégral, sans perte |
| L'arme a un **bonus** contre la nouvelle cible | Le bonus s'applique au reste *(cf. critique sur point faible, §0.4)* |

**Le principe réel : le report ne conserve jamais le taux de la protection qu'il vient de traverser.**
C'est ce qui empêche une arme anti-bouclier de devenir accidentellement bonne contre la chair au moment
de la transition. Le tir de bascule reste utile — rien n'est gaspillé — sans devenir un tir de chair
déguisé.

> **Exemple canonique — une arme à ×1,50 bouclier et ×0,25 chair**, sur **Élite Major**
> *(bouclier 2,00 · chair 1,25)*.
>
> | Étape | Calcul |
> |---|---|
> | 4 tirs sur le bouclier | 0,60 × 4 = **2,40** |
> | Bouclier du Major | **2,00** — il saute au 4ᵉ tir |
> | Reste à reporter | **0,40** |
> | Ce reste touche la chair | 0,40 × **×0,25** = **0,10 ART** |
>
> **Sans ce ×0,25, les 0,40 seraient passés en entier.** La réduction
> vient de l'arme, pas de la mécanique de report.
>
> ⚠️ **Piège de lecture repéré une fois** : une fiche écrivait « 25 % des 0,20 restants ». Ce **n'est pas
> un taux de report** — c'est le **malus chair de l'arme**. Aucune exception au report général n'est
> nécessaire, et il ne faut pas en inventer une.

---

### D18 — ré-application, jamais cumul

**Aucun effet de durée ne s'additionne à lui-même.** Une cible porte **un seul effet actif** par famille.
Une nouvelle source **ne s'ajoute pas** : elle **remet la durée à plein**.

| Famille | Comportement | Référence |
|---|---|---|
| **Feu / brûlure** | Une cible = **une brûlure**. Un nouvel allumage **remplace** le foyer | §5.0 |
| **Saignement** | Une cible = **une plaie**. Une seconde frappe **ré-applique** à durée pleine | §5.6 |
| **Zones au sol** | Une nouvelle zone **remplace** l'ancienne | §5.0 |

**La conséquence de design est la même dans les trois cas, et elle est voulue : le gain d'une seconde
application n'est pas dans les dégâts, il est dans la fenêtre.** Frapper à nouveau ne fait pas plus mal
sur la durée — cela **maintient la cible dans l'état**. Pour le saignement, cela relance les **12,50 s**
de vulnérabilité tranchant → cinétique ; pour le feu, cela garde la cible cautérisée et interdit la mise
en place au tranchant.

> **Corollaire à retenir avant tout chiffrage** : un effet de durée ne doit **jamais** être équilibré sur
> l'hypothèse d'un empilement. Trois frappes de Tourelle Spiker valent **0,188 ART**, pas 0,564.

---

## Légende des colonnes

Conventions de lecture communes à **tous** les tableaux d'équilibrage du projet.

| Colonne | Signification |
|---|---|
| **ART/tir** | Dégâts bruts par tir, rafale ou cartouche (unité précisée) |
| **Cad.** | Cadence en tirs/s (ou rafales/s) |
| **DPS ch. / bcl** | Dégâts par seconde sur chair / sur bouclier (malus appliqué) |
| **Mod. bcl** | Modificateur contre bouclier Covenant |
| **Mod. arm.** | Modificateur contre armure (Brutes) |
| **ANB** | **Dégâts anti-blindage** — barème parallèle, spécifique aux véhicules et cibles blindées |
| **Crit** | Multiplicateur sur point faible |
| **Perfo** | Ignore le casque (jamais le bouclier) |
| **Report** | Le surplus de dégâts bouclier passe dans les PV — **règle générale, toutes armes** (voir `equilibrage-sandbox-armes.md` §0.4) |
| **Mag** | Chargeur ou batterie |
| **Frac.** | **Fraction de chargeur pour tuer un Elite Minor** — unité de rythme |
| **K/mag** | Kills (Minor) par chargeur |

### Unités de référence

| Référence | Valeur | Note |
|---|---|---|
| **1 ART** | 100 % du bouclier de référence | Unité strictement **additive** |
| **Mêlée de référence** | **0,35 ART** | Base Spartan, avant tout bonus |

### Le standard de fraction de chargeur

⚠️ **Portée restreinte** *(**D2**)*. Ce standard ne régit que les **armes de précision légères** — la
classe **BR / Fusil à Aiguille**. Les automatiques, les armes lourdes, les armes à
batterie et le CAC **ne sont pas mesurés à cette aune** : leur rythme se lit sur la surchauffe, la
réserve ou la fenêtre de refroidissement.

```
1/3 (≈33 %) → 3 kills/mag  ·  standard des armes de précision légères
1/2 (50 %)  → 2 kills/mag  ·  exception assumée (M6D)
> 100 %     → 0 kill/mag   ·  arme de soutien, ne conclut jamais seule
```

> Sur cette classe, c'est l'unité de **rythme d'encounter** : elle fixe la fréquence des recharges,
> donc les fenêtres de vulnérabilité, donc le moment où l'IA doit pousser.
>
> **Hors de cette classe, appliquer le tiers de chargeur est une erreur de lecture** : un automatique
> qui tuerait en un tiers de chargeur serait hors-norme, et une arme à batterie n'a pas de chargeur à
> fractionner.

### ANB — l'axe anti-blindage

**Barème parallèle et indépendant de l'ART.** Toutes les armes du jeu reçoivent une valeur ANB,
y compris celles dont la valeur est nulle : c'est une **seconde grille d'équilibrage complète**,
qui ne se déduit pas des dégâts anti-infanterie.

| Point | Règle |
|---|---|
| Cibles | Véhicules et cibles blindées uniquement |
| Indépendance | Une arme forte en ART peut être nulle en ANB, et l'inverse |
| Valeur nulle | Autorisée et significative — elle ferme un rôle |
| Colonne | À renseigner pour **chaque** arme des deux factions |

*Grille ANB à construire — les valeurs seront posées arme par arme.*

---

## Matrice de solidité des unités de référence

Toutes les valeurs en **ART**. Le bouclier est exprimé en **% du bouclier Spartan** (référence 100 %) :
**c'est ce pourcentage qui encode le rang** de l'unité — il monte avec la hiérarchie Covenant,
la chair suit beaucoup plus lentement.

| Unité | Bouclier | **% bcl** *(encode le rang)* | PV (chair) | Casque | Total hors casque | Total avec casque | Solidité / Spartan *(casque inclus)* |
|---|---|---|---|---|---|---|---|
| **Spartan** *(joueur)* | 1,00 | **100 %** | 1,50 | — | **2,50** | 2,50 | **1,00×** |
| Elite Furtif | 0 | **0 %** | 1,50 | — | 1,50 | 1,50 | 0,60× |
| Elite Minor | 1,00 | **100 %** | 1,00 | — | 2,00 | 2,00 | 0,80× |
| Disciple Dévot *(héroïque)* | 0 | **0 %** | 2,25 | — | 2,25 | 2,25 | 0,90× |
| Apprenti Ultra *(légendaire)* | 1,25 | **125 %** | 1,50 | — | 2,75 | 2,75 | 1,10× |
| Elite Major | 2,00 | **200 %** | 1,25 | — | 3,25 | 3,25 | 1,30× |
| Elite Spec-Ops | 2,00 | **200 %** | 1,75 | — | 3,75 | 3,75 | 1,50× |
| Elite Ultra | 2,75 | **275 %** | 2,50 | 0,75 *(perforable)* | 5,25 | 6,00 | 2,40× |
| Elite Dévot | 3,50 | **350 %** | 2,25 | 0,75 *(**anti-perfo**)* | 5,75 | 6,50 | 2,60× |
| Elite Général | 6,00 | **600 %** | 2,50 | 1,25 | 8,50 | 9,75 | 3,90× |

### Lecture

| Constat | Chiffre |
|---|---|
| Amplitude du **bouclier** | 0 % → 600 % — **facteur 6** |
| Amplitude de la **chair** | 1,00 → 2,50 — **facteur 2,5** |
| Deux unités sans bouclier | Furtif (1,50) · Disciple Dévot (2,25) |
| Seule unité plus fragile que le Spartan à nu | Furtif — 0,60× |
| Unités plus solides que le Spartan | Major, Spec-Ops, Ultra, Dévot, Général, Apprenti Ultra |
| Casque **anti-perforation** | Dévot uniquement |

> **Le rang se lit sur la protection, pas sur la chair.** La progression de difficulté est portée
> à ~85 % par la serrure — bouclier **ou armure** — et non par la barre de vie ; conforme à **D1**. Un joueur qui règle son
> problème de bouclier voit toutes les unités s'effondrer dans une fourchette de 1,00 à 2,50 ART.
>
> **Conséquence directe :** un outil qui contourne le bouclier (M319 collé) ne gagne pas un peu de
> temps — il ramène une unité de rang 6 au niveau d'un Minor.
>
> ⚠️ **Mise à jour :** le **report de DPS est désormais général à toutes les armes** — il n'est plus
> l'apanage du SRS99 et du M90. La différenciation se joue donc ailleurs (criticité, perforation,
> bypass), et non plus sur le fait de reporter ou non. Voir `equilibrage-sandbox-armes.md` §0.4.

---

## 0. Le postulat de design

Le Hornet est un **propulseur qui accélère** : un **correcteur de vecteur** sur un personnage à forte
inertie. Conséquence : le joueur n'est pas *rapide*, il est **imprévisible**. Ce n'est pas la même chose
à équilibrer.

| Ce que le joueur gagne | Ce qu'il faut taxer |
|---|---|
| **Du contrôle directionnel** | **La ressource** *(carburant)* **et la précision pendant la poussée** |

> **Règle d'or :** ne jamais taxer la *vitesse*. Taxer l'*accélération*.
> Taxer la vitesse apprend au joueur à s'arrêter — et tue le jeu que tu construis.

---

## 1. Le modèle d'inertie : les 4 états du joueur

Tout l'équilibrage découle de ces états. Nomme-les dans ton code, ils serviront partout.

| État | Définition | Précision | Vulnérabilité |
|---|---|---|---|
| **ANCRÉ** | Au sol, vitesse < 30 % max | 100 % | Normale |
| **DÉRIVE** | En l'air ou au sol, accélération ≈ 0 | 90–95 % | Normale |
| **POUSSÉE** | Hornet actif, accélération forte | 50–65 % | Normale |
| **SUBI** | Knockback / explosion / EMP subi | 40 % | +25 % dégâts reçus |

**Formule de spread recommandée :**
```
spread_final = spread_base
             + k_accel * |accélération_actuelle|      // le Hornet, les impacts
             + k_recul * recul_accumulé                // cadence de tir
```
Note bien : `vitesse` n'apparaît **pas** dans la formule. C'est volontaire.

**Constante de départ :** `k_accel` calibré pour qu'une poussée Hornet à pleine puissance multiplie le spread par **2,5×**, avec un retour à la normale en **0,25 s** après la fin de la poussée.

Ce délai de 0,25 s est le paramètre le plus important du jeu. C'est lui qui crée le rythme
**pousser → planer → tirer**. Trop court (0,1 s) : la mobilité est gratuite, tirer en poussant devient
optimal. Trop long (0,6 s) : le joueur arrête de bouger pendant les combats. Teste 0,20 / 0,25 / 0,35.

---

## 2. Budget de survie et TTK

### 2.1 Les trois barres
| Barre | Valeur | Régénération | Rôle |
|---|---|---|---|
| Bouclier | 100 | 2 s de délai, puis 100 en 2 s | Absorbe les erreurs |
| Santé | 45 | Aucune (packs / bornes) | Punit les erreurs répétées |
| **Carburant Hornet** | **100** | **0,5 s de délai, 100 en 2,5 s** | **Ressource de mobilité = 3e barre de vie** |

Le carburant est une barre de vie déguisée. Le vider, c'est retirer au joueur sa capacité d'esquive
sans jamais lui retirer le contrôle. **C'est ton meilleur levier d'équilibrage — utilise-le au lieu des dégâts.**

### 2.2 Cible de TTK

⚠️ **Section périmée — à refaire.** Ces cibles datent d'avant la matrice réelle. Elles ont été posées
en secondes, alors que la sandbox se chiffre désormais en **ART** et en **tirs-pour-tuer** ; et elles
supposent des règles de mêlée que **D14** a remplacées *(pas de « one-shot dorsal » générique : ×3,00
traversant, plafonné à 1,00 sur la seule base 0,35)*.

**Ce qui reste valable, et qui est le vrai critère :**

> Un joueur qui repère un tireur et réagit immédiatement au Hornet doit pouvoir **sortir de la ligne de
> vue avant de mourir**, mais seulement s'il réagit dans les ~0,3 premières secondes. En dessous, la
> mobilité est décorative. Au-dessus, personne ne meurt jamais.

**À refaire à partir des chiffres réels** — la troisième lecture transversale due sur la matrice
*(cohérence des seuils)* produira ces valeurs : elles seront dérivées des DPS constatés arme par arme,
pas posées a priori.

### 2.3 Coûts Hornet indicatifs
| Action | Coût | Note |
|---|---|---|
| Poussée courte (correction) | 12 | L'action de base, doit être quasi-gratuite |
| Poussée longue (0,5 s) | 30 | |
| Wall jump | 8 | Récompense l'usage des surfaces |
| Wallrun | 10 / s | La gravité fait déjà le travail, ne surtaxe pas |
| Freinage d'urgence | 25 | **Cher.** Annuler son inertie doit être un choix, pas un réflexe |

Le freinage cher est ce qui donne du poids au personnage. Sans lui, l'inertie n'existe plus.

---

## 3. La matrice de sandbox

Chaque arme occupe **une case unique**. Deux armes dans la même case = une arme morte.

### Axe 1 — Portée efficace
`CONTACT (0-5m)` · `COURTE (5-15m)` · `MOYENNE (15-40m)` · `LONGUE (40m+)`

### Axe 2 — Rôle sur les barres
`ANTI-BOUCLIER` · `ANTI-CHAIR` · `POLYVALENT` · `ANTI-VÉHICULE` · `ZONE` · **`DÉNI DE MOBILITÉ`**

**`ANTI-VÉHICULE` est le libellé retenu**, au sens large — pas de sous-catégorie « anti-char ». Ce rôle
sera chiffré par la **grille ANB** à venir, qui couvrira l'ensemble de la sandbox ; il n'a donc pas
besoin d'être subdivisé ici.

Le 6ᵉ rôle est ton ajout spécifique. Il n'existe dans aucun Halo, et ton système le réclame.

### 3.1 — Occupation des cases

⚠️ **La grille de départ a été retirée.** Elle listait 14 armes génériques et des interactions Hornet
posées avant la matrice réelle ; elle est aujourd'hui contredite par les **43 fiches** de
`equilibrage-sandbox-armes.md`. **Elle sera refaite** à partir du roster réel, quand le moment viendra.

**Ce qui survit de la grille, et qui reste une décision de design :**

| Case | État |
|---|---|
| `CONTACT / ANTI-VÉHICULE` | **Volontairement vide** — gardée pour un ajout futur |

> Une sandbox saine garde de la place pour grandir. **Ces vides sont un choix, pas un oubli** — à ne pas
> combler par réflexe de complétude au moment de refaire la grille.

---

## 4. Les explosifs : inverser le curseur

C'est le point où la plupart des fangames à mobilité se plantent.

**Le problème :** un personnage à forte inertie ne peut pas s'arrêter. L'AoE classique
(gros rayon, gros dégâts) devient une punition non-réactive : le joueur voit l'explosion arriver
et *ne peut rien faire*. C'est frustrant, pas difficile.

**La solution :** l'explosion vole le vecteur au lieu de tuer.

| Paramètre | Valeur classique Halo | **Valeur recommandée pour toi** |
|---|---|---|
| Rayon de dégâts | 5 – 7 m | **3 – 4 m** |
| Falloff | Linéaire | **Quadratique (raide)** |
| Rayon d'impulsion | ≈ rayon de dégâts | **6 – 8 m (bien plus large)** |
| Force d'impulsion | Modérée | **Forte, injectée dans le momentum** |
| Dégâts au centre | Létaux | Bouclier + ~50 % santé |

**Bénéfices :**
- L'explosion devient **positionnelle** : elle te déplace, elle ne te supprime pas.
- Elle crée du **rocket jump** — les bons joueurs en font un outil de mobilité. Ne bloque pas ça, c'est du skill ceiling gratuit.
- Elle **synergise avec l'IA de groupe** : un ennemi regroupé se fait disperser, ce qui est lisible et satisfaisant.
- Elle reste dangereuse près des gouffres et des surfaces — le level design décide de sa létalité.

**Auto-dégâts : AUCUNE réduction.** L'explosion du joueur lui inflige **ses dégâts pleins**, comme à
n'importe quelle cible. Le rocket jump reste possible — l'impulsion est entière — mais il se paie au
prix fort, et **le joueur doit être prudent**.

> C'est cohérent avec le reste du socle : pas de régénération des PV *(**D4**)*, des kits pour se
> soigner *(**D13**)*. Un explosif mal placé sous ses propres pieds est une faute qui coûte une
> ressource rare, pas une taxe symbolique. **La mobilité n'achète pas l'impunité.**

---

## 5. Le rôle « déni de mobilité »

**Arbitrage tranché : le Hornet ne se coupe jamais.** Le jeu est construit sur la mobilité ; lui retirer
sa mobilité, même une seconde, c'est lui retirer le jeu. La porte ouverte était visible : une fois le
brouillage admis, le mode Légendaire finit par en mettre partout, et l'on obtient des combats sans
Hornet dans un jeu dont c'est le cœur. **C'est non.**

### Ce qui est autorisé, ce qui ne l'est pas

| Effet | Statut |
|---|---|
| **Couper le Hornet** *(EMP ou autre)* | ❌ **Interdit** — jamais, à aucune durée |
| **Alourdissement** *(poussées plus chères)* | ❌ **Retiré** — inutile, le carburant fait déjà ce travail |
| **Zone de brouillage** *(volume sans régén.)* | ❌ **Retiré du bestiaire** — n'existera que si un **équipement** du joueur l'apporte, jamais comme outil ennemi de zone |
| **Suspendre la RÉGÉNÉRATION du carburant** | ✅ **Autorisé** — la poussée reste disponible, seule la recharge s'arrête |

**La seule prise autorisée sur la mobilité est donc la régénération.** Le joueur garde en permanence
l'usage de ce qu'il a en réserve : il peut toujours pousser, esquiver, sortir. Ce qu'on lui prend, c'est
la **capacité à recommencer indéfiniment** — ce qui crée de la pression sans jamais retirer le contrôle.

### Les trois règles non négociables

1. **JAMAIS DE COUPURE. Tout court.** Pas 1,5 s, pas 0,5 s, pas une frame. Le contrôle directionnel du
   joueur est inviolable — c'est la règle la plus dure du document.
2. **La lisibilité est essentielle.** Toute menace doit être lue **avant** de frapper : un jet de grenade
   s'annonce par un **cri**, un **feedback sonore** et une **animation caractéristique** ; un Rapace qui
   prépare une charge fait **briller son pistolet à plasma**. Le joueur doit pouvoir répondre à une
   information, jamais à un dé.
3. **L'EMP inflige peu de dégâts aux PV, et n'enlève de toute façon pas la mobilité.** Il perd son
   statut d'outil de déni pour devenir ce qu'il est : un **outil anti-bouclier**, sans effet sur le
   contrôle du personnage.

> **Cas particulier — la Grenade Dynamo.** Elle ajoute à l'EMP un **souffle de 0,35 ART, traité comme une
> attaque de mêlée**. La conséquence est systémique et voulue : étant de la mêlée, ce souffle **entre dans
> l'économie du saignement** *(§5.6 de `equilibrage-sandbox-armes.md`)* et se trouve **rendu nettement plus
> violent** sur une cible déjà entaillée. La Dynamo n'est pas une grenade utilitaire — c'est une grenade
> qui frappe.

Ce rôle, tel qu'il subsiste, empêche le Hornet de devenir une carte « je gagne » **sans jamais dire
stop** : il rend le carburant précieux au lieu de rendre le joueur passif.

---

## 6. Le ciel n'est pas un problème d'équilibrage

**Cette question est close.** L'altitude n'est pas un espace sûr, et elle n'a pas besoin d'archétypes
ennemis dédiés pour cesser de l'être — deux garde-fous suffisent, et ils existent déjà :

| Garde-fou | Effet |
|---|---|
| **Le carburant est fini** | Le joueur **ne peut pas rester en l'air indéfiniment**. La ressource borne le temps de vol, sans qu'aucun ennemi ait à s'en mêler |
| **Les ennemis touchent** | Leur précision n'est pas nulle. Un joueur en l'air **encaisse quand même** — il gagne des angles, il ne gagne pas l'invulnérabilité |

> **Le ciel reste jouable, il n'est jamais gratuit.** Le joueur monte : il gagne de la vision et des
> angles, il perd la couverture et devient la cible prioritaire. C'est le bon équilibre, et il tient
> tout seul.

**Aucun archétype anti-aérien obligatoire n'est requis.** La question de l'IA — comportements, escouades,
coordination, directeur — **se traitera en son temps**, dans `comportement-de-l-ennemi.md`. Elle ne
relève pas de l'équilibrage de la sandbox d'armes et n'a pas à être pré-décidée ici.

---

## 7. Level design : construire pour le vecteur

| Principe | Application concrète |
|---|---|
| **Couloirs de vecteur** | Des trajectoires longues et lisibles que le joueur *apprend* à enchaîner |
| **Murs opportunistes** | Le wallrun subit la gravité → les surfaces sont des relais, pas des routes |
| **Verticalité punie** | Chaque hauteur avantageuse est exposée à un archétype Flak |
| **Volumes fermés** | Zones anti-Hornet où le joueur doit assumer un combat au sol |
| **Points de respiration** | Espaces sûrs pour régénérer le carburant — ce sont les vrais checkpoints du rythme |

**Métrique de conception :** mesure la **distance franchissable en une poussée Hornet à plein carburant**.
Appelle-la `D_hornet`. C'est ton unité de mesure de niveau — comme le saut de Mario.

- Écarts < `D_hornet` : franchissables sans réflexion (fluidité)
- Écarts ≈ `1,5 × D_hornet` : demandent un enchaînement (skill)
- Écarts > `2 × D_hornet` : nécessitent un mur, une rampe, une explosion (level design)

Construis **toutes** tes distances en multiples de `D_hornet`. C'est ce qui donnera à tes niveaux
une cohérence que les joueurs sentiront sans pouvoir la nommer.

---

## 8. Protocole de test — dans cet ordre

L'ordre compte. Chaque étape verrouille des valeurs dont la suivante dépend.

| Ordre | Ce qu'on verrouille | Test |
|---|---|---|
| 1 | **Inertie + coûts Hornet** | Une salle vide. Est-ce agréable de bouger *sans rien d'autre* ? |
| 2 | `D_hornet` | Mesurer, documenter, ne plus y toucher |
| 3 | **Délai de retour du spread** (0,25 s) | Une cible fixe. Le rythme pousser/planer/tirer émerge-t-il seul ? |
| 4 | Arme utilitaire seule | Le duel contre cible mobile est-il tenable ? *(cible chiffrée à réétablir — cf. §2.2)* |
| 5 | Un ennemi | Le duel est-il lisible ? |
| 6 | Une escouade de 4 | La coordination se *voit*-elle sans être expliquée ? |
| 7 | Sandbox complète | Chaque arme a-t-elle un moment où elle est le bon choix ? |

> **Ne jamais équilibrer une arme avant que la mobilité soit figée.** Tout chiffre de dégâts posé
> avant l'étape 2 sera à refaire.

### Le test de la case vide
Pour chaque arme, demande : *« Quelle est la situation où cette arme est le meilleur choix
disponible ? »* Si tu n'as pas de réponse en une phrase, l'arme n'a pas sa place.
Ce test élimine plus de mauvaises armes que n'importe quel tableur.

---

## 9. Les cinq pièges spécifiques à ton projet

1. **Punir la vitesse au lieu de l'accélération.** Le joueur apprend à s'arrêter, ta mobilité meurt.
2. **Un TTK trop court.** Le Hornet devient décoratif : on meurt avant d'avoir esquivé.
3. **Des explosifs à gros rayon.** Punition non-réactive contre un personnage qui ne peut pas freiner.
4. **Toucher au contrôle du joueur.** Couper le Hornet, même brièvement, casse le jeu que tu construis
   *(§5, règle 1)*. La seule prise autorisée est la **régénération** du carburant.
5. **Un freinage trop bon marché.** L'inertie disparaît, et avec elle l'identité du personnage.
