#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
matrice-de-depart.py — Socle de calcul du projet.

Ne contient QUE ce qui est encore vivant dans les .md :
  · base-de-travail.md   (doctrine, légende, unités de référence, matrice de solidité, ANB)
  · contenu-sandbox-armes-retenues.md (registre éditorial — aucun chiffre)

Tout le reste (anciens moteurs art_*.py) a été supprimé : valeurs obsolètes,
tables recalculées ailleurs, ou armes dont l'équilibrage sera redonné plus tard.

Ce fichier est un SOCLE : la table ARMES est volontairement vide.
Elle se remplira quand l'équilibrage arme par arme sera posé.
"""

from math import ceil

# ═══════════════════════════════════════════════════════════════════════
#  1. UNITÉS DE RÉFÉRENCE
#     1 ART = 100 % du bouclier Spartan. Unité strictement additive.
# ═══════════════════════════════════════════════════════════════════════

ART_REFERENCE = 1.00          # bouclier Spartan = 1 ART = 100 %
MELEE_REFERENCE = 0.35        # mêlée Spartan de base, avant tout bonus

# nom, bouclier, PV (chair), casque, casque_anti_perfo
UNITS = [
    ("Spartan (joueur)",   1.00, 1.50, 0.00, False),
    ("Elite Furtif",       0.00, 1.50, 0.00, False),
    ("Elite Minor",        1.00, 1.00, 0.00, False),
    ("Disciple Dévot",     0.00, 2.25, 0.00, False),
    ("Apprenti Ultra",     1.25, 1.50, 0.00, False),
    ("Elite Major",        2.00, 1.25, 0.00, False),
    ("Elite Spec-Ops",     2.00, 1.75, 0.00, False),
    ("Elite Ultra",        2.75, 2.50, 0.75, False),
    ("Elite Dévot",        3.50, 2.25, 0.75, True),    # casque ANTI-PERFORATION
    ("Elite Général",      6.00, 2.50, 1.25, False),
]

SPARTAN_TOTAL = 1.00 + 1.50   # 2.50 ART — référence de solidité


# ═══════════════════════════════════════════════════════════════════════
#  2. RÈGLES DE PROTECTION (fixées)
# ═══════════════════════════════════════════════════════════════════════
#
#   PERFORATEUR  : ignore le CASQUE uniquement — jamais le bouclier.
#   ANTI-PERFO   : casque du Dévot. Seule exception du jeu.
#   REPORT       : le surplus bouclier passe dans la chair.
#                  RÈGLE GÉNÉRALE — vaut pour TOUTES les armes du jeu.
#                  La base du critique se calcule sur les dégâts RESTANTS.
#                  Si le report vient d'un coup malusé, le reste est indexé
#                  sur la base malusée.  Voir equilibrage-sandbox-armes.md §0.4.
#                  Réservé aux armes puissantes.
#   MALUS BCL    : pénalité balistique CSNU contre bouclier Covenant.
#   BYPASS       : ignore intégralement le bouclier (contact / collage).
#
# ═══════════════════════════════════════════════════════════════════════


# ═══════════════════════════════════════════════════════════════════════
#  3. STANDARD DE FRACTION DE CHARGEUR  (unité de rythme, doctrine D2)
# ═══════════════════════════════════════════════════════════════════════

FRACTION_STANDARD = {
    "1/3": 1 / 3,     # 3 kills/mag — standard arme principale
    "1/2": 1 / 2,     # 2 kills/mag — exception assumée
}
CIBLE_FRACTION = ("Elite Minor")   # l'étalon sur lequel la fraction se mesure


def classer_fraction(frac):
    """Situe une fraction de chargeur par rapport au standard."""
    if abs(frac - 1 / 3) < 0.06:
        return "1/3 — standard arme principale"
    if abs(frac - 1 / 2) < 0.06:
        return "1/2 — exception assumée"
    if frac > 1.0:
        return "dépasse le chargeur — arme de soutien"
    if frac < 0.25:
        return "réserve large"
    return "hors standard"


# ═══════════════════════════════════════════════════════════════════════
#  4. GABARIT D'ARME  (à remplir à l'arrivée de l'équilibrage)
# ═══════════════════════════════════════════════════════════════════════

class W:
    """Une arme. `anb` = barème anti-blindage, parallèle et indépendant de l'ART."""

    def __init__(self, nom, dmg, rof, mag,
                 malus=0.0, crit=1.0, anb=0.0,
                 report=False, perfo=False, bypass=False, unite="tir"):
        self.nom = nom
        self.dmg = dmg          # ART par tir / rafale / cartouche
        self.rof = rof          # cadence, tirs/s
        self.mag = mag          # chargeur ou batterie
        self.malus = malus      # pénalité contre bouclier (0.25 = −25 %)
        self.crit = crit        # multiplicateur point faible
        self.anb = anb          # dégâts anti-blindage (véhicules)
        self.report = report    # surplus bouclier → chair
        self.perfo = perfo      # ignore le casque
        self.bypass = bypass    # ignore le bouclier
        self.unite = unite

    @property
    def d_bcl(self):
        return self.dmg * (1 - self.malus)

    @property
    def d_chair(self):
        return self.dmg

    @property
    def d_crit(self):
        return self.dmg * self.crit


# ─── CSNU — 17 entrées, transcription de la fiche d'équilibrage ────────
# dmg = ART/tir (ou /salve, /cartouche, /unité selon `unite`)
# malus = pénalité bouclier exprimée en fraction (0.20 = ×0.80)
# Les valeurs ⚠ sont celles RECALCULÉES ; voir §5.2 du .md pour les écarts.

ARMES = [
    # nom                dmg     rof     mag  malus crit  anb   report perfo bypass unite
    W("MA37",            0.071,  8.0,    32,  0.20, 1.40, 0,    True,  False, False, "tir"),  # ecart A : 0.071 (32 tirs pile) ; crit 1.40 = casque/tete ; 1.25 armures hors tete + pts faibles (0.8)
    W("MA5B (sec 1)",    0.059,  15.0,   60,  0.20, 1.00, 0,    True,  False, False, "tir"),
    W("MA5B (sec 4)",    0.0915, 15.0,   60,  0.20, 1.35, 0,    True,  False, False, "tir"),
    W("M6D",             0.225,  2.5,    12,  0.00, 5.00, 0,    True,  True,  False, "tir"),
    W("M6C",             0.15,   8.0,    15,  0.00, 1.00, 0,    True,  False, False, "tir"),
    W("M7",              0.045,  12.0,   48,  0.00, 1.00, 0,    True,  False, False, "tir"),
    W("M7-S",            0.045,  12.0,   48,  0.00, 1.35, 0,    True,  False, False, "tir"),  # point 10 : crit 1.65 -> 1.35, balle critique de fin de rafale supprimee
    W("W0-LF M4",        0.65,   1.5,    8,   0.00, 2.00, 0,    True,  False, False, "tir"),
    W("BR75",            0.36,   1.488,  12,  0.00, 5.00, 0,    True,  True,  False, "salve"),  # ecart C : x5.00 = 1.80/salve ; + bonus casques x1.35 (0.486/salve)
    W("M90 CAWS",        1.375,  0.60,   6,   0.00, 1.50, 0,    True,  False, False, "cartouche"),
    W("SRS99C S2",       1.50,   2.0,    4,   0.25, 1.00, 0,    True,  True,  False, "tir"),
    W("SRS99C SSR",      1.00,   2.0,    5,   0.25, 1.00, 0,    True,  True,  False, "tir"),  # ecart E : base 1.00, malus bouclier x0.75 -> 0.75 (pas une penalite de -0.75)
    W("M41 (contact)",   1.00,   0.567,  2,   0.00, 1.00, 0,    True,  False, False, "roquette"),  # point 3 : impact cinetique, jamais de malus bouclier
    W("M41 (souffle)",   2.50,   0.567,  2,   0.34, 1.00, 0,    True,  False, True,  "souffle"),  # souffle cinetique, malus x0.66 sur le souffle seul
    W("Laser M6",        3.50,   0.0,    5,   0.00, 1.00, 0,    True,  True,  False, "tir"),
    W("M319 IGL",        1.25,   0.44,   1,   0.40, 1.00, 0,    True,  False, False, "grenade"),  # point 9 : ANB retire -> grille ANB dediee
    W("M319 adhesif",    1.75,   0.44,   1,   0.00, 1.00, 0,    True,  False, True,  "grenade"),  # point 9 : ANB retire -> grille ANB dediee
    W("M319 IEM",        1.25,   0.44,   1,   0.00, 0.40, 0,    True,  False, False, "grenade"),
    W("Lance-Flammes",   0.125,  10.0,   100, 0.00, 0.35, 0,    True,  False, False, "tir"),
    W("Lance Spartane",  0.35,   1.0,    5,   0.00, 1.00, 0,    True,  False, False, "unite"),
    W("Grenade Frag",    1.25,   0.0,    8,   0.00, 1.50, 0,    True,  False, False, "grenade"),
    W("M739 LMG (fixe)", 0.085,  13.0,   200, 0.25, 1.50, 0,    True,  False, False, "tir"),
    W("M739 SAW",        0.085,  13.0,   72,  0.25, 1.50, 0,    True,  False, False, "tir"),

    # ─── COVENANT / ELITES — 13 fiches, 18 entrees (D9 : malus sur la CHAIR, pas le bouclier)
    # LOT ARBITRE ET CLOS. Reworks appliques : Focus Rifle (chaleur + railgun 2.00)
    # et Epee a Energie (chauffe, perforation retiree, scaling de combo).
    # Rappel §0.11 : l'IA n'utilise AUCUN sous-systeme (charge, railgun, estoc)
    # sauf mention explicite sur sa fiche d'ennemi.
    # `malus` reste la penalite bouclier ; les malus "cible non protegee" sont
    # notes en commentaire car le moteur ne modelise pas encore ce sens-la.
    W("Fusil a Plasma",  0.125,  5.0,    250, 0.00, 1.00, 0,    True,  False, False, "tir"),   # x0.80 chair
    W("Estoc Plasma",    0.65,   0.0,    10,  0.00, 1.00, 0,    True,  False, True,  "estoc"),
    W("Pistolet Plasma", 0.162,  9.0,    400, 0.00, 1.00, 0,    True,  False, False, "tir"),   # x1.35 bcl applique ; 0.12 neutre ; surchauffe 27 tirs
    W("Charge Plasma",   2.25,   0.0,    16,  0.00, 1.00, 0,    True,  False, False, "charge"),
    W("Needler (SC)",    1.25,   1.0,    3,   0.00, 1.00, 0,    True,  False, True,  "supercombine"),
    W("Repeteur Plasma", 0.076,  12.0,   380, 0.00, 1.00, 0,    True,  False, False, "tir"),
    W("Fusil Aiguille",  0.167,  2.5,    21,  0.00, 1.00, 0,    True,  False, False, "tir"),
    W("Aiguille (SC)",   1.25,   0.833,  7,   0.00, 1.00, 0,    True,  True,  False, "supercombine"),
    W("Grenadier Plasma",0.40,   1.66,   8,   0.00, 1.50, 0,    True,  False, False, "tir"),
    W("Grenadier charge",1.60,   0.55,   2,   0.00, 1.50, 0,    True,  False, True,  "charge"), # x0.66 armures = 1.056
    W("Focus Rifle",     0.088,  10.0,   40,  0.50, 1.75, 0,    True,  False, False, "impulsion"), # crit x1.75 = cible BRULEE ; portee infinie ; 2.75%/s = 36.4 s de tir
    W("Focus Railgun",   2.50,   0.50,   11,  0.00, 1.00, 0,    True,  True,  False, "railgun"), # max 2.50 (72.51-87.50%) ; 1.50 en 65-72.50% ; froid 9% -> 11 tirs, chaud 14% -> 7
    W("Canon Combust.",  0.95,   2.2,    5,   0.00, 1.00, 0,    True,  False, False, "tir"),
    W("Epee a Energie",  1.50,   1.0,    7,   0.00, 1.00, 0,    True,  False, False, "coup"),  # REWORK : perfo RETIREE ; chauffe 15% chair / 9.90% bouclier / 0% armure
    W("Epee (combo 3+)", 2.25,   1.0,    7,   0.00, 1.00, 0,    True,  False, False, "coup"),  # x1.25 au 2e, x1.50 des le 3e
    W("Poing americain", 0.50,   1.0,    99,  0.00, 1.00, 0,    True,  False, False, "melee"), # socle epee en surchauffe (10 s)
    W("Grenade Plasma",  2.25,   0.0,    8,   0.00, 1.00, 0,    True,  False, True,  "grenade"),
    W("Tourelle Plasma", 0.136,  11.0,   250, 0.00, 1.00, 0,    True,  False, False, "tir"),   # x1.25 bcl applique
    W("Greleur (SC)",    1.75,   0.5833, 18,  0.00, 1.00, 0,    True,  False, True,  "supercombine"), # 1.75 t/s = 0.5714 s ; SC = 9 pics = 3 tirs

    # ── Brutes / Jiralhanae ────────────────────────────────────────────
    # Valeurs retenues apres arbitrage des ecarts O-V (voir 5.10).
    W("Fusil Plasma Br.", 0.125,  6.0,    200, 0.00, 1.00, 0,    True,  False, False, "tir"),   # x0.80 chair (ecart O)
    W("Mauler",           1.00,   1.666,  5,   0.00, 2.857,0,    True,  False, False, "tir"),   # 0.35 + 0.65 schrapnel
    W("Mauler (princ.)",  0.35,   1.666,  5,   0.50, 2.857,0,    True,  False, False, "tir"),   # tir solide seul, x0.50 protections
    W("Sabre Grenade",    0.334,  2.5,    6,   0.00, 1.00, 0,    True,  False, False, "tir"),   # ANB retire -> table ANB dediee
    W("Fusil Electrique",  0.40,   1.818,  12,  0.00, 1.50, 0,    True,  False, False, "tir"),   # V2 siege : x1.50 bcl, x0.25 chair, 12.50-25 m
    W("Marteau Antigrav", 2.25,   1.0,    10,  0.00, 1.00, 350,  True,  False, False, "frappe"),
    W("Marteau (au sol)", 3.00,   1.0,    6,   0.00, 1.00, 350,  True,  False, False, "frappe"),
    W("Ravageur",         1.35,   1.09,   25,  0.00, 1.00, 85,   True,  False, False, "salve"), # 3 x 0.45 (ecart S)
    W("Ravageur (guide)", 1.6875, 1.09,   25,  0.00, 1.00, 85,   True,  False, False, "salve"), # x1.25
    W("Fusil a Faisceau", 1.00,   3.33,   32,  0.00, 1.50, 0,    True,  False, False, "tir"),   # perfo allegee
    W("Dechiqueteur",     1.25,   5.0,    2,   0.00, 1.00, 0,    True,  True,  False, "tir"),
    W("Dechiq. (dual)",   2.50,   5.0,    1,   0.00, 1.00, 0,    True,  True,  False, "tir"),
    W("Gren. Incendiaire",0.035,  20.0,   90,  0.00, 1.50, 0,    True,  False, False, "tick"),  # 4.5 s de surface
    W("Gren. Dynamo",     0.35,   0.0,    1,   0.00, 3.00, 0,    True,  False, False, "grenade"),
    W("Tourelle Spiker",  0.105,  9.0,    180, 0.00, 1.00, 0,    True,  False, False, "tir"),

    # ── Forerunner / Sentinelles ───────────────────────────────────────
    # Valeurs retenues apres arbitrage des ecarts W-Z (voir 5.14).
    W("Sentinel Beam",    0.022,  30.0,   400, 0.00, 1.35, 0,    True,  False, False, "tir"),   # crit x1.35 ARMURES seules
    W("Heatwave",         0.88,   2.0,    8,   0.00, 2.50, 120,  True,  False, False, "salve"), # 8 x 0.11, crit tete
    W("Heatwave (unite)", 0.11,   16.0,   64,  0.00, 2.50, 15,   True,  False, False, "tir"),
    W("Cindershot",       1.376,  1.333,  5,   0.00, 1.00, 125,  True,  False, False, "tir"),   # 0.50 + 3 x 0.167 + brulure 0.375
    W("Epee de Lumiere",  2.25,   0.0,    13,  0.00, 1.00, 0,    True,  True,  False, "coup"),  # PERFORATEUR, 7.5 %/coup
    W("Epee Lum. (dual)", 1.00,   0.0,    13,  0.00, 1.00, 0,    True,  True,  False, "coup"),  # ecart Y : 1.00, pas 1.485
    W("Flash (detone)",   0.45,   0.0,    1,   0.00, 3.00, 0,    True,  False, False, "grenade"),# crit 1.35 (ecart Z)
]


# ═══════════════════════════════════════════════════════════════════════
#  5. MOTEUR — tirs pour tuer, tir par tir
# ═══════════════════════════════════════════════════════════════════════

def kill(w, unite, viser_faible=False):
    """(tirs_total, tir_qui_casse_le_bouclier, tir_qui_casse_le_casque)."""
    _, bcl, chair, casque, anti = unite

    if w.bypass:
        bcl = 0.0
    b, c_ = bcl, chair
    casq = casque if (casque > 0 and not (w.perfo and not anti)) else 0.0

    n = n_bcl = n_casq = 0
    while (b > 1e-9 or c_ > 1e-9) and n < 4000:
        n += 1
        if b > 1e-9:
            surplus = w.d_bcl - b
            b -= w.d_bcl
            if b <= 1e-9:
                b, n_bcl = 0.0, n
                if w.report and surplus > 0:
                    c_ -= surplus
        elif casq > 1e-9:
            casq -= w.d_chair
            if casq <= 1e-9:
                casq, n_casq = 0.0, n
        else:
            c_ -= (w.d_crit if (viser_faible and w.crit > 1) else w.d_chair)
    return n, n_bcl, n_casq


def ttk(w, n_tirs):
    """Temps pour tuer : le premier tir est à t=0."""
    return (n_tirs - 1) / w.rof if w.rof else float("nan")


def fraction_chargeur(w, unite=None, viser_faible=True):
    """Fraction de chargeur consommée pour tuer la cible étalon."""
    if unite is None:
        unite = trouver("Elite Minor")
    n, _, _ = kill(w, unite, viser_faible=viser_faible)
    return n / w.mag, w.mag / n


def coups_de_melee(unite, degats=MELEE_REFERENCE):
    """Nombre de coups de mêlée requis, bouclier + chair."""
    _, bcl, chair, casque, _ = unite
    return ceil((bcl + chair) / degats)


def trouver(nom):
    for u in UNITS:
        if u[0].lower().startswith(nom.lower()):
            return u
    raise KeyError(nom)


# ═══════════════════════════════════════════════════════════════════════
#  6. SORTIE — matrice de solidité
# ═══════════════════════════════════════════════════════════════════════

def matrice_solidite():
    print("=" * 104)
    print("  MATRICE DE SOLIDITÉ DES UNITÉS DE RÉFÉRENCE   (le % de bouclier encode le rang)")
    print("=" * 104)
    print(f"{'Unité':<20}{'Bcl':>7}{'% bcl':>9}{'Chair':>8}{'Casque':>9}"
          f"{'Hors casq.':>12}{'Total':>8}{'/Spartan':>10}   Note")
    print("-" * 104)
    for u in UNITS:
        nom, bcl, chair, casque, anti = u
        pct = bcl / ART_REFERENCE
        hors = bcl + chair
        tot = hors + casque
        note = []
        if casque and anti:
            note.append("casque ANTI-PERFO")
        elif casque:
            note.append("casque perforable")
        if bcl == 0:
            note.append("aucun bouclier")
        if nom.startswith("Spartan"):
            note.append("référence")
        print(f"{nom:<20}{bcl:>7.2f}{pct:>8.0%}{chair:>8.2f}"
              f"{(f'{casque:.2f}' if casque else '—'):>9}"
              f"{hors:>12.2f}{tot:>8.2f}{tot / SPARTAN_TOTAL:>9.2f}×   {' · '.join(note)}")
    print()

    bcls = [u[1] for u in UNITS]
    chairs = [u[2] for u in UNITS]
    print(f"  Amplitude bouclier : {min(bcls):.2f} → {max(bcls):.2f} ART"
          f"   (facteur {max(bcls) / max(min([b for b in bcls if b], default=1), 1e-9):.1f} hors zéros)")
    print(f"  Amplitude chair    : {min(chairs):.2f} → {max(chairs):.2f} ART"
          f"   (facteur {max(chairs) / min(chairs):.1f})")
    print("  → Le rang se lit sur le bouclier, pas sur la chair. Doctrine D1.\n")


def table_melee():
    print("=" * 104)
    print(f"  MÊLÉE — coups requis à la valeur de référence ({MELEE_REFERENCE:.2f} ART)")
    print("=" * 104)
    for u in UNITS:
        if u[0].startswith("Spartan"):
            continue
        print(f"{u[0]:<20}{coups_de_melee(u):>4} coups")
    print()


def table_armes():
    print("=" * 104)
    print("  ARMES")
    print("=" * 104)
    if not ARMES:
        print("  Table vide — l'équilibrage arme par arme n'a pas encore été posé.")
        print("  Le registre éditorial des armes retenues vit dans")
        print("  contenu-sandbox-armes-retenues.md (17 CSNU + 13 Covenant, sans chiffres).\n")
        return
    print(f"{'Arme':<22}{'ART':>8}{'Cad.':>7}{'Mag':>6}{'ANB':>7}"
          f"{'Tirs/Minor':>12}{'Frac.':>8}{'K/mag':>8}   Standard")
    print("-" * 104)
    minor = trouver("Elite Minor")
    for w in ARMES:
        n, _, _ = kill(w, minor, viser_faible=(w.crit > 1))
        frac, kpm = fraction_chargeur(w, minor)
        print(f"{w.nom:<22}{w.dmg:>8.3f}{w.rof:>7.1f}{w.mag:>6}{w.anb:>7.2f}"
              f"{n:>12}{frac:>8.0%}{kpm:>8.2f}   {classer_fraction(frac)}")
    print()


if __name__ == "__main__":
    matrice_solidite()
    table_melee()
    table_armes()
